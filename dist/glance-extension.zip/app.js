const G=Glance,$=s=>document.querySelector(s);let data={},settings={opacity:80,position:'bottom-right',enabled:true},extensionId='',connected=false,pipWindow=null,highlightTimer=null;
try{extensionId=localStorage.getItem('glance-extension-id')||'';settings={...settings,...JSON.parse(localStorage.getItem('glance-settings')||'{}')}}catch{}
const internal=!!globalThis.chrome?.runtime?.id;
function toast(text){$('#toast').textContent=text;$('#toast').style.display='block';clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('#toast').style.display='none',5000)}
async function rpc(message){if(internal)return chrome.runtime.sendMessage(message);if(!/^[a-p]{32}$/.test(extensionId)||!globalThis.chrome?.runtime?.sendMessage)throw Error('拡張機能の接続が必要です');return new Promise((resolve,reject)=>chrome.runtime.sendMessage(extensionId,message,r=>{const e=chrome.runtime.lastError;if(e)reject(Error('拡張機能に接続できません。IDとブラウザを確認してください。'));else if(r?.error)reject(Error(r.error));else resolve(r)}));}
function render(){
 clearTimeout(highlightTimer);const deadline=G.changes.next();if(Number.isFinite(deadline))highlightTimer=setTimeout(render,Math.max(1,deadline-Date.now()));
 $('#cards').innerHTML=Object.entries(G.services).map(([id,p])=>{const s=data[id],w=s?.windows?.[0],weekly=s?.windows?.[1],v=G.percent(w?.remaining),color=v!==null&&v<=15?'#ff9a99':p.color;return `<article class="card" aria-busy="${G.updating(s)}" style="--color:${color}"><div class="card-head"><span class="service-mark">${p.mark}</span><div class="service-title"><h2>${p.name}</h2><span class="plan">${G.escape(s?.plan||'契約プラン未取得')}</span></div><span class="badge">${G.escape(G.status(s))}</span></div><div class="gauge" role="img" aria-label="${G.escape(p.name+' '+(w?.label||'')+' 残り '+G.value(v))}"><svg viewBox="0 0 120 120" aria-hidden="true"><circle cx="60" cy="60" r="51"/><circle class="fill" cx="60" cy="60" r="51" stroke-dasharray="${(v??0)*3.2044} 320.44"/></svg><div class="gauge-value">${G.numeric(id,'window:'+w?.label,v===null?'—':Math.round(v))}${v===null?'':'<small>%</small>'}<span>${v===null?'数値未取得':'残り使用量'}</span></div></div><div class="metric-label">${G.escape(w?.label||(id==='chatgpt'?'Work / Codex 共通枠':'現在のセッション'))}</div><p class="reset">${G.escape(w?.reset||'リセット時刻未取得')}</p><div class="metric-row"><span>${G.escape(weekly?.label||'週間の利用枠')}</span><span>${G.numeric(id,'window:'+weekly?.label,G.value(weekly?.remaining))}</span></div><div class="track"><i style="width:${G.percent(weekly?.remaining)??0}%"></i></div><p class="reset">${G.escape(weekly?.reset||'リセット時刻未取得')}</p><p class="card-note">${G.escape(id==='chatgpt'?'通常のChat：取得不可（上記とは別枠）':s?.note||'公式の使用量画面に接続してください。')}</p>${G.extras(data,id)}${G.historyBox(s)}<div class="card-bottom"><span class="age">${G.escape(G.age(s))}</span><button data-service="${id}">${s?.status==='login'?'公式サイトでログイン':s?'使用量を開く':'接続'}</button></div></article>`}).join('');
 $('#widget').innerHTML=G.widget(data);$('#widget').className='widget '+settings.position;$('#widget').style.setProperty('--alpha',settings.opacity/100);$('#widget').style.display=settings.enabled?'':'none';
 if(pipWindow&&!pipWindow.closed){pipWindow.document.querySelector('.widget').innerHTML=G.widget(data)}
 $('#connection').innerHTML=connected?'<span class="notice-icon">↗</span><div><strong>ブラウザに接続済み</strong><p>専用の使用量タブを開いている間、60秒ごとに確認します。取得できない数値は推定しません。</p></div><span class="badge">LOCAL CONNECTION</span>':'<span class="notice-icon">↗</span><div><strong>ブラウザを接続して、モニターを開始</strong><p>拡張機能が公式の使用量画面を読み取ります。ログイン情報は公式画面で入力してください。</p></div><a href="#setup" class="button primary">接続方法</a>';
}
async function sync(){try{const r=await rpc({type:'GET'});if(!r)throw Error('接続できません');data=r.data||{};G.observe(data);settings={...settings,...r.settings};connected=true;applyControls();render()}catch{connected=false;render()}}
function applyControls(){$('#opacity').value=settings.opacity;$('#opacity-value').textContent=settings.opacity+'%';$('#position').value=settings.position;$('#enabled').checked=settings.enabled}
async function saveSettings(){settings={opacity:Number($('#opacity').value),position:$('#position').value,enabled:$('#enabled').checked};try{localStorage.setItem('glance-settings',JSON.stringify(settings))}catch{}applyControls();render();if(connected)try{await rpc({type:'SETTINGS',settings})}catch(e){toast(e.message)}}
$('#cards').addEventListener('click',async e=>{const id=e.target.closest('[data-service]')?.dataset.service;if(!id)return;if(!connected){toast('拡張機能を追加し、接続してください');$('#setup').scrollIntoView({behavior:'smooth'});return}try{await rpc({type:'OPEN',service:id});toast('公式画面を開きました。未ログインならログインしてください。');setTimeout(sync,2500)}catch(e){toast(e.message)}});
$('#refresh').onclick=async()=>{try{await rpc({type:'REFRESH'});toast('専用の使用量タブを更新しています');await sync()}catch(e){toast(e.message)}};
$('#connect-form').onsubmit=async e=>{e.preventDefault();extensionId=$('#extension-id').value.trim();try{const r=await rpc({type:'GET'});if(!r)throw Error('接続できません');localStorage.setItem('glance-extension-id',extensionId);await sync();toast('接続しました')}catch(e){toast(e.message)}};
$('#extension-id').value=extensionId;$('#opacity').oninput=saveSettings;$('#position').onchange=saveSettings;$('#enabled').onchange=saveSettings;
$('#pip').onclick=async()=>{try{if(!('documentPictureInPicture'in window)){toast('このブラウザでは最前面の小窓に未対応です。AIサイト内のパネルをご利用ください。');return}pipWindow=await window.documentPictureInPicture.requestWindow({width:330,height:600});const link=pipWindow.document.createElement('link');link.rel='stylesheet';link.href=new URL('style.css',location.href).href;pipWindow.document.head.append(link);pipWindow.document.title='各種トークン残量';pipWindow.document.body.className='pip-body';const panel=pipWindow.document.createElement('div');panel.className='widget';panel.innerHTML=G.widget(data);pipWindow.document.body.append(panel)}catch(e){toast('小窓を開けませんでした：'+e.message)}};
if(internal)$('#setup').style.display='none';
applyControls();render();sync();setInterval(sync,2000);

let soundDesired=true;
try{soundDesired=localStorage.getItem('token-sound')!=='off'}catch{}
function paintSound(on,waiting=false){$('#sound-toggle').innerHTML=`<span class="sound-dot"></span>${on?'通知音 ON'+(waiting?' · 操作待ち':''):'通知音 OFF'}`;$('#sound-toggle').setAttribute('aria-pressed',String(on))}
const notifier=GlanceSound.createNotifier({active:()=>G.changes.active(),eventId:()=>G.changes.eventId(),onState:on=>paintSound(soundDesired,!on&&soundDesired)});
paintSound(soundDesired,soundDesired);
async function armSound(){if(!soundDesired||notifier.isEnabled())return;try{await notifier.enable()}catch(e){paintSound(true,true)}}
function rememberSound(){try{localStorage.setItem('token-sound',soundDesired?'on':'off')}catch{}}
$('#sound-toggle').onclick=async()=>{soundDesired=!soundDesired;rememberSound();if(!soundDesired){notifier.disable();paintSound(false)}else{paintSound(true,true);try{await notifier.enable()}catch(e){toast(e.message)}}};
const firstGesture=e=>{if(e.target.closest('#sound-toggle,#sound-test'))return;armSound();document.removeEventListener('pointerdown',firstGesture,true);document.removeEventListener('keydown',firstGesture,true)};
document.addEventListener('pointerdown',firstGesture,true);document.addEventListener('keydown',firstGesture,true);
window.addEventListener('pagehide',()=>notifier.disable());

$('#sound-test').onclick=async()=>{soundDesired=true;rememberSound();try{await notifier.test();paintSound(true);toast('試聴音を再生しました。聞こえない場合は音量・タブのミュート・出力先を確認してください。')}catch(e){toast(e.message)}};
$('#sound-volume').oninput=()=>notifier.setVolume(Number($('#sound-volume').value)/100);

let theme='dark';try{theme=localStorage.getItem('token-theme')||'dark'}catch{}
function applyTheme(){document.documentElement.dataset.theme=theme;$('#theme-toggle').textContent=theme==='dark'?'☼ 標準':'◐ ダーク';$('#theme-toggle').setAttribute('aria-pressed',String(theme==='dark'))}
$('#theme-toggle').onclick=()=>{theme=theme==='dark'?'standard':'dark';try{localStorage.setItem('token-theme',theme)}catch{}applyTheme()};applyTheme();
function paintFullscreen(){const on=!!document.fullscreenElement;$('#fullscreen').textContent=on?'⛶ 全画面を終了':'⛶ フルスクリーン';$('#fullscreen').setAttribute('aria-pressed',String(on))}
$('#fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen()}catch(e){toast('フルスクリーン表示を開始できませんでした')}};document.addEventListener('fullscreenchange',paintFullscreen);paintFullscreen();
