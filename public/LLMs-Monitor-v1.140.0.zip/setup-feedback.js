/* Visible, action-local feedback. No RPC, permission changes or data collection. */
(function(root){
 function bind(button,result,english=false){
  if(!button||typeof button.onclick!=='function'||button.dataset.feedbackBound)return;
  button.dataset.feedbackBound='true';const action=button.onclick;let pending=false;
  const say=(ja,en)=>english?en:ja;
  button.onclick=async function(event){
   if(pending)return;pending=true;const label=button.textContent,previous=result?.textContent||'';
   let output=button.nextElementSibling;if(!output?.matches?.('[data-setup-feedback]')){output=document.createElement('output');output.dataset.setupFeedback='true';output.setAttribute('role','status');output.setAttribute('aria-live','polite');output.style.display='block';output.style.margin='6px 0';button.after(output);}
   output.textContent=say('処理中… 許可の確認画面があれば回答してください。','Working… Respond to a permission prompt if shown.');button.textContent=say('処理中…','Working…');button.disabled=true;button.setAttribute('aria-busy','true');
   let reported=false;const observer=result?new MutationObserver(()=>{if(result.textContent){reported=true;output.textContent=result.textContent}}):null;observer?.observe(result,{childList:true,characterData:true,subtree:true});
   const timer=setTimeout(()=>{output.textContent=say('応答を待っています。許可画面を確認してください。処理は続いている可能性があります。','Waiting for a response. Check any permission prompt; work may still be running.');button.textContent=say('応答待ち…','Waiting…');},12000);
   try{await action.call(this,event);output.textContent=result?.textContent&&(reported||result.textContent!==previous)?result.textContent:say('処理が終了しました。下の接続状態を確認してください。','Action finished. Check the connection state below.');}
   catch{output.textContent=say('操作を完了できませんでした。拡張機能の再読み込み後に再確認してください。','Action failed. Reload the extension and check again.');}
   finally{clearTimeout(timer);observer?.disconnect();pending=false;button.disabled=false;button.textContent=label;button.removeAttribute('aria-busy');}
  };
 }
 root.GlanceSetupFeedback={bind};if(typeof module!=='undefined')module.exports=root.GlanceSetupFeedback;
})(globalThis);
