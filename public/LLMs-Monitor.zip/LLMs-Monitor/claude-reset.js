/* Fixed model-specific entitlement adapter; never executes a reset or reads conversations. */
(function(root){
 const LABEL='Fableリセット';
 function parseText(text,{now=Date.now(),actionable=null}={}){
  if(typeof text!=='string'||text.length>1600||!Number.isFinite(now))return null;
  const lines=text.normalize('NFKC').split(/\n/).map(s=>s.trim()).filter(Boolean);
  if(lines.filter(s=>/^Fable\s*(?:リセット|reset)(?:\s*[ⓘℹi])?$/i.test(s)).length!==1)return null;
  const expiry=[...text.normalize('NFKC').matchAll(/(?:有効期限|Expires?(?: on)?|Valid until)\s*[:：]\s*(?:20\d\d年\s*\d{1,2}月\s*\d{1,2}日|(?:January|February|March|April|May|June|July|August|September|October|November|December) \d{1,2},? 20\d\d)\s+\d{1,2}:\d\d\s*(?:AM|PM)?\s*(?:JST|UTC|GMT|[+-]\d\d:\d\d)?/gi)].map(m=>m[0].trim());if(expiry.length!==1||expiry[0].length>140)return null;
  const t=expiry[0],jp=t.match(/(20\d\d)年\s*(\d{1,2})月\s*(\d{1,2})日\s+(\d{1,2}):(\d\d)\s*(JST|UTC|GMT|[+-]\d\d:\d\d)?$/i),en=t.match(/(January|February|March|April|May|June|July|August|September|October|November|December) (\d{1,2}),? (20\d\d)\s+(\d{1,2}):(\d\d)\s*(AM|PM)?\s*(JST|UTC|GMT|[+-]\d\d:\d\d)?$/i);
  if(!jp&&!en)return null;
  const months=['january','february','march','april','may','june','july','august','september','october','november','december'];
  const y=Number(jp?jp[1]:en[3]),m=jp?Number(jp[2]):months.indexOf(en[1].toLowerCase())+1,d=Number(jp?jp[3]:en[2]),minute=Number(jp?jp[5]:en[5]);let hour=Number(jp?jp[4]:en[4]);if(en?.[6]){if(hour<1||hour>12)return null;hour=hour%12+(en[6].toUpperCase()==='PM'?12:0)}
  const date=new Date(Date.UTC(y,m-1,d,hour,minute));if(m<1||m>12||d<1||hour>23||minute>59||date.getUTCFullYear()!==y||date.getUTCMonth()!==m-1||date.getUTCDate()!==d)return null;
  const zone=(jp?jp[6]:en[7])?.toUpperCase();let offset=null;if(zone==='JST')offset=540;else if(zone==='UTC'||zone==='GMT')offset=0;else if(zone){const z=zone.match(/^([+-])(\d\d):(\d\d)$/);if(!z||+z[2]>14||+z[3]>59||+z[2]===14&&+z[3])return null;offset=(+z[2]*60+ +z[3])*(z[1]==='-'?-1:1)}
  const expiresAt=offset===null?null:date.getTime()-offset*60000,negative=/(?:現在、?\s*)?リセットできる\s*Fable\s*の使用量はありません|(?:there is (?:currently )?no|no) Fable usage (?:available )?to reset/i.test(text),positive=/Fable reset (?:is )?available|Fableの使用量をリセットできます/i.test(text);
  if(positive&&negative)return null;
  const state=expiresAt!==null&&expiresAt<=now?'expired':negative?'unavailable':actionable===true||positive?'available':'unknown';
  return {schemaVersion:1,model:'Fable',state,expiresAt,expiryText:t,scope:'fable-weekly-consumption-only'};
 }
 function fromDocument(doc){
  let url;try{url=new URL(doc.location?.href||doc.URL||'')}catch{return null}
  if(url.origin!=='https://claude.ai'||url.search||!(/^\/settings\/usage\/?$/.test(url.pathname)&&!url.hash||['/','/new'].includes(url.pathname)&&url.hash==='#settings/usage'))return null;
  const hs=[...doc.querySelectorAll('h1,h2,h3,h4,[role="heading"]')],found=hs.filter(n=>/^Fable\s*(?:リセット|reset)(?:\s*[ⓘℹi])?$/i.test((n.textContent||'').trim()));if(found.length!==1)return null;
  const h=found[0],range=doc.createRange();range.setStartAfter(h);const next=hs[hs.indexOf(h)+1];if(next)range.setEndBefore(next);else range.setEndAfter(h.parentElement);const content=range.cloneContents();const controls=[...content.querySelectorAll('button,[role="button"]')].filter(n=>/^(?:無料でリセット|Free reset|Reset for free)$/i.test((n.textContent||'').trim()));
  return parseText('Fable reset\n'+(content.textContent||''),{actionable:controls.length===1?!controls[0].disabled&&controls[0].getAttribute?.('aria-disabled')!=='true':null});
 }
 function extra(v){if(!v)return null;return {label:LABEL,value:{available:'利用可能',unavailable:'対象使用量なし',unknown:'利用可否未確認',expired:'期限切れ'}[v.state],detail:'Fableが消費した週間枠のみ。週間全体のリセットではありません。',officialText:v.expiryText,expiresAt:v.expiresAt};}
 root.GlanceClaudeReset={LABEL,parseText,fromDocument,extra};if(typeof module!=='undefined')module.exports=root.GlanceClaudeReset;
})(globalThis);
