/* Fixed usage metadata source. Reuse one quiet acquisition; never foreground or execute a reset. */
(function(root){let pending=null,last=0;const route=value=>{try{const u=new URL(value);return u.origin==='https://claude.ai'&&!u.search&&(/^\/settings\/usage\/?$/.test(u.pathname)&&!u.hash||['/','/new'].includes(u.pathname)&&u.hash==='#settings/usage')}catch{return false}};
 async function source(tabs){
  const Q=root.GlanceQuietTabs,key='llms-claude-reset-source-v1';
  if(!Q||!chrome.storage?.session)return tabs.length===1?tabs[0]:null;
  const saved=(await chrome.storage.session.get(key))[key]||{};
  if(!tabs.length){const t=await Q.create('https://claude.ai/settings/usage');if(!t.borrowed)await chrome.storage.session.set({[key]:{id:t.id,reloadedAt:Date.now()}});return null;}
  const active=tabs.filter(t=>t.active);const tab=active.length===1?active[0]:tabs.length===1?tabs[0]:tabs.find(t=>t.id===saved.id);if(!tab)return null;
  if(tab.id===saved.id&&!tab.active&&tab.status==='complete'&&Date.now()-(saved.reloadedAt||0)>=300000&&await Q.isOwned(tab.id,{allowSeveredOpener:true})&&await Q.sameMonitorWindow(tab.windowId)){
   const live=await chrome.tabs.get(tab.id);if(route(live.url)&&!live.active&&!live.incognito&&await chrome.permissions.contains({permissions:['scripting'],origins:['https://claude.ai/*']})&&await Q.isOwned(live.id,{allowSeveredOpener:true})){await chrome.storage.session.set({[key]:{id:live.id,reloadedAt:Date.now()}});await chrome.tabs.reload(live.id);return null;}
  }return tab;
 }
 function readAll(){if(pending)return pending;if(Date.now()-last<60000)return Promise.resolve(null);last=Date.now();pending=(async()=>{if(!await chrome.permissions.contains({permissions:['scripting'],origins:['https://claude.ai/*']}))return null;const tabs=(await chrome.tabs.query({url:'https://claude.ai/*'})).filter(t=>route(t.url)&&!t.incognito);const tab=await source(tabs);if(!tab)return null;if(tab.discarded||tab.status!=='complete')return null;const rows=await chrome.scripting.executeScript({target:{tabId:tab.id},files:['claude-reset.js']});const result=await chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>globalThis.GlanceClaudeReset?.extrasFromDocument(document)||[]});const live=await chrome.tabs.get(tab.id);if(live.url!==tab.url||live.incognito||result.length!==1||result[0].frameId!==0)return null;const raw=result[0].result;
 const extras=Array.isArray(raw)?raw:[root.GlanceClaudeReset.extra(raw)];
 return extras.filter(e=>e&&['Fableリセット','週次リセット'].includes(e.label)&&['利用可能','対象使用量なし','利用可否未確認','期限切れ','現在使用不可','保有'].includes(e.value)&&typeof e.officialText==='string'&&e.officialText.length<=140&&(e.expiresAt===null||Number.isFinite(e.expiresAt))).filter(e=>e.label!=='Fableリセット'||!root.GlanceReaderRules||root.GlanceReaderRules.allows('claude-fable-reset-'+(/^有効期限/.test(e.officialText)?'ja':'en')+'-v1',/^有効期限/.test(e.officialText)?'ja':'en'));
 })().catch(()=>null).finally(()=>{pending=null});return pending;}
 async function read(){return (await readAll())?.[0]||null;}
 root.GlanceClaudeResetBackground={read,readAll,route};
})(globalThis);
