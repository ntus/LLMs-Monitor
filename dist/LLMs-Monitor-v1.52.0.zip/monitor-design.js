/* Layout and setup presentation. Permission controls mount only on the own top-level extension page. */
(function(root){
 const $=s=>document.querySelector(s),G=root.Glance,L=root.GlanceLocale;let last={},paintKey='',ownLanguage='',ownMounting=false;
 const say=(ja,en)=>L.language()==='ja'?ja:en;
 function paint(state=last){last=state||{};if(location.protocol==='chrome-extension:'){if(ownLanguage!==L.language()&&!ownMounting)mountOwnSetup();return;}const host=$('#inline-options');if(!host)return;const key=JSON.stringify([L.language(),last.apiCredits||{}]);if(key===paintKey)return;paintKey=key;const initialized=host.childElementCount>0,open=new Set([...host.querySelectorAll('details[open]')].map(n=>n.dataset.option));const diagnosticsLabel=document.querySelector('.dock-diagnostics>summary');if(diagnosticsLabel)diagnosticsLabel.textContent=say('診断・更新状況','Diagnostics / updates');
  const rows=[['api',say('APIクレジット残高','API credit balances'),say('月額の利用枠とは別です。各社の請求画面の表示値を読み取ります。','Separate from plan quotas. Reads the official billing display.')],['codex','Codex',say('初回のみヘルパー導入。接続後の一覧はChatGPTタスク詳細に表示します。','Install the helper once. Local tasks appear in ChatGPT task details.')],['tibo','Tibo / ClaudeDevs 𝕏',say('表示済みの本人投稿を確認。自動巡回・リロードはしません。','Checks rendered public author posts without automatic navigation or reload.')],['additional',say('追加サービス','Additional services'),say('Grok・DeepSeek・Perplexity・Gensparkは試験対応。選択したカードは幅を保って横一列に表示します。','Grok, DeepSeek, Perplexity and Genspark are experimental. Selected cards retain their width in a horizontal row.')]];
  host.innerHTML=`<section id="setup-api"><h2>${say('API残高','API balances')}</h2><p>${say('月額プランとは別のAPI残高です。アクセス許可と接続の変更は拡張機能のメイン画面で行います。','API balances are separate from plan quotas. Access controls are changed on the extension monitor.')}</p>${Object.entries(root.GlanceApiCredits.PROVIDERS).map(([key,p])=>`<section><h2>${G.escape(p.name)}</h2>${root.GlanceApiCredits.view(key)}<div class="api-setup-actions"><button type="button" data-permission-setup="api">${say('接続設定','Connection settings')}</button><a href="${p.url}" target="_blank" rel="noopener noreferrer">${say('公式請求画面を開く','Open official billing')} ↗</a></div></section>`).join('')}</section>`+rows.filter(([id])=>id!=='api').map(([id,title,copy])=>`<details open class="inline-option" data-option="${id}"><summary>${G.escape(title)}</summary><p>${G.escape(copy)}</p><button type="button" data-permission-setup="${id}">${say('接続設定','Connection settings')}</button></details>`).join('');for(const node of host.querySelectorAll('details[data-option]'))node.open=!initialized||open.has(node.dataset.option);

 }
 const dock=$('#monitor-dock'),advisor=$('#advisor');if(dock&&advisor)$('#dock-advice-slot').append(advisor);
 const diagnostics=$('#status-log');if(diagnostics){const wrap=document.createElement('details');wrap.className='dock-diagnostics';const summary=document.createElement('summary');summary.textContent=say('診断・更新状況','Diagnostics / updates');diagnostics.before(wrap);wrap.append(summary,diagnostics);}
 document.addEventListener('click',e=>{if(!e.target.closest('[data-permission-setup]'))return;rpc({type:'SETUP_INLINE_OPEN'}).catch(error=>{const n=$('#toast');n.textContent=error.message;n.style.display='block'})});
 function openSetup(key){key=key||'api';const show=()=>{const setup=$('#setup'),options=$('#setup-options');if(options)options.open=true;const option=document.querySelector('[data-option="'+key+'"]')||document.getElementById('setup-'+key);if(option)option.open=true;(option||setup)?.scrollIntoView({behavior:'smooth',block:'start'})};if(document.fullscreenElement)document.exitFullscreen().then(show).catch(show);else show();}
 document.addEventListener('click',e=>{if(e.target.closest('#header-setup')){e.preventDefault();openSetup('')}});
 async function mountOwnSetup(){
  if(location.protocol!=='chrome-extension:'||window.top!==window||ownMounting)return;ownMounting=true;ownLanguage=L.language();
  const host=$('#inline-options');try{
   const response=await fetch(chrome.runtime.getURL('setup.html'));if(!response.ok)throw Error('Setup unavailable');
   const source=new DOMParser().parseFromString(await response.text(),'text/html'),body=source.querySelector('.api-setup'),panel=document.createElement('div');panel.className='api-setup';
   panel.append(...[...body.childNodes].map(node=>document.importNode(node,true)));host.replaceChildren(panel);
   // Reuse the trusted setup controls and direct-click permission prompts without frames.
   for(const name of ['tibo-reader.js','helper-package.js','setup.js','api-setup.js','codex-setup.js','tibo-setup.js'])await new Promise((resolve,reject)=>{const script=document.createElement('script');script.src=chrome.runtime.getURL(name);script.onload=resolve;script.onerror=reject;document.body.append(script)});
   if(location.hash==='#setup')openSetup('');
  }catch{host.textContent=say('設定を読み込めません。拡張機能を再読み込みしてください。','Could not load settings. Reload the extension.');}finally{ownMounting=false;}
 }
 root.GlanceMonitorDesign={paint,openSetup};paint();mountOwnSetup();
})(globalThis);
/* Equalize corresponding sections without relying on subgrid support in embedded browsers. */
(()=>{const host=document.querySelector('#cards'),scroller=document.querySelector('.cards-scroll');if(!host||!scroller)return;let pending=false,width=0;
 function align(){pending=false;const cards=[...host.children].filter(n=>n.classList.contains('card')&&n.children.length===8);host.style.removeProperty('--aligned-card-rows');if(!cards.length)return;const sizes=Array(8).fill(0);for(const card of cards)[...card.children].forEach((node,i)=>{const css=getComputedStyle(node),height=node.getBoundingClientRect().height+(parseFloat(css.marginTop)||0)+(parseFloat(css.marginBottom)||0);sizes[i]=Math.max(sizes[i],Math.ceil(height))});host.style.setProperty('--aligned-card-rows',sizes.map(n=>n+'px').join(' '));}
 const schedule=()=>{if(!pending){pending=true;requestAnimationFrame(align)}};scroller.addEventListener('pointerup',event=>{if(event.target.matches('textarea.history-log'))schedule()});new MutationObserver(schedule).observe(host,{childList:true});new ResizeObserver(entries=>{const next=entries[0]?.contentRect.width;if(next!==width){width=next;schedule()}}).observe(scroller);schedule();
})();
