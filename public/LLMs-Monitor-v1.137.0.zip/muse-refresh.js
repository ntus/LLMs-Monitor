/* One optional owned Muse tab in the existing monitor window; never foregrounds or creates windows. */
(function(root){
 const KEY='llms-muse-refresh-v1',URL='https://muse.ai/',RETRY_DELAYS=[300000,900000,3600000];let pending=null;
 const retryCount=s=>Number.isSafeInteger(s.retryCount)&&s.retryCount>=0?Math.min(s.retryCount,3):0;
 const retryScheduled=s=>s.pauseReason==='timeout'&&Number.isSafeInteger(s.retryAt)&&Number.isFinite(s.at)&&s.retryAt>s.at&&s.retryAt-s.at<=3600000;
 const load=async()=>((await chrome.storage.session.get(KEY))[KEY]||{}),save=s=>chrome.storage.session.set({[KEY]:s});
 const enabled=async()=>((await chrome.storage.local.get('llms-additional-services-v1'))['llms-additional-services-v1']||{}).muse?.enabled===true&&await chrome.permissions.contains({permissions:['scripting'],origins:['https://muse.ai/*']});
 async function owned(tab){return tab&&tab.url===URL&&!tab.active&&await root.GlanceQuietTabs.isOwned(tab.id,{allowSeveredOpener:true})&&await (root.GlanceQuietTabs.hasMonitorWindow||root.GlanceQuietTabs.sameMonitorWindow)(tab.windowId)===true}
 // Explicit recovery opt-in may prepare General on the selected restored source,
 // without acquiring ownership or gaining permission to reload/close a live page.
 async function prepareSource(tab,s){
  if(await owned(tab))return true;
  if(!s?.borrowed||s.id!==tab?.id||tab.url!==URL||tab.active||tab.incognito||tab.discarded||!await enabled())return false;
  if((await chrome.storage.local.get('llms-acquisition-recovery-v1'))['llms-acquisition-recovery-v1']?.muse!==true)return false;
  return await (root.GlanceQuietTabs.hasMonitorWindow||root.GlanceQuietTabs.sameMonitorWindow)(tab.windowId)===true;
 }
 const loginCache=new Map();
 async function loginRequired(tab){
  if(tab.status!=='complete')return false;
  const cached=loginCache.get(tab.id);if(cached&&Date.now()-cached.at<15000)return cached.value;
  try{if(!await enabled()||!await owned(tab))return false;const rows=await chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>{
   if(location.origin!=='https://muse.ai'||location.pathname!=='/'||location.search||location.hash)return false;
   const visible=n=>n.getClientRects().length>0&&!n.closest('[hidden],[aria-hidden="true"]');
   return [...document.querySelectorAll('form')].filter(visible).some(form=>{
    const fields=[...form.querySelectorAll('input[type="email"],input[type="password"],input[autocomplete="username"]')].filter(visible);
    const buttons=[...form.querySelectorAll('button,[role="button"],input[type="submit"]')].filter(visible);
    const auth=/^(?:Log in|Log into Muse|Sign in|Sign into Muse|ログイン|サインイン)$/i,heading=[...document.querySelectorAll('h1,h2,[role="heading"]')].filter(visible).some(n=>auth.test(n.textContent.trim()));
    return fields.length>0&&buttons.some(n=>{const text=(n.textContent||n.getAttribute('value')||'').trim();return auth.test(text)||heading&&/^(?:Continue|続行)$/i.test(text)});
   });
  }});const value=rows.length===1&&rows[0].frameId===0&&rows[0].result===true;loginCache.clear();loginCache.set(tab.id,{at:Date.now(),value});return value}catch{return false}
 }
 async function releaseOwned(id){try{const tab=await chrome.tabs.get(id);if(await owned(tab))await root.GlanceQuietTabs.release(id);else await root.GlanceQuietTabs.relinquish(id)}catch{}}
 async function mayPrepare(id){const s=await load();if(!await enabled()||s.id!==id||s.paused||Date.now()-(s.startedAt||0)>90000)return false;try{return !!await prepareSource(await chrome.tabs.get(id),s)}catch{return false}}
 async function readerContext(id){const s=await load();let eligible=false;if(await enabled()&&s.id===id&&!s.paused&&Date.now()-(s.startedAt||0)<=90000)try{eligible=!!await prepareSource(await chrome.tabs.get(id),s)}catch{}return {prepare:eligible,generation:eligible?s.startedAt:0}}
 async function acquisitionStatus(){
  // Public UI metadata only; never expose tab IDs, URLs, page content or ownership records.
  try{if(!await enabled())return {state:'inactive',reason:'disabled'};const s=await load();
   if(!Number.isInteger(s.id))return {state:s.paused?'paused':'inactive',reason:s.paused?(s.pauseReason==='missing-tab'?'missing-tab':'paused'):'not-started'};
   let tab;try{tab=await chrome.tabs.get(s.id)}catch{return {state:'paused',reason:'missing-tab'}}
   if(!await owned(tab))return s.borrowed&&tab.url===URL&&!tab.incognito?{state:s.completedAt?'ready':'waiting',reason:'passive'}:{state:'paused',reason:'ownership'};
   if(await loginRequired(tab))return {state:'paused',reason:'login'};
   if(s.paused)return retryScheduled(s)?{state:'waiting',reason:'retry-backoff',retryAt:s.retryAt}:{state:'paused',reason:s.pauseReason==='login'?'login':s.pauseReason==='ownership'?'ownership':'paused'};
   if(s.completedAt)return {state:'ready',reason:''};
   if(!Number.isFinite(s.startedAt)||s.startedAt>Date.now())return {state:'unavailable',reason:'unknown'};
   return Date.now()-s.startedAt>90000?{state:'paused',reason:'timeout'}:{state:'waiting',reason:''};
  }catch{return {state:'unavailable',reason:'unknown'}}
 }
 async function accepts(id,generation){
  if(!Number.isSafeInteger(generation)||generation<0||!await enabled())return false;
  try{const source=await chrome.tabs.get(id);if(source.url!==URL||source.incognito)return false}catch{return false}
  const s=await load();let selectedOwned=false;
  if(Number.isInteger(s.id))try{selectedOwned=!!await prepareSource(await chrome.tabs.get(s.id),s)}catch{}
  const tabs=typeof chrome.tabs.query==='function'?(await chrome.tabs.query({url:URL})).filter(t=>t.url===URL&&!t.incognito):[];
  const active=tabs.filter(t=>t.active).sort((a,b)=>(b.lastAccessed||0)-(a.lastAccessed||0)||a.id-b.id)[0];
  if(active)return generation===0&&id===active.id;
  if(selectedOwned)return !s.paused&&id===s.id&&generation===s.startedAt&&Date.now()-s.startedAt<=90000;
  let retained;try{retained=Number.isInteger(s.id)?await chrome.tabs.get(s.id):null}catch{}
  const selected=retained?.url===URL&&!retained.incognito?retained:tabs.sort((a,b)=>(b.lastAccessed||0)-(a.lastAccessed||0)||a.id-b.id)[0];
  return generation===0&&(selected?selected.id===id:tabs.length===0&&typeof chrome.tabs.query!=='function');
 }
 async function renderPending(id){
  // Only an owned, inactive, exact-root acquisition within its existing hydration budget.
  if(!await mayPrepare(id))return {rendered:false};let s=await load();if((s.renderCount||0)>=3||Date.now()-(s.renderProbeAt||0)<3000)return {rendered:false};
  await save({...s,renderProbeAt:Date.now()});
  try{if(!await mayPrepare(id))return {rendered:false};const rows=await chrome.scripting.executeScript({target:{tabId:id},world:'MAIN',func:()=>{
   if(location.origin!=='https://muse.ai'||location.pathname!=='/'||location.search||location.hash||document.hidden!==true)return false;
   // React's streamed HTML can wait forever for a hidden-tab animation frame. Flush only its existing DOM-pair queue.
   const queue=window.$RB,flush=window.$RV;if(!Array.isArray(queue)||!queue.length||queue.length>32||queue.length%2||typeof flush!=='function')return false;
   const source=Function.prototype.toString.call(flush);if(source.length>5000||!source.includes('$RT=performance.now()')||!source.includes('removeChild'))return false;
   for(let i=0;i<queue.length;i+=2){const a=queue[i],b=queue[i+1];if(a?.tagName!=='TEMPLATE'||b?.tagName!=='DIV'||!/^B:[0-9]+$/.test(a.id)||b.id!=='S:'+a.id.slice(2)||!b.hidden||!a.isConnected||!b.isConnected||a.ownerDocument!==document||b.ownerDocument!==document)return false;}
   flush(queue);return queue.length===0;
  }});const rendered=rows.length===1&&rows[0].frameId===0&&rows[0].result===true,current=await load();if(rendered&&current.id===id&&current.startedAt===s.startedAt)await save({...current,renderCount:(current.renderCount||0)+1});return {rendered};
  }catch{return {rendered:false}}
 }
 async function report(id,generation){const s=await load();if(s.id!==id||!await accepts(id,generation))return;await save({...s,completedAt:Date.now(),retryCount:0,retryAt:0,pauseReason:''})}
 function refresh(force=false){if(pending)return pending;pending=(async()=>{
  if(!await enabled())return;let s=await load();if(Number.isInteger(s.id)&&await root.GlanceQuietTabs.recoverDiscarded?.('muse',s.id)){await save({...s,at:Date.now(),startedAt:Date.now(),completedAt:0,paused:false,pauseReason:'',retryAt:0,retryCount:0,renderCount:0,renderProbeAt:0});return;}if(s.paused&&s.pauseReason!=='login'&&s.pauseReason!=='missing-tab'&&!force&&(!retryScheduled(s)||Date.now()<s.retryAt))return;if(!force&&Date.now()-(s.at||0)<60000)return;
  if(Number.isInteger(s.id)){
   let tab;try{tab=await chrome.tabs.get(s.id)}catch{await root.GlanceQuietTabs.relinquish(s.id);s={};await save(s)}
   if(tab){if(!await owned(tab)){if(s.borrowed&&tab.url===URL&&!tab.incognito){
     const now=Date.now(),allowed=await prepareSource(tab,s),restart=allowed&&(s.completedAt||now-(s.startedAt||0)>=300000||force);
     await save({...s,at:now,paused:false,pauseReason:'',...(restart?{startedAt:now,completedAt:0,renderCount:0,renderProbeAt:0}:{})});return}
await save({...s,paused:true,pauseReason:'ownership',retryAt:0});return}if(await loginRequired(tab)){await save({...s,paused:true,pauseReason:'login',retryAt:0});return}if(s.pauseReason==='login'){s={...s,paused:false,pauseReason:'',startedAt:Date.now(),completedAt:0};await save(s)}if(!s.completedAt){if(Date.now()-(s.startedAt||0)>90000){if(force||retryScheduled(s)&&Date.now()>=s.retryAt){await save({...s,paused:false,pauseReason:'',retryAt:0,retryCount:force?0:Math.min(retryCount(s)+1,3),at:Date.now(),startedAt:Date.now(),completedAt:0,renderCount:0,renderProbeAt:0});if(await enabled()&&await owned(await chrome.tabs.get(s.id)))await chrome.tabs.reload(s.id)}else {const at=Date.now();await save({...s,paused:true,pauseReason:'timeout',at,retryAt:at+RETRY_DELAYS[Math.min(retryCount(s),2)]})}return}return}
    if(Date.now()-(s.at||0)<60000)return;await save({...s,at:Date.now(),startedAt:Date.now(),completedAt:0,renderCount:0,renderProbeAt:0,paused:false,pauseReason:'',retryAt:0,retryCount:0});if(await enabled()&&await owned(await chrome.tabs.get(s.id)))await chrome.tabs.reload(s.id);return;
   }
  }
  // QuietTabs refuses to create a tab if no existing normal monitor window is available.
  await save({at:Date.now()});try{const tab=await root.GlanceQuietTabs.create(URL);if(!await enabled()){await releaseOwned(tab.id);return}await save({id:tab.id,at:Date.now(),startedAt:Date.now(),completedAt:0,renderCount:0,renderProbeAt:0,paused:false,borrowed:tab.borrowed===true})}catch{}
 })().finally(()=>{pending=null});return pending}
 async function stop(){if(pending)await pending.catch(()=>{});const s=await load();if(Number.isInteger(s.id))await releaseOwned(s.id);await save({})}
 // Explicit recovery only: keep an adopted page untouched and allocate one new owned acquisition.
 async function reconnect(){if(pending)await pending.catch(()=>{});if(!await enabled())return;const s=await load();if(Number.isInteger(s.id)){let tab;try{tab=await chrome.tabs.get(s.id)}catch{}if(tab&&!await owned(tab)){await root.GlanceQuietTabs.relinquish(s.id);await save({});}else if(tab&&s.paused&&s.pauseReason==='ownership'){await save({...s,paused:false,pauseReason:''});}}return refresh(true)}
 async function diagnostic(){const s=await load();let tab;try{tab=Number.isInteger(s.id)?await chrome.tabs.get(s.id):null}catch{}let reader='unavailable';if(tab)try{let timer;const reply=await Promise.race([chrome.tabs.sendMessage(tab.id,{type:'MUSE_READER_DIAG'}),new Promise(resolve=>{timer=setTimeout(()=>resolve(null),1500)})]).finally(()=>clearTimeout(timer));if(reply&&reply.version==='1.136.0'&&['idle','checking','disabled','collecting','preparing','no-controls','submitted','error'].includes(reply.stage))reader=reply.stage}catch{}return {enabled:await enabled(),selected:!!tab,borrowed:s.borrowed===true,paused:s.paused===true,active:tab?.active===true,discarded:tab?.discarded===true,ageSeconds:Number.isFinite(s.startedAt)?Math.max(0,Math.floor((Date.now()-s.startedAt)/1000)):null,prepare:tab?await mayPrepare(tab.id):false,reader};}
 root.GlanceMuseRefresh=Object.freeze({refresh,reconnect,stop,mayPrepare,readerContext,accepts,report,renderPending,acquisitionStatus,diagnostic});
})(globalThis);
