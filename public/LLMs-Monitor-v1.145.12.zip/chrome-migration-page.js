'use strict';
const field = id => document.getElementById(id);
const file = field('file');
const confirm = field('confirm');
const importButton = field('import');
const result = field('result');
let pending = null;
let revision = 0;

function updateImport() {
 importButton.disabled = !pending || !confirm.checked;
}

field('export').onclick = async event => {
 const button = event.currentTarget;
 button.disabled = true;
 try {
  const answer = await chrome.runtime.sendMessage({type: 'CHROME_MIGRATION_EXPORT'});
  if (!answer?.ok) throw Error();
  const url = URL.createObjectURL(new Blob([answer.text], {type: 'application/json'}));
  const link = document.createElement('a');
  link.href = url;
  link.download = 'LLMs-Monitor-Chrome-transfer.json';
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 30_000);
  result.textContent = '移行ファイルを保存しました。';
 } catch {
  result.textContent = '移行ファイルを作れませんでした。拡張機能と保存容量を確認してください。';
 } finally {
  button.disabled = false;
 }
};

file.onchange = async () => {
 const current = ++revision;
 const selected = file.files[0];
 const preview = field('preview');
 pending = null;
 confirm.checked = false;
 confirm.disabled = true;
 preview.textContent = '';
 updateImport();
 if (!selected) return;
 try {
  if (selected.size > GlanceChromeMigration.MAX_BYTES) throw Error();
  const raw = await selected.text();
  const data = GlanceChromeMigration.parse(raw);
  if (current !== revision) return;
  const count = groups => Object.values(groups).flatMap(Object.values).reduce((n, rows) => n + rows.length, 0);
  const entries = count(data.history) + count(data.historyScopes.claude) +
   count(data.extraHistoryScopes.claude) + data.muse.length;
  preview.textContent = `設定 ${Object.keys(data.settings).length}項目、利用履歴 ${entries}件、Gateway利用枠 ${data.gateway.quota.length}件、API残高 ${data.gateway.credit.length}件`;
  pending = raw;
  confirm.disabled = false;
 } catch {
  if (current === revision) preview.textContent = '移行ファイルの形式とサイズを確認してください。';
 }
};

confirm.onchange = updateImport;
importButton.onclick = async () => {
 if (!pending || !confirm.checked) return;
 file.disabled = confirm.disabled = importButton.disabled = true;
 try {
  const answer = await chrome.runtime.sendMessage({type: 'CHROME_MIGRATION_IMPORT', text: pending});
  if (!answer?.ok) throw Error();
  result.textContent = '移行しました。モニターを再読み込みすると表示に反映されます。';
  file.value = '';
  file.onchange();
 } catch {
  result.textContent = '読み込めませんでした。移行先の保存容量とファイルを確認してください。';
 } finally {
  file.disabled = false;
  confirm.disabled = !pending;
  updateImport();
 }
};


async function setupPairingTransfer() {
 const mode = await chrome.runtime.sendMessage({type: 'CHROME_PAIRING_MODE'});
 if (!mode?.ok || !['legacy', 'store'].includes(mode.role)) return;
 field('pairing-transfer').hidden = false;
 field('pairing-' + mode.role).hidden = false;
 const status = field('pairing-result');
 if (mode.role === 'legacy') {
  field('pairing-arm').onclick = async () => {
   const code = field('pairing-code');
   code.value = '';
   try {
    const answer = await chrome.runtime.sendMessage({type: 'CHROME_PAIRING_ARM'});
    if (!answer?.ok) throw Error();
    code.value = answer.code;
    status.textContent = 'ストア版の移行画面にコードを入力してください。';
   } catch {
    status.textContent = '有効なGateway承認を確認できませんでした。';
   }
  };
  return;
 }
 field('pairing-import').onclick = async event => {
  const button = event.currentTarget;
  const input = field('pairing-input');
  const code = input.value.trim().toLowerCase();
  if (!/^[a-f0-9]{32}$/.test(code)) {
   status.textContent = '旧版に表示された32文字の一時コードを入力してください。';
   return;
  }
  button.disabled = true;
  try {
   if (!await chrome.permissions.request({permissions: ['nativeMessaging']})) {
    status.textContent = 'Gatewayと通信するChromeの権限が必要です。';
    return;
   }
   const answer = await chrome.runtime.sendMessage({type: 'CHROME_PAIRING_IMPORT', code});
   input.value = '';
   if (!answer?.ok) throw Error();
   const label = {adopted: '引き継ぎ完了', absent: '旧版で共有なし', unverified: '確認できませんでした'};
   status.textContent = `利用枠 ${label[answer.quota]}。API残高 ${label[answer.credit]}。`;
  } catch {
   status.textContent = '移行できませんでした。同じChromeプロファイルで旧版を有効にし、新しいコードを発行してください。';
  } finally {
   button.disabled = false;
  }
 };
}

setupPairingTransfer().catch(() => {});
