/* Read only current plan and benefit amount on an already-open official billing page. */
(()=>{
 if(globalThis.llmsBillingPlanReader==='1.137.0')return;globalThis.llmsBillingPlanReader='1.137.0';
 const exact=()=>location.href==='https://chatgpt.com/settings/billing';
 let last=0,signature='',timer;async function read(){if(!exact()||Date.now()-last<1500)return;last=Date.now();const plan=GlanceParser.chatGPTBillingPlan(document),benefit=GlanceParser.chatGPTBillingBenefit(document);if(plan==='未取得')return;const next=JSON.stringify({plan,benefit});if(next===signature)return;try{await chrome.runtime.sendMessage({type:'SNAPSHOT',service:'chatgpt',status:'ready',plan,planEvidence:'chatgpt-billing-current',windows:[],extras:benefit?[benefit]:[]});signature=next}catch{}}
 chrome.runtime.onMessage.addListener((m,_,reply)=>{if(m?.type==='GLANCE_BILLING_PLAN_PING'){reply({ready:exact(),version:'1.137.0'});return false}if(m?.type==='GLANCE_BILLING_PLAN_READ'){last=0;signature='';read().then(()=>reply({ready:true}),()=>reply({ready:false}));return true}return false});
 const observer=new MutationObserver(()=>{clearTimeout(timer);timer=setTimeout(read,300)});observer.observe(document.documentElement,{childList:true,subtree:true});setTimeout(()=>{observer.disconnect();clearTimeout(timer)},90000);read();
})();
