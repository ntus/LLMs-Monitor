/* Explicit local transfer between Chrome extension IDs. Never transfers authorization. */
(function(root){
 'use strict';
 const SCHEMA='llms-monitor-chrome-migration',VERSION=1,MAX_BYTES=8_000_000,LIMIT=10000;
 const SETTINGS=['opacity','position','enabled','theme','language','sound','volume','usageDisplay','serviceOrder','hiddenServices'];
 const KEYS=['settings','history','historyVersion','historyScopes','extraHistoryScopes','llms-additional-services-v1','llms-gateway-link-v1','llms-gateway-credit-link-v1','chromeMigrationSelection'];
 const catalog=['chatgpt','claude','gemini','grok','muse','copilot','deepseek','perplexity','genspark'];
 const quota=['chatgpt','claude','gemini'],credit=['openai','anthropic','google','xai'];
 const bad=()=>{throw Error('移行ファイルの形式またはサイズが正しくありません。');};
 const object=x=>x!==null&&typeof x==='object'&&!Array.isArray(x)&&Object.getPrototypeOf(x)===Object.prototype;
 const exact=(x,keys)=>object(x)&&Object.keys(x).every(k=>keys.includes(k));
 const pick=(x,keys)=>Object.fromEntries(keys.filter(k=>Object.hasOwn(x??{},k)).map(k=>[k,x[k]]));
 const number=(n,min,max)=>typeof n==='number'&&Number.isFinite(n)&&n>=min&&n<=max;
 const validAt=n=>Number.isSafeInteger(n)&&number(n,1,Date.now()+5000);
 const validLabel=l=>l.length>0&&l.length<=80&&!/[<>&\x00-\x1f]/.test(l)&&!['__proto__','prototype','constructor'].includes(l);
 const choice=(v,list)=>Array.isArray(v)&&v.length<=list.length&&new Set(v).size===v.length&&v.every(k=>list.includes(k));
 function settings(x,strict){
  if(!exact(x,SETTINGS))bad();
  const validators={
   opacity:v=>number(v,15,100),volume:v=>number(v,1,50),
   position:v=>['bottom-right','bottom-left','top-right','top-left'].includes(v),
   enabled:v=>typeof v==='boolean',sound:v=>typeof v==='boolean',
   theme:v=>['standard','dark'].includes(v),language:v=>['ja','en'].includes(v),
   usageDisplay:v=>['used','remaining'].includes(v),
   serviceOrder:v=>choice(v,catalog),hiddenServices:v=>choice(v,catalog)
  };
  return Object.fromEntries(Object.entries(x).filter(([k,v])=>validators[k](v)||(strict&&bad())));
 }
 function rows(x,kind,strict){
  if(!Array.isArray(x)||x.length>LIMIT)bad();
  const keys=kind==='quota'?['capturedAt','remaining']:
   kind==='muse'?['capturedAt','remaining','total','unit','period']:['capturedAt','remaining','limit','used','unit'];
  return x.flatMap(row=>{
   const r=strict?row:pick(row,keys);
   let valid=exact(r,keys)&&validAt(r.capturedAt)&&number(r.remaining,0,kind==='quota'?100:1e12);
   if(valid&&kind==='muse')valid=number(r.total,1,1e9)&&r.remaining<=r.total&&['percent','count','credits','tokens'].includes(r.unit)&&
    (r.unit!=='percent'||r.total===100)&&['week','day','month','session','unknown'].includes(r.period);
   if(valid&&kind==='extra')valid=r.unit==='unknown'&&(!Object.hasOwn(r,'limit')||number(r.limit,r.remaining,1e12))&&
    (!Object.hasOwn(r,'used')||number(r.used,0,r.limit??1e12));
   if(!valid){if(strict)bad();return [];}
   return [r];
  });
 }
 function groups(x,kind,strict){
  if(!object(x)||Object.keys(x).length>60)bad();
  return Object.fromEntries(Object.entries(x).map(([label,list])=>{
   if(!validLabel(label)||kind==='extra'&&label!=='追加使用クレジット')bad();
   return [label,rows(list,kind,strict)];
  }));
 }
 function scopes(x,kind,strict){
  if(!exact(x,['claude'])||!object(x.claude??{})||Object.keys(x.claude??{}).length>100)bad();
  return {claude:Object.fromEntries(Object.entries(x.claude??{}).map(([scope,windows])=>{
   if(!/^claude:[a-f0-9]{64}$/.test(scope))bad();
   return [scope,groups(windows,kind,strict)];
  }))};
 }
 function clean(d,strict){
  if(!exact(d,['schema','version','settings','history','historyScopes','extraHistoryScopes','muse','gateway'])||
     d.schema!==SCHEMA||d.version!==VERSION||!exact(d.history,catalog)||!exact(d.gateway,['quota','credit'])||
     !choice(d.gateway.quota,quota)||!choice(d.gateway.credit,credit))bad();
  return {schema:SCHEMA,version:VERSION,settings:settings(d.settings,strict),
   history:Object.fromEntries(Object.entries(d.history).map(([id,g])=>[id,groups(g,'quota',strict)])),
   historyScopes:scopes(d.historyScopes,'quota',strict),extraHistoryScopes:scopes(d.extraHistoryScopes,'extra',strict),
   muse:rows(d.muse,'muse',strict),gateway:{quota:[...d.gateway.quota],credit:[...d.gateway.credit]}};
 }
 function fromStorage(s){
  const providers=(key,kind,valid)=>{
   const configured=s[key]?.enabled===true?s[key].providers:s.chromeMigrationSelection?.[kind];
   return [...new Set((Array.isArray(configured)?configured:[]).filter(id=>valid.includes(id)))];
  };
  return clean({schema:SCHEMA,version:VERSION,settings:pick(s.settings,SETTINGS),history:s.history??{},
   historyScopes:s.historyScopes??{},extraHistoryScopes:s.extraHistoryScopes??{},
   muse:s['llms-additional-services-v1']?.muse?.history??[],
   gateway:{quota:providers('llms-gateway-link-v1','quota',quota),credit:providers('llms-gateway-credit-link-v1','credit',credit)}},false);
 }
 function parse(text){
  if(typeof text!=='string'||text.length>MAX_BYTES||new TextEncoder().encode(text).length>MAX_BYTES)bad();
  return clean(JSON.parse(text),true);
 }
 function serialize(s){
  const text=JSON.stringify(fromStorage(s));
  if(new TextEncoder().encode(text).length>MAX_BYTES)bad();
  return text;
 }
 function mergeRows(existing,incoming){
  // On a timestamp collision prefer the destination observation.
  const byTime=new Map(incoming.map(r=>[r.capturedAt,r]));
  for(const r of existing)byTime.set(r.capturedAt,r);
  return [...byTime.values()].sort((a,b)=>a.capturedAt-b.capturedAt).slice(-LIMIT);
 }
 function mergeGroups(a,b){
  const out={...a};
  for(const [label,items] of Object.entries(b))out[label]=mergeRows(out[label]??[],items);
  return out;
 }
 function mergeScopes(a,b){
  const claude={...(a?.claude??{})};
  for(const [scope,windows] of Object.entries(b.claude))claude[scope]=mergeGroups(claude[scope]??{},windows);
  return {...a,claude};
 }
 function patch(s,d){
  const history={...(s.history??{})};
  for(const [id,windows] of Object.entries(d.history))history[id]=mergeGroups(history[id]??{},windows);
  const additional=s['llms-additional-services-v1']??{};
  const updates={settings:{...s.settings,...d.settings,...(Object.hasOwn(d.settings,'serviceOrder')||Object.hasOwn(d.settings,'hiddenServices')?{selectionUpdatedAt:Date.now()}:{} )},
   history,historyScopes:mergeScopes(s.historyScopes,d.historyScopes),extraHistoryScopes:mergeScopes(s.extraHistoryScopes,d.extraHistoryScopes),
   historyVersion:(Number(s.historyVersion)||0)+1,
   chromeMigrationSelection:d.gateway};
  if(d.muse.length)updates['llms-additional-services-v1']={...additional,muse:{...additional.muse,history:mergeRows(additional.muse?.history??[],d.muse)}};
  return updates;
 }
 const api={KEYS,MAX_BYTES,parse,serialize,patch};
 root.GlanceChromeMigration=api;
 if(typeof module!=='undefined')module.exports=api;
})(globalThis);
