/* Fixed model-specific entitlement adapter; never executes a reset or reads conversations. */
(function(root){
 const LABEL='Fableリセット';
 function parseText(text,{now=Date.now(),actionable=null}={}){
  if(typeof text!=='string'||text.length>1600||!Number.isFinite(now))return null;
  const lines=text.normalize('NFKC').split(/\n/).map(s=>s.trim()).filter(Boolean);
  if(lines.filter(s=>/^Fable\s*(?:リセット|reset)(?:\s*[ⓘℹi])?$/i.test(s)).length!==1)return null;
  const expiry=[...text.normalize('NFKC').matchAll(/(?:有効期限|Expires?(?: on)?|Valid until)\s*[:：]\s*(?:20\d\d年\s*\d{1,2}月\s*\d{1,2}日|(?:January|February|March|April|May|June|July|August|September|October|November|December) \d{1,2},? 20\d\d)\s+\d{1,2}:\d\d\s*(?:AM|PM)?\s*(?:JST|UTC|GMT|[+-]\d\d:\d\d)?/gi)].map(m=>m[0].trim());if(expiry.length!==1||expiry[0].length>140)return null;
  const t=expiry[0],jp=t.match(/(20\d\d)年\s*(\d{1,2})月\s*(\d{1,2})日\s+(\d{1,2}):(\d\d)\s*(JST|UTC|GMT|[+-]\d\d:\d\d)?$/i),en=t.match(/(January|February|March|April|May|June|July|August|September|October|November|December) (\d{1,2}),? (20\d\d)\s+(\d{1,2}):(\d\d)\s*(AM|PM)?\s*(JST|UTC|GMT|[+-]\d\d:\d\d)?$/i);
  if(!jp&&!en)return null;
  const months=['january','february','march','april','may','june','july','august','september','october','november','december'];
  const y=Number(jp?jp[1]:en[3]),m=jp?Number(jp[2]):months.indexOf(en[1].toLowerCase())+1,d=Number(jp?jp[3]:en[2]),minute=Number(jp?jp[5]:en[5]);let hour=Number(jp?jp[4]:en[4]);if(en?.[6]){if(hour<1||hour>12)return null;hour=hour%12+(en[6].toUpperCase()==='PM'?12:0)}
  const date=new Date(Date.UTC(y,m-1,d,hour,minute));if(m<1||m>12||d<1||hour>23||minute>59||date.getUTCFullYear()!==y||date.getUTCMonth()!==m-1||date.getUTCDate()!==d)return null;
  const zone=(jp?jp[6]:en[7])?.toUpperCase();let offset=null;if(zone==='JST')offset=540;else if(zone==='UTC'||zone==='GMT')offset=0;else if(zone){const z=zone.match(/^([+-])(\d\d):(\d\d)$/);if(!z||+z[2]>14||+z[3]>59||+z[2]===14&&+z[3])return null;offset=(+z[2]*60+ +z[3])*(z[1]==='-'?-1:1)}
  const expiresAt=offset===null?null:date.getTime()-offset*60000,negative=/(?:現在、?\s*)?リセットできる\s*Fable\s*の使用量はありません|(?:there is (?:currently )?no|no) Fable usage (?:available )?to reset/i.test(text),positive=/Fable reset (?:is )?available|Fableの使用量をリセットできます/i.test(text);
  if(positive&&negative)return null;
  const state=expiresAt!==null&&expiresAt<=now?'expired':negative?'unavailable':actionable===true||positive?'available':'unknown';
  return {schemaVersion:1,model:'Fable',state,expiresAt,expiryText:t,scope:'fable-weekly-consumption-only'};
 }
 function fromDocument(doc){
  let url;try{url=new URL(doc.location?.href||doc.URL||'')}catch{return null}
  if(url.origin!=='https://claude.ai'||url.search||!(/^\/settings\/usage\/?$/.test(url.pathname)&&!url.hash||['/','/new'].includes(url.pathname)&&url.hash==='#settings/usage'))return null;
  const hs=[...doc.querySelectorAll('h1,h2,h3,h4,[role="heading"]')],found=hs.filter(n=>/^Fable\s*(?:リセット|reset)(?:\s*[ⓘℹi])?$/i.test((n.textContent||'').trim()));if(found.length!==1)return null;
  const h=found[0],range=doc.createRange();range.setStartAfter(h);const next=hs[hs.indexOf(h)+1];if(next)range.setEndBefore(next);else range.setEndAfter(h.parentElement);const content=range.cloneContents();const controls=[...content.querySelectorAll('button,[role="button"]')].filter(n=>/^(?:無料でリセット|Free reset|Reset for free)$/i.test((n.textContent||'').trim()));
  return parseText('Fable reset\n'+(content.textContent||''),{actionable:controls.length===1?!controls[0].disabled&&controls[0].getAttribute?.('aria-disabled')!=='true':null});
 }
 function extra(v){if(!v)return null;return {label:LABEL,value:{available:'利用可能',unavailable:'対象使用量なし',unknown:'利用可否未確認',expired:'期限切れ'}[v.state],detail:'Fableが消費した週間枠のみ。週間全体のリセットではありません。',officialText:v.expiryText,expiresAt:v.expiresAt};}
 function weekly(text,{actionable=null}={}){
  if(typeof text!=='string'||text.length>1600)return null;
  const normalized=text.normalize('NFKC');
  if(!/^(?:週次リセット|Weekly reset)\s*\n/i.test(normalized))return null;
  const matches=[...normalized.matchAll(/(?:有効期限|Expires?(?: on)?|Valid until)\s*[:：]\s*((?:20\d\d年\s*)?\d{1,2}月\s*\d{1,2}日\s+\d{1,2}:\d{2}\s*JST)/gi)];
  if(matches.length!==1)return null;
  const parts=matches[0][1].match(/(?:(20\d\d)年\s*)?(\d{1,2})月\s*(\d{1,2})日\s+(\d{1,2}):(\d{2})\s*JST/);
  const [,year,month,day,hour,minute]=parts;
  const probe=new Date(Date.UTC(Number(year||2000),Number(month)-1,Number(day),Number(hour),Number(minute)));
  if(+month<1||+month>12||+day<1||+hour>23||+minute>59||probe.getUTCMonth()!==+month-1||probe.getUTCDate()!==+day)return null;
  const expiresAt=year?probe.getTime()-540*60000:null;
  return {label:'週次リセット',value:expiresAt&&expiresAt<=Date.now()?'期限切れ':actionable===true?'利用可能':actionable===false?'現在使用不可':'保有',detail:'公式の週次リセット権。対象範囲と利用可否は公式使用量画面で確認してください。',officialText:matches[0][0],expiresAt};
 }
 function extrasFromDocument(doc){
  let url;try{url=new URL(doc.location?.href||doc.URL||'')}catch{return []}
  if(url.origin!=='https://claude.ai'||url.search||!(/^\/settings\/usage\/?$/.test(url.pathname)&&!url.hash||['/','/new'].includes(url.pathname)&&url.hash==='#settings/usage'))return [];
  const cards=[...doc.querySelectorAll('#resets-fable,#resets-other')].filter(card=>['resets-fable','resets-other'].includes(card.id)&&typeof card.querySelectorAll==='function');
  if(!cards.length){const old=extra(fromDocument(doc));return old?[old]:[];}
  const result=[];
  for(const card of cards){
   const text=String(card.textContent||'');
   const buttons=[...card.querySelectorAll('button,[role="button"]')].filter(b=>/無料でリセット|Free reset|Reset for free/i.test(b.textContent||''));
   const actionable=buttons.length===1?!buttons[0].disabled&&buttons[0].getAttribute?.('aria-disabled')!=='true':null;
   const label=card.id==='resets-fable'?'Fable reset':'週次リセット';
   const body=label+'\n'+text.replace(/^(?:Fable\s*(?:リセット|reset)|週次リセット|Weekly reset)\s*/i,'');
   const item=card.id==='resets-fable'?extra(parseText(body,{actionable})):weekly(body,{actionable});
   if(item)result.push(item);
  }
  return result;
 }
 root.GlanceClaudeReset={LABEL,parseText,fromDocument,extra,weekly,extrasFromDocument};if(typeof module!=='undefined')module.exports=root.GlanceClaudeReset;
})(globalThis);
