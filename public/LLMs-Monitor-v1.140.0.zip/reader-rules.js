/* Data-only reader selection. Remote data cannot add code, selectors, origins or permissions. */
(function(root){
 'use strict';
 const PARSERS=['openai-next-expiry-ja-v1','openai-next-expiry-en-v1','claude-fable-reset-ja-v1','claude-fable-reset-en-v1'];
 const base={schemaVersion:1,revision:2,rules:PARSERS.map((parser,i)=>({id:(i<2?'openai-expiry-':'claude-reset-')+i,provider:i<2?'chatgpt':'claude',route:i<2?'billing-overview':'usage',structure:i<2?'api-credit-balance':'model-reset-entitlement',plans:['any'],languages:[i%2?'en':'ja'],parser}))};
 let current=base;
 function validate(input){
  if(!input||Array.isArray(input)||Object.keys(input).some(k=>!['schemaVersion','revision','rules'].includes(k))||input.schemaVersion!==1||!Number.isSafeInteger(input.revision)||input.revision<1||!Array.isArray(input.rules)||!input.rules.length||input.rules.length>32)return null;
  const seen=new Set();for(const r of input.rules){if(!r||Object.keys(r).sort().join(',')!=='id,languages,parser,plans,provider,route,structure'||!/^[-a-z0-9]{1,60}$/.test(r.id)||seen.has(r.id)||!PARSERS.includes(r.parser)||(r.parser.startsWith('openai-')?(r.provider!=='chatgpt'||r.route!=='billing-overview'||r.structure!=='api-credit-balance'):(r.provider!=='claude'||r.route!=='usage'||r.structure!=='model-reset-entitlement'))||!Array.isArray(r.plans)||!r.plans.length||r.plans.length>8||r.plans.some(p=>!['any','free','plus','pro','pro-100','pro-200','pro-500','business','enterprise','ultra','max','max-5x','team'].includes(p))||!Array.isArray(r.languages)||!r.languages.length||r.languages.length>2||r.languages.some(l=>!['ja','en'].includes(l)))return null;seen.add(r.id)}
  return JSON.parse(JSON.stringify(input));
 }
 function install(input){const v=validate(input);if(!v||v.revision<current.revision)return false;current=v;return true}
 function allows(parser,language,plan='unknown'){return current.rules.some(r=>r.parser===parser&&r.languages.includes(language)&&(r.plans.includes('any')||plan!=='unknown'&&r.plans.includes(plan)))}
 function snapshot(){return JSON.parse(JSON.stringify(current))}
 root.GlanceReaderRules={validate,install,allows,snapshot};if(typeof module!=='undefined')module.exports=root.GlanceReaderRules;
})(globalThis);
