/* Optional Muse settings. Read-only preparation only in a freshly revalidated owned inactive tab. */
(()=>{
 if(globalThis.llmsMuseReader?.version==='1.136.0')return;globalThis.llmsMuseReader={version:'1.136.0'};
 let pending=false,stopped=false,timer,signature='',stableAt=0,preparations=0,lastPreparationAt=0,generation=0,refreshPending=false,diagStage='idle';
 const route=()=>location.origin==='https://muse.ai'&&location.pathname==='/'&&!location.search&&!location.hash;
 async function read(){
  if(stopped||pending||!route())return;pending=true;diagStage='checking';
  try{
   const allowed=await chrome.runtime.sendMessage({type:'ADDITIONAL_READER_STATUS',service:'muse'});if(allowed?.enabled!==true||!route()||stopped){diagStage='disabled';return;}
   if(allowed.generation!==generation){generation=allowed.generation;preparations=0;lastPreparationAt=0;refreshPending=allowed.prepare===true&&allowed.explicit!==true;}
   if(refreshPending){
    const current=await chrome.runtime.sendMessage({type:'ADDITIONAL_READER_STATUS',service:'muse'});
    if(current?.enabled!==true||current.prepare!==true||current.generation!==generation||!route())return;
    refreshPending=false;
    if(GlanceMuseUsage.refreshGeneral?.(document)){signature='';stableAt=0;diagStage='preparing';clearTimeout(timer);timer=setTimeout(read,1600);return;}
   }
   diagStage='collecting';const cards=GlanceMuseUsage.collect(document),parsed=GlanceMuseUsage.extract(cards);
   // Loading or an absent General section must not erase or refresh the previous observation.
   if(parsed.status!=='ready'){if(allowed.prepare===true&&preparations<3){const render=allowed.explicit===true?null:await chrome.runtime.sendMessage({type:'MUSE_RENDER_PENDING',service:'muse'});if(render?.rendered){clearTimeout(timer);timer=setTimeout(read,1600);return}if(Date.now()-lastPreparationAt<5000){clearTimeout(timer);timer=setTimeout(read,5000-(Date.now()-lastPreparationAt));return}const current=await chrome.runtime.sendMessage({type:'ADDITIONAL_READER_STATUS',service:'muse'});if(current?.enabled!==true||current.prepare!==true||current.generation!==generation||!route())return;diagStage='preparing';if(GlanceMuseUsage.prepare(document)){lastPreparationAt=Date.now();preparations++;}else diagStage='no-controls';clearTimeout(timer);timer=setTimeout(read,1600)}return}
   const key=JSON.stringify(parsed);if(key!==signature){signature=key;stableAt=Date.now();clearTimeout(timer);timer=setTimeout(read,1600);return}if(Date.now()-stableAt<1500)return;
   diagStage='submitted';await chrome.runtime.sendMessage({type:'ADDITIONAL_SNAPSHOT',service:'muse',readerVersion:'1.136.0',generation:allowed.generation,evidence:cards});
  }catch{diagStage='error'; /* An extension restart/revoke fails closed; no page text or private error logging. */ }finally{pending=false}
 }
 const observer=new MutationObserver(()=>{clearTimeout(timer);timer=setTimeout(read,1500)});observer.observe(document.documentElement,{subtree:true,childList:true,characterData:true});
 const interval=setInterval(read,60000);timer=setTimeout(read,1500);
 chrome.runtime.onMessage.addListener((m,_,reply)=>{if(m?.type==='MUSE_READER_DIAG'){reply({version:'1.136.0',stage:diagStage});return false;}if(m?.type!=='ADDITIONAL_READ')return false;read().then(()=>reply({ready:true,version:'1.136.0'}));return true});
 addEventListener('pagehide',()=>{stopped=true;observer.disconnect();clearTimeout(timer);clearInterval(interval)},{once:true});
})();
