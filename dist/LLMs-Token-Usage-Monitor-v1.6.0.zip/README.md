# LLMs Token Usage Monitor

[🌍 EN](#en) · [🇯🇵 JP](#ja)

<a id="en"></a>

**See the remaining usage across ChatGPT, Claude, and Gemini at a glance.**

This browser companion checks usage from your signed-in provider sessions about once a minute. Large gauges and bars show current and weekly limits, reset times, plans, and available credits. Your change history stays in your browser, with up to 10,000 entries per limit. The interface supports English and Japanese, light and dark themes, fullscreen viewing, and compact floating panels.

Version **1.6.0 beta** adds service visibility and ordering, deadline alerts, an estimate of how many current-session equivalents remain in the weekly allowance, and compact usage advice. Tips and news link to their original sources. The estimate is based on your local history; it is not an official provider limit.

[Open the monitor](https://ai-usage-glance.ntusnog.chatgpt.site/) · [Download the beta extension package](dist/LLMs-Token-Usage-Monitor-v1.6.0.zip) · [Detailed specification](SPECIFICATION.md) · [Privacy](PRIVACY.md) · [Follow @ntus on X](https://x.com/ntus)

## Quick start

1. Sign in to the services you want to monitor on their official [ChatGPT](https://chatgpt.com/), [Claude](https://claude.ai/), and [Gemini](https://gemini.google.com/) sites in the same Chrome or Edge profile. Enter credentials only on those sites.
2. Before store approval, run `python3 build.py`, unpack `dist/LLMs-Token-Usage-Monitor-v1.6.0.zip`, and load the unpacked extension from the browser's extension management page for beta testing. Installing without developer mode requires Chrome Web Store or Edge Add-ons review and publication.
3. Open the extension or the [web monitor](https://ai-usage-glance.ntusnog.chatgpt.site/). The web monitor asks for your extension ID once. The providers' usage tabs do not need to remain open.
4. Use **Show and arrange services** to choose and reorder cards. Hidden services continue collecting history. Adjust language, theme, opacity, volume, and fullscreen mode from the controls.

The monitor never asks for provider passwords and never exercises a reset entitlement automatically. A reset link opens the official usage page when an entitlement is available. If a provider does not expose a reliable plan or deadline, the app shows it as unavailable rather than guessing. Document Picture-in-Picture can keep a panel on top in supported browsers; OS-wide window transparency and native mobile apps are outside this beta.

For contributors and future AI-assisted changes, read [AGENTS.md](AGENTS.md), the [specification](SPECIFICATION.md), and the [requirements ledger](spec/requirements.json) before editing. Run `node --test tests/*.test.cjs` and `python3 build.py` before releasing.

---

<a id="ja"></a>
# 日本語 — LLMs トークン残量モニタ

[🌍 EN](#en) · [🇯🇵 JP](#ja)

## 1.6.0 β — 各種LLMの利用残量をリアルタイム表示

ChatGPT、Claude、Gemini の残量とリセット時刻を、ログイン中の公式セッションから約1分ごとに確認するブラウザー用モニターです。円とバーで現在枠・週間枠を見渡し、変化履歴を各枠最大10,000件まで端末内に保持します。日本語／英語、標準／ダーク、フルスクリーン、通常小窓、対応ブラウザーでの最前面表示に対応します。

今回のβ版では、3サービスの表示・非表示と順序を保存し、表示枚数に合わせてレイアウトを調整します。履歴から週間枠が現在セッションの何枠分に相当するかを推定し、期限が近いリセット権と利用枠を段階的に警告します。分析欄は高さを約半分に抑え、利用ペースの提案、公式ソース付きTips／NEWSを切り替えて表示します。通知音量のスライダー操作中も画面が動かないよう修正し、アプリアイコンを刷新しました。

[使い方](#使い方) · [詳しい仕様と制限](SPECIFICATION.md) · [デグレ防止手順](AGENTS.md) · [プライバシー](PRIVACY.md) · [更新情報をXで見る](https://x.com/ntus)

### 使い方

1. 同じChromeまたはEdgeプロファイルで [ChatGPT](https://chatgpt.com/)、[Claude](https://claude.ai/)、[Gemini](https://gemini.google.com/) に必要な分だけログインします。パスワードは公式サイトで入力します。
2. ストア公開前は、このリポジトリで `python3 build.py` を実行し、`dist/LLMs-Token-Usage-Monitor-v1.6.0.zip` を展開して、ブラウザーの拡張機能管理画面から開発用として読み込みます。一般ユーザーがデベロッパーモードなしで導入するには、Chrome Web Store / Edge Add-ons の審査・公開が必要です。
3. 拡張機能の画面、または [公開モニター](https://ai-usage-glance.ntusnog.chatgpt.site/) を開きます。公開モニターでは拡張機能IDを一度登録してください。各サービスの使用量タブを開いたままにする必要はありません。
4. 「表示サービス」からチェックと上下ボタンで表示数・順序を変更します。非表示中も取得と履歴保存は続きます。音、テーマ、言語、透明度、フルスクリーンも画面上で変更できます。
5. 残量とリセット時刻は公式サービスが返す範囲で表示されます。リセット権は利用可能なら公式利用量ページへ移動できますが、アプリから自動行使しません。出典のあるTips／NEWSはリンクで原文を確認できます。

### β版の注意点

Geminiなどの契約プランは公式アカウント画面から取得できない場合があります。その場合は未取得と表示し、推測した有料プラン名は付けません。週間の「現在セッション何枠分」は十分な同期履歴があるときだけ推定表示します。ブラウザー外のOS全体での常時最前面・窓全体の透過はWeb拡張機能の機能ではありません。対応ブラウザーのDocument Picture-in-Pictureを使用します。iOS／Androidのネイティブ版は今後の設計対象で、今回のβには含みません。

## 1.5.3 の変更

- Google Oneの「現在のプラン」をアップグレード候補より優先し、Geminiと同じGoogleアカウント番号のメンバーシップ管理画面から契約プランを取得します。
- 英語モードで残っていた取得注記、リセット、補足値、期限、未取得プランの日本語を英訳します。
- フローティング画面の最上部から版番号を外し、日英どちらの製品名も横幅に合わせて1行表示します。

## 1.5.2 の変更

- 日本語／英語を切り替えられます。初回は環境言語が日本語なら日本語、それ以外は英語を選び、`🇯🇵JP`／`🌍EN`で現在のモードを表示します。
- 言語、テーマ、透明度、利用枠、リセット、クレジット、変化履歴をメイン画面、通常小窓、最前面表示、AIサイト内パネルで同期します。
- 通常小窓と最前面表示を約180〜190px幅へ縮小し、幅に応じて文字を調整しながらメイン画面と同じ情報を縦スクロールで表示します。
- メイン画面の再読み込み時は通常小窓も再読み込みし、メイン画面を閉じた場合は連動して通常小窓を閉じます。
- 通常小窓のタイトルを選択言語の製品名へ統一し、透明度変更が小窓の背景とカードへ即時反映されるようにしました。
- フルスクリーン時のサービス名、プラン、利用枠、履歴、操作部品の文字を拡大しました。

## 1.5.1 の変更

- Geminiの契約プランをGeminiの契約情報、アカウント状態RPC、Google Oneの現在契約画面から多段取得します。複数Googleアカウントの `/u/0`〜`/u/4` に対応し、広告だけのプラン名は採用しません。
- 変化履歴を利用枠ごとに最大10,000件保存し、起動時に保存済み履歴を復元します。画面には取得期間・件数・読込と分析の所要時間を表示します。
- 起動時は全履歴から直近10,000件を3秒以内で選び、同じ履歴を画面表示と利用ペース分析へ使用します。
- フルスクリーンでも各サービスの変化履歴テキストボックスを表示します。
- 公開画面とインストール済み拡張機能の版が異なる場合は、接続欄に更新警告と双方の版番号を表示します。
- 公開画面のJavaScriptとCSSには版番号を付け、ブラウザーキャッシュに旧ロジックが残らないようにします。
- v1.5.1へ更新しても既存の保存履歴は削除しません。旧版がすでに上限超過分を削除していた場合、その削除済みデータだけは復元できません。

## 1.5.0 の変更

- これまでの全要件を `spec/requirements.json` の単一要件台帳と [詳細仕様書](SPECIFICATION.md) に固定し、版番号、証跡、受入条件を自動検査するようにしました。
- ログアウト後も利用枠ごとの変化履歴を最大1,000件保持し、再ログイン後の初回値を新しい基準として追加します。
- APIと公式画面の補助データを取得元別に統合し、一方だけが取得できたプラン、枠、期限、クレジットを別の更新で消さないようにしました。
- Geminiは既定アカウントと `/u/0`〜`/u/4` の公式ページ、RPC、契約画面を探索し、アップグレード広告を契約中プランと誤認しない検証を追加しました。
- Claudeのクラウドセッションクレジット、追加使用クレジット、プロジェクトセットアップクレジットの残率・残額・総額・期限処理を補強しました。
- 通知音をバックグラウンドのOffscreen Documentで再生し、1回の更新で複数値が変化しても1秒間隔の3音だけに集約しました。
- 対応ブラウザではDocument Picture-in-Pictureによる最前面表示へ切り替えられます。起動時は通常小窓を1つだけ開き、PiP開始時に通常小窓を閉じます。
- 本番拡張機能の外部接続先を公開モニターのHTTPS originだけに限定し、公開プライバシーページを追加しました。

## 1.4.1 の変更

- アドバイスを画面下部の横幅ほぼ一杯に収まる1行ティッカーへ変更しました。
- ChatGPTのリセット権期限を更新間で保持し、7日以内の警告と利用先リンクを表示します。
- Geminiの公式ページ・埋め込みデータ・契約画面からプランを多段取得します。
- 2時間未満のリセット時間を赤色警告し、接続表示を1行へ圧縮しました。
- 変化履歴の保存上限を利用枠ごとに1000件へ拡張し、起動時にも既存履歴を維持します。

## 1.4.0 の変更

- 最大100件の変化履歴から消費速度とリセット時残量を予測し、現在のプランを活用できているかを助言します。
- 利用枠を早く使い切る傾向では上位プラン、継続して大きく余る傾向では下位プランを比較候補として表示します。履歴不足時はプラン変更を勧めません。
- ChatGPTの利用上限リセット権について、現在残量と有効期限から「行使候補」「期限優先」「温存」を提示します。
- 助言は画面を押し下げない半透明の吹き出しで9秒ごとに切り替わり、手動送りとON/OFFに対応します。

## 1.3.5 の変更

- 保存済みデータが旧表記でも、ChatGPTの週間枠をメイン画面・履歴・フローティング表示で「週間 (Work / Codex)」へ統一します。
- ChatGPTの「利用上限のリセット」カードとAPI応答から、利用可能件数・リセット種別・有効期限を取得します。期限が7日以内なら赤色で警告します。

## 1.3.4 の変更

- 標準／ダークテーマをサイト、プレビュー、フローティング小窓、各AIサイト上の半透明パネルで同期します。
- Geminiの契約名取得先にログイン中アカウントのサブスクリプション画面を追加しました。
- Claudeの未使用セッションは「最初のメッセージから開始します」と表示します。
- Claudeのクラウドセッションクレジット枠から残額・総額・期限・残率を取得し、横棒グラフを表示します。
- ChatGPTの週間枠を「週間 (Work / Codex)」へ変更しました。

## 1.3.3 の変更

- 標準モードを落ち着いたニュートラル配色へ刷新し、文字・境界・操作部品のコントラストを統一しました。
- Geminiの契約名を使用量API応答、旧称のGoogle One AI Premium、Gemini Advancedからも判定します。
- ChatGPTの利用枠リセットに加え、取得できる場合は利用権期限を表示します。7日以内は赤色で警告します。
- Claudeのクラウドセッションクレジットは残量・総額・期限を表示し、組織名の注記を削除しました。

## 1.3.2 の変更

- 現在セッションの残量を円形ゲージと横棒グラフの両方で表示し、全画面でもバーを常時表示します。
- 円内にリセット日時と「あと何時間・何分」を表示します。
- Claude／Geminiの契約プラン解析を補強し、一時的な未取得時も既知の契約名を保持します。
- 履歴には起動後の初回値を記録し、以後は数値が変化した場合だけ追加します。
- ChatGPTのサービスアイコンを枠の中央へ配置しました。

## 1.3.1 の変更

- 各サービスの円形ゲージを約2倍の直径に拡大し、残量数値も合わせて大きくしました。
- 全画面表示では画面高に応じて直径を調整し、ページ全体をスクロールせず確認できます。

## 1.3.0 の変更

- 円形ゲージの数値を大きくし、離れた位置からも読みやすくしました。
- 履歴は残量が変わった時だけ記録し、利用枠ごとに1000件保存します。
- ChatGPTは公式ページの `client-bootstrap` にある契約情報からPlus／Proなどを取得します。
- 3サービスをログイン中の公式セッションからバックグラウンド取得し、使用量タブの常駐を不要にしました。
- ブラウザ起動時に専用フローティング小窓を開きます。サイト内パネルのぼかしを抑え、15〜100%の透明度が見た目へ反映されます。
- 全画面表示では監視カードだけを画面内へ収め、ページ全体のスクロールをなくしました。
- 配布ファイル名を `LLMs-Token-Usage-Monitor-v1.3.0.zip` に変更しました。

## 1.2.0 の変更

- ChatGPT / Claude / Gemini の契約プランを公式画面から取得してサービス名の下に表示します。
- 各利用枠の取得履歴を日時と残り使用量の形式で最大1000件、端末内に保存します。
- フルスクリーンと標準・ダークテーマの切替を追加しました。
- 小型パネルの背景透明度を15〜100%で調整でき、背後の画面が自然に透けます。

## 1.1.0 の変更

- 残量が変化した利用枠に、変更直前の値と取得日時（秒まで・端末のタイムゾーン）を表示。同じ値の再取得では直近の変更履歴を保持します。
- 更新中は前回値を保持してゆっくり点滅。45秒を超えた場合は「更新待ち（前回値）」に切り替えます。端末でアニメーション抑制を指定している場合は薄色のみです。
- Claudeのクラウドセッションクレジット、プロジェクトセットアップクレジット、使用クレジットを下部に追加。取得可能な金額・残率・期限を表示。Web画面で金額を確認できない場合は「未取得」とします。
- 更新するには最新ZIPを展開し、既存の拡張機能フォルダのファイルを置き換えて、拡張機能管理画面の「再読み込み」を押してください。各AIサイトとモニターも再読み込みしてください。

OSに依存しない静的Webアプリと、Chrome / Edgeデスクトップ用Manifest V3拡張機能です。Safari、Firefox、モバイルブラウザへの対応は未検証です。

## 使い方

1. Chrome Web StoreまたはMicrosoft Edge Add-onsで審査公開された拡張機能を追加します。ストア公開前のZIPは審査提出・動作確認用です。
2. ChatGPT・Claude・Geminiの公式サイトへ普段のブラウザプロファイルでログインします。モニタにパスワードを入力する画面はありません。
3. ツールバーの「LLMs トークン残量モニタ」を開きます。以後は60秒ごとにバックグラウンド取得し、専用タブを開いたままにする必要はありません。
4. 各AIサイト上の半透明パネル、起動時のフローティング小窓、またはメインモニタで残量を確認します。
5. 常に手前へ置く場合はメイン画面の「最前面に固定」を押します。ブラウザの制約によりユーザー操作が必要で、元のモニター画面を閉じると終了します。

ホストされたWebアプリは、拡張機能の詳細画面にある32文字のIDを入力すると接続できます。拡張機能に内蔵したモニターはID入力不要・ネット接続なしでも起動できます。取得には各サービスへの通信が必要です。

## 表示と制約

- Claude: 現在のセッション・週間の使用済み率から残量を算出。製品別内訳や追加クレジットは混ぜません。
- Gemini: 公式使用量ページの現在・週間の使用率から残量を算出。
- ChatGPT: 現時点で確認した公式使用量ページは通常Chatを含みません。表示できるのは **Work / Codex等の共通利用枠** です。「通常のChat：取得不可」と明記します。Chatの正確な残量は未実装・取得未確認です。
- 数値がない場合は「—」。更新中・取得失敗時は前回取得値を保持し、ログアウト時は数値を消去。125秒以上経過すると「更新待ち」を表示します。
- 常駐パネルは対象3サイトのページ内で半透明表示されます。背景不透明度は15〜100%です。通常小窓およびPiPのウィンドウ自体は、OSデスクトップを透過するネイティブオーバーレイではありません。
- 起動時の通常小窓はOSの常時最前面ではありません。対応Chrome/Edgeでは、ユーザーが「最前面に固定」を押した後にDocument Picture-in-Pictureへ切り替えます。
- 複数アカウントの合算はしません。各公式サービスで現在選択されているアカウントが対象です。アカウント切り替え後は「今すぐ更新」を押してください。
- 公式DOM構造を読むため、サービス側の変更で修正が必要になることがあります。

## データ・権限

パスワードは読み取りません。ChatGPTの使用量取得では、公式ページが現在のログインに使っているアクセストークンを取得処理中のメモリ内だけで利用し、保存・ログ出力・第三者送信をしません。ClaudeとGeminiも現在の公式ログインセッションを使います。取得対象は契約名・利用枠・残率・リセット時刻・関連クレジットです。使用量・履歴・表示設定はブラウザのlocalストレージだけに保存し、運営サーバーへアップロードしません。送信・購入操作は自動実行しません。

拡張機能に対する3サイトの閲覧権限は、ログイン中の公式セッションで使用量を取得するために必要です。ブラウザ再起動時は前回値をすぐ表示し、その後バックグラウンド更新します。

## 開発

- `python3 -m http.server 4173 --directory dist` でローカルWeb版の表示を確認できます。本番Manifestは安全のためlocalhostからの外部接続を許可しないので、実データ接続は拡張機能内蔵画面か公開HTTPS版で検証します。
- `node --test tests/*.test.cjs` で残量パーサーを検証。
- `python3 build.py` で共通ファイルを拡張機能に複製し、配布ZIPを更新。
- `dist/` が静的Web配布物。`extension/` が読み込み可能な拡張機能。

実装契約、取得経路、データモデル、手動検証項目は [SPECIFICATION.md](SPECIFICATION.md) を正本とし、機械可読の受入条件は [`spec/requirements.json`](spec/requirements.json) を参照してください。公式サービスの非公開内部構造は変更され得るため、拡張機能の実アカウントでの通し動作はリリースごとに確認します。
