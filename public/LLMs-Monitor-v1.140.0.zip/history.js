(function(root){
 const LIMIT=10000,LOAD_LIMIT=10000;
 const scopeKey=value=>typeof value==='string'&&/^claude:[a-f0-9]{64}$/.test(value)?value:'';
 const aliases=label=>label==='週間 (Work / Codex)'?['週間 (Work / Codex)','Work / Codex · 週間']:label==='Work / Codex · 週間'?['Work / Codex · 週間','週間 (Work / Codex)']:[label];
 function record(history={},last={},id,windows,capturedAt){
  const next=structuredClone(history),nextLast=structuredClone(last),service=next[id]||{},baseline=nextLast[id]||{};let changed=false;
  for(const w of windows){if(typeof w.remaining!=='number'||!Number.isFinite(w.remaining))continue;const key=String(w.label).slice(0,80),keys=aliases(key),list=keys.flatMap(name=>Array.isArray(service[name])?service[name]:[]).sort((a,b)=>a.capturedAt-b.capturedAt).filter((row,index,rows)=>index===0||row.capturedAt!==rows[index-1].capturedAt||Math.round(row.remaining)!==Math.round(rows[index-1].remaining)),before=keys.map(name=>baseline[name]).find(value=>typeof value==='number');if(typeof before!=='number'||Math.round(before)!==Math.round(w.remaining)){list.push({capturedAt,remaining:w.remaining});changed=true;}service[key]=list.slice(-LIMIT);baseline[key]=w.remaining;for(const oldKey of keys.slice(1)){delete service[oldKey];delete baseline[oldKey];}}
  next[id]=service;nextLast[id]=baseline;return {history:next,last:nextLast,changed};
 }
 // Keep all pre-scope history as legacy, never assign it to the first identified account.
 function recordScoped(scopes={},lastScopes={},id,scope,windows,capturedAt){
  if(id!=='claude'||!scopeKey(scope))throw Error('Invalid history scope');
  const next=structuredClone(scopes),baselines=structuredClone(lastScopes),result=record({[id]:next[id]?.[scope]||{}},{[id]:baselines[id]?.[scope]||{}},id,windows,capturedAt);
  (next[id]??={})[scope]=result.history[id];(baselines[id]??={})[scope]=result.last[id];return {historyScopes:next,historyLastScopes:baselines,changed:result.changed};
 }
 function project(legacy={},scopes={},data={}){const result={...legacy};for(const[id,row]of Object.entries(data))if(id==='claude'&&scopeKey(row?.accountKey))result[id]=scopes[id]?.[row.accountKey]||{};return result;}
 const EXTRA_LABEL='追加使用クレジット';
 function extraValues(value){
  if(!value||typeof value!=='object'||value.unit!=='unknown')return null;
  const result={unit:'unknown'};
  for(const key of ['remaining','limit','used']){
   if(!Object.hasOwn(value,key)){if(key==='remaining')return null;continue;}
   const n=value[key];if(typeof n!=='number'||!Number.isFinite(n)||n<0||n>1e12)return null;result[key]=n;
  }
  if(result.limit!==undefined&&(result.remaining>result.limit||result.used!==undefined&&result.used>result.limit))return null;
  return result;
 }
 function extraRows(rows){return (Array.isArray(rows)?rows:[]).flatMap(row=>{const values=extraValues(row);return values&&Number.isSafeInteger(row.capturedAt)&&row.capturedAt>0?[{capturedAt:row.capturedAt,...values}]:[]}).slice(-LIMIT);}
 function recordExtraScoped(scopes={},lastScopes={},id,scope,extras,capturedAt){
  const unchanged={extraHistoryScopes:scopes,extraHistoryLastScopes:lastScopes,changed:false};
  if(id!=='claude'||!scopeKey(scope)||!Number.isSafeInteger(capturedAt)||capturedAt<=0)return unchanged;
  const matches=(Array.isArray(extras)?extras:[]).filter(e=>e?.label===EXTRA_LABEL);
  if(matches.length!==1||matches[0].dataSource!=='claude-usage-extra_usage'||matches[0].unit!=='unknown')return unchanged;
  const values=extraValues({...matches[0].rawValues,unit:matches[0].unit});if(!values)return unchanged;
  const rows=extraRows(scopes[id]?.[scope]?.[EXTRA_LABEL]),last=rows.at(-1),before=extraValues(lastScopes[id]?.[scope]?.[EXTRA_LABEL])||last;
  if(last&&capturedAt<=last.capturedAt||before&&['remaining','limit','used'].every(key=>before[key]===values[key]))return unchanged;
  const next=structuredClone(scopes),baselines=structuredClone(lastScopes);
  ((next[id]??={})[scope]??={})[EXTRA_LABEL]=[...rows,{capturedAt,...values}].slice(-LIMIT);
  ((baselines[id]??={})[scope]??={})[EXTRA_LABEL]=values;
  return {extraHistoryScopes:next,extraHistoryLastScopes:baselines,changed:true};
 }
 function projectExtra(scopes={},data={}){
  const scope=scopeKey(data.claude?.accountKey);if(!scope)return {};
  const rows=extraRows(scopes.claude?.[scope]?.[EXTRA_LABEL]);return {claude:rows.length?{[EXTRA_LABEL]:rows}:{}};
 }
 function view(history={},options={}){
  const limit=Math.max(1,Number(options.limit)||LOAD_LIMIT),budgetMs=Math.max(1,Number(options.budgetMs)||2600),clock=typeof options.clock==='function'?options.clock:()=>typeof performance!=='undefined'&&performance.now?performance.now():Date.now(),started=clock(),all=[];
  for(const [service,groups]of Object.entries(history||{}))for(const [label,rows]of Object.entries(groups||{}))for(const row of Array.isArray(rows)?rows:[]){const capturedAt=Number(row?.capturedAt),remaining=Number(row?.remaining);if(Number.isFinite(capturedAt)&&Number.isFinite(remaining))all.push({service,label,capturedAt,remaining});}
  all.sort((a,b)=>b.capturedAt-a.capturedAt);const selected=[];for(const row of all){if(selected.length>=limit)break;if(selected.length&&clock()-started>=budgetMs)break;selected.push(row);}
  const output={};for(const row of selected.reverse()){const groups=output[row.service]||(output[row.service]={}),rows=groups[row.label]||(groups[row.label]=[]);rows.push({capturedAt:row.capturedAt,remaining:row.remaining});}
  const times=selected.map(row=>row.capturedAt),elapsedMs=Math.max(0,Math.round(clock()-started));return {history:output,meta:{total:all.length,loaded:selected.length,firstAt:times.length?Math.min(...times):null,lastAt:times.length?Math.max(...times):null,truncated:selected.length<all.length,elapsedMs,limit,budgetMs}};
 }
 root.GlanceHistory={record,recordScoped,recordExtraScoped,projectExtra,project,scopeKey,view,LIMIT,LOAD_LIMIT};if(typeof module!=='undefined')module.exports=root.GlanceHistory;
})(globalThis);
