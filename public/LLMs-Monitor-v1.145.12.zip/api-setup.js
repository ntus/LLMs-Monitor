(()=>{
 const select=selector=>document.querySelector('#setup-api '+(selector.startsWith('#')?'#api-'+selector.slice(1):selector))||document.querySelector(selector);
const A=GlanceApiCredits,L=GlanceLocale,text=(ja,en)=>L.language()==='ja'?ja:en;
async function paint(){
 const state=await chrome.runtime.sendMessage({type:'GET'});L.setLanguage(state.settings?.language||L.detect());document.documentElement.lang=L.language();document.documentElement.dataset.theme=state.settings?.theme||'dark';if(!document.getElementById('setup-title'))document.title=L.t('appTitle')+' · API';select('h1').textContent=text('APIクレジット連携','API credit connections');select('#api-help').textContent=text('月額プランとは別のAPI残高です。各社の請求画面へのアクセスを個別に許可すると、ログイン中の画面の表示値を60秒ごとに読み取ります。Claudeはログイン済みなら公式の残高データを直接読み、画面の表示・切替は不要です。OpenAIはモニターと同じ通常窓の裏タブを1つ再利用して更新し、前面には切り替えません。Gemini・Grok APIは請求画面を開いておく必要があります。パスワード・APIキー・決済情報は保存せず、購入や設定変更は行いません。後払い・未取得・複数残高を合算して0円や推定残高にしません。','API balances are separate from monthly plan limits. Grant access to each official billing site individually to read its signed-in display every 60 seconds. Claude reads official balance data directly when signed in; no page needs to be displayed or activated. OpenAI reuses one background billing tab in the monitor’s normal window without bringing it forward. Keep Gemini and Grok API billing pages open. Passwords, API keys and payment details are not saved; no purchases or billing changes are made. Postpaid, missing or multiple balances are never treated as zero or estimated.');
 const payments=await chrome.permissions.contains({origins:[A.GEMINI_PAYMENTS]});
 select('#api-providers').innerHTML=Object.entries(A.PROVIDERS).map(([id,p])=>{const on=state.apiCredits?.[id]?.enabled;return `<section><h2>${p.name}</h2><div>${A.view(id)}</div><div class="api-setup-actions"><button type="button" data-enable="${id}" data-on="${on?'true':'false'}">${on?text('連携を解除','Disconnect'):text('アクセスを許可して連携','Allow access and connect')}</button><a href="${p.url}" target="_blank" rel="noopener noreferrer">${text('公式請求画面を開く','Open official billing')} ↗</a>${id==='gemini'&&on&&!payments?`<button type="button" data-gemini-payments>${text('Google決済の残高読取りを許可','Allow the Google payments balance reader')}</button>`:''}${id==='claude'?`<button type="button" data-credit-observation-export>${text('Gateway参考JSONを書き出す','Export Gateway reference JSON')}</button><small>${text('利用者操作時のみ端末へ保存。参考表示専用・費用許可には使用不可。自動送信はしません。','Saved locally only when clicked. Reference only; never spending authorization. No automatic delivery.')}</small>`:''}</div></section>`}).join('');select('#api-back').textContent=L.t('appTitle')+' ↗';
}
select('#api-providers').addEventListener('click',async event=>{
 if(event.target.closest('[data-gemini-payments]')){
  try{
   if(!await chrome.permissions.request({origins:[A.GEMINI_PAYMENTS]}))return;
   await paint();
   select('#api-result').textContent=text('Google決済の読取りを許可しました。次の自動取得後に公式請求画面を再読み込みしてください。','Google payments access enabled. Reload the official billing page after the next automatic read.');
  }catch{select('#api-result').textContent=text('Google決済の読取りを許可できませんでした。','Could not allow Google payments access.')}
  return;
 }
 if(event.target.closest('[data-credit-observation-export]')){try{if(location.protocol!=='chrome-extension:'||window.top!==window)throw Error('Own extension page required');const current=await chrome.runtime.sendMessage({type:'GET'}),value=GlanceCreditObservation.create(current.apiCredits?.claude,chrome.runtime.getManifest().version),url=URL.createObjectURL(new Blob([JSON.stringify(value,null,2)+'\n'],{type:'application/json'})),link=document.createElement('a');link.href=url;link.download='LLMs-Monitor-credit-observation-'+value.generatedAt.replace(/[:.]/g,'-')+'.json';document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);select('#api-result').textContent=text('参考JSONを保存しました。取得失敗・古い値・期限不明も記録されます。費用許可には使用できません。','Reference JSON saved, including failed reads, stale values and unknown expiry. Never use it as spending authorization.');}catch{select('#api-result').textContent=text('JSONを書き出せませんでした。拡張機能の設定画面で再試行してください。','Could not export JSON. Retry in the extension setup page.');}return;}
 const button=event.target.closest('[data-enable]');if(!button)return;const id=button.dataset.enable,on=button.dataset.on==='true',origins=[A.PROVIDERS[id].origin+'/*'];
 try{
  // Request must be the first asynchronous operation in the user click, preserving user activation.
  if(!on&&!await chrome.permissions.request({permissions:['scripting'],origins}))return;
  button.disabled=true;const result=await chrome.runtime.sendMessage({type:'API_CREDITS_CONFIGURE',service:id,enabled:!on});if(result.error)throw Error(result.error);
  if(on&&id==='gemini')await chrome.permissions.remove({origins:[A.GEMINI_PAYMENTS]});
  if(on&&!(id==='grok'&&(await chrome.runtime.sendMessage({type:'GET'})).additionalServices?.grok?.enabled))await chrome.permissions.remove({origins});
  A.set((await chrome.runtime.sendMessage({type:'GET'})).apiCredits);await paint();select('#api-result').textContent=text(on?'連携を解除しました':['claude','chatgpt'].includes(id)?'連携を有効化しました。ログイン済みなら自動取得します。未取得の場合は公式請求画面でログインを確認してください。':'連携を有効化しました。公式請求画面を開いて残高を取得してください',on?'Disconnected':['claude','chatgpt'].includes(id)?'Connected. Automatic reading starts when signed in. If unavailable, check sign-in on official billing.':'Connected. Open the official billing page to read the balance');
 }catch{button.disabled=false;select('#api-result').textContent=text('連携できませんでした。権限と拡張機能を確認してください','Connection failed. Check permissions and the extension')}
});
chrome.runtime.sendMessage({type:'GET'}).then(state=>{A.set(state.apiCredits);return paint()});

})();
