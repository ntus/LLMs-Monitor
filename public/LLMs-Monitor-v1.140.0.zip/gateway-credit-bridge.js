/* Independent optional local money-observation grant. Never an execution grant. */
(function(root){'use strict';
const HOST='info.ntus.llms_gateway.credit',SCHEMA='monitor-gateway-credit.v1',KEY='llms-gateway-credit-link-v1';
const UUID=/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i;
const statuses=new Set(['ready','granted','accepted','consent-required','disconnected','revoked','denied','unavailable','invalid-request']);
function create(browser,model,{now=()=>Date.now(),uuid=()=>root.crypto.randomUUID(),schedule=setTimeout,cancel=clearTimeout}={}){
 let config={enabled:false,providers:[],sequence:0},loaded=false,loading=null,generation=0,port=null,queue=Promise.resolve(),timer=null,working=false,dirty=false,state='disconnected',lastReceivedAt=null;
 const serial=fn=>{const p=queue.then(fn);queue=p.catch(()=>{});return p;};
 const view=()=>({enabled:config.enabled,providers:[...config.providers],state,lastReceivedAt,accountVerified:false,executionAllowed:false,spendingAllowed:false});
 function grant(g){if(!g||!UUID.test(g.id)||!Number.isSafeInteger(g.epoch)||g.epoch<1||g.scope!=='api-credit-observations'||g.continuity!=='until-disconnected')throw Error('invalid-grant');return {id:g.id,epoch:g.epoch,providers:model.selection(g.providers)};}
 function same(ids){return JSON.stringify(model.selection(ids))===JSON.stringify(config.providers);}
 async function save(){await browser.storage.local.set({[KEY]:config});}
 async function load(){if(loaded)return;if(loading)return loading;loading=(async()=>{const s=(await browser.storage.local.get(KEY))[KEY];try{if(s?.enabled===true){const g=grant({...s,scope:'api-credit-observations',continuity:'until-disconnected'});if(!Number.isSafeInteger(s.sequence)||s.sequence<0)throw Error('invalid-sequence');config={enabled:true,providers:g.providers,id:g.id,epoch:g.epoch,sequence:s.sequence};state='unavailable';}}catch{state='invalid-local-state';}loaded=true;})();try{await loading;}finally{loading=null;}}
 async function call(op,fields,epoch){
  if(!await browser.permissions.contains({permissions:['nativeMessaging']}))throw Error('permission-required');if(epoch!==generation)throw Error('cancelled');
  const request={schema:SCHEMA,op,request_id:uuid(),...fields};if(JSON.stringify(request).length>65536||request.observations&&JSON.stringify(request.observations).length>55000)throw Error('payload-too-large');
  return new Promise((resolve,reject)=>{let done=false,p;
   const finish=(raw,error)=>{if(done)return;done=true;cancel(timeout);try{p?.disconnect();}catch{}if(port===p)port=null;if(epoch!==generation)return reject(Error('cancelled'));if(error)return reject(Error(error));try{if(!raw||typeof raw!=='object'||Array.isArray(raw)||JSON.stringify(raw).length>8192||raw.schema!==SCHEMA||raw.request_id!==request.request_id||raw.op!==op||!statuses.has(raw.status)||raw.status==='accepted'&&(op!=='publish'||raw.sequence!==request.sequence)||op==='publish'&&raw.status==='granted')throw Error('invalid-response');resolve({status:raw.status,...(raw.status==='granted'?{grant:grant(raw.grant)}:{})});}catch(e){reject(e);}};
   const timeout=schedule(()=>finish(null,'timeout'),6000);
   try{p=browser.runtime.connectNative(HOST);port=p;p.onMessage.addListener(r=>finish(r));p.onDisconnect.addListener(()=>{void browser.runtime.lastError;finish(null,'host-unavailable');});p.postMessage(request);}catch{finish(null,'host-unavailable');}
  });
 }
 async function stop(stateValue='disconnected'){const cursor=UUID.test(config.id||'')?{id:config.id,epoch:config.epoch,sequence:config.sequence}:{sequence:0};config={enabled:false,providers:[],...cursor};state=stateValue;lastReceivedAt=null;await save();}
 async function publish(epoch=generation){await load();if(!config.enabled||epoch!==generation)return view();try{
  const r=await call('status',{},epoch);
  if(r.status!=='granted'){await stop(r.status);return view();}
  if(r.grant.id!==config.id||r.grant.epoch!==config.epoch||!same(r.grant.providers)){await stop('grant-changed');return view();}
  const data=(await browser.storage.local.get('apiCredits')).apiCredits||{};if(epoch!==generation||!config.enabled)return view();
  if(config.sequence>=Number.MAX_SAFE_INTEGER)throw Error('sequence-exhausted');
  config={...config,sequence:config.sequence+1};await save();if(epoch!==generation||!config.enabled)return view();
  const result=await call('publish',{grant_id:config.id,epoch:config.epoch,sequence:config.sequence,observations:model.create(data,config.providers,now())},epoch);
  if(result.status==='accepted'){
   state='granted';lastReceivedAt=now();
  }else await stop(result.status);
 }catch(e){if(epoch===generation)state=['permission-required','timeout','payload-too-large','sequence-exhausted','invalid-response','invalid-grant'].includes(e.message)?e.message:'host-unavailable';}return view();}
 function changed(){if(!config.enabled)return;if(working){dirty=true;return;}if(timer!==null)cancel(timer);const epoch=generation;timer=schedule(()=>{timer=null;working=true;dirty=false;serial(()=>publish(epoch)).catch(()=>{}).finally(()=>{working=false;if(dirty&&epoch===generation){dirty=false;changed();}});},1000);}
 async function disconnect(){await load();const old=config,epoch=++generation;if(timer!==null)cancel(timer);timer=null;dirty=false;try{port?.disconnect();}catch{}port=null;await stop();if(old.id)try{const r=await call('disconnect',{grant_id:old.id,epoch:old.epoch},epoch);if(epoch===generation&&r.status!=='disconnected')state='disconnect-unconfirmed';}catch{if(epoch===generation)state='disconnect-unconfirmed';}return view();}
 const allowed=(sender,external)=>!external&&sender?.id===browser.runtime.id&&sender.frameId===0&&sender.url===browser.runtime.getURL('gateway-credit-setup.html');
 async function handle(message,sender,external=false){if(!allowed(sender,external))return {error:'not-allowed'};if(message?.type==='GATEWAY_CREDIT_DISCONNECT')return disconnect();const epoch=generation;return serial(async()=>{
  await load();if(epoch!==generation)return view();
  if(message.type==='GATEWAY_CREDIT_STATUS')return view();
  if(message.type==='GATEWAY_CREDIT_CONNECT'){
   if(config.enabled)return {error:'disconnect-first'};
   try{const providers=model.selection(message.providers),prior=(await browser.storage.local.get(KEY))[KEY];config={enabled:false,providers,sequence:0};state='consent-required';await save();
    // status only discovers a separately approved grant. It must not mint consent.
    const r=await call('status',{},epoch);
    if(r.status!=='granted'){state=r.status;return view();}
    if(!same(r.grant.providers)){state='selection-mismatch';return view();}
    const sequence=prior?.id===r.grant.id&&prior?.epoch===r.grant.epoch&&Number.isSafeInteger(prior.sequence)&&prior.sequence>=0?prior.sequence:0;
    config={enabled:true,providers,id:r.grant.id,epoch:r.grant.epoch,sequence};await save();if(epoch!==generation){await stop();return view();}return publish(epoch);
   }catch(e){if(epoch===generation)state=e.message==='invalid-selection'?'selection-required':['permission-required','timeout','invalid-response','invalid-grant'].includes(e.message)?e.message:'host-unavailable';return view();}
  }
  if(message.type==='GATEWAY_CREDIT_CHECK')return config.enabled?publish(epoch):view();
  return {error:'unsupported-operation'};
 });}
 browser.storage.onChanged?.addListener((changes,area)=>{if(area==='local'&&changes.apiCredits)changed();});
 browser.permissions?.onRemoved?.addListener(p=>{if(p.permissions?.includes('nativeMessaging'))disconnect().catch(()=>{});});
 return {handle,allowed,disconnect,changed,resume:async()=>{await load();return config.enabled?serial(()=>publish()):view();}};
}
const api={HOST,SCHEMA,KEY,create};if(typeof module!=='undefined')module.exports=api;else root.LLMGatewayCreditBridge=create(root.chrome,root.GlanceCreditObservationsV2);
})(globalThis);
