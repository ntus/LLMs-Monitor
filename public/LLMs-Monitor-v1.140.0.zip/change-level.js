(function(root){
 function changeLevel(old={},next={}){
  if(!old.capturedAt||next.status!=='ready')return '';
  let changed=false,level='normal',recovered=false;
  for(const item of next.windows||[]){
   const before=old.windows?.find(row=>row.label===item.label);
   if(!before||typeof before.remaining!=='number'||typeof item.remaining!=='number')continue;
   if(before.remaining===0&&item.remaining>0&&(!before.conflict)&&(!item.conflict))recovered=true;
   // Notify only when the integer percentage shown in the UI changes.
   if(Math.round(before.remaining)===Math.round(item.remaining))continue;
   changed=true;
   if(item.remaining===0&&before.remaining>0)level='exhausted';
   else if(item.remaining<=1&&before.remaining>1&&level!=='exhausted')level='critical';
   else if(item.remaining<=5&&before.remaining>5&&!['critical','exhausted'].includes(level))level='low';
  }
  return recovered&&level==='normal'?'recovered':changed?level:'';
 }
 root.GlanceChangeLevel=changeLevel;
 if(typeof module!=='undefined')module.exports=changeLevel;
})(globalThis);
