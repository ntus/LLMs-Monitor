(()=>{
 if(globalThis.llmsApiCreditReader==='1.118.0')return;globalThis.llmsApiCreditReader='1.118.0';
 const A=GlanceApiCredits;let scheduled=null,lastRead=0;
 const visible=node=>node.getClientRects().length>0;
 function nodes(selector){const roots=[document],out=[];for(let i=0;i<roots.length&&i<20;i++){const r=roots[i];out.push(...[...r.querySelectorAll(selector)].slice(0,6000-out.length));if(out.length>=6000)break;for(const n of [...r.querySelectorAll('*')].slice(0,6000))if(n.shadowRoot&&!roots.includes(n.shadowRoot)&&roots.length<20)roots.push(n.shadowRoot);}return out;}
 function scope(){
  const scopeNodes=nodes('button,[role="combobox"],[aria-current="true"]').filter(visible),selected=scopeNodes.map(n=>(n.innerText||'').trim()).filter(s=>/(?:Organization|Billing account|請求先アカウント|組織)/i.test(s)&&s.length<160).join('|');
  if(!selected)return '';let hash=2166136261;for(const c of selected)hash=Math.imul(hash^c.charCodeAt(0),16777619);return (hash>>>0).toString(16).padStart(8,'0');
 }
 async function read(){
  if(globalThis.llmsApiCreditReader!=='1.118.0')return;const id=A.provider(location.href);if(!id||Date.now()-lastRead<1500)return;lastRead=Date.now();
  const candidates=nodes('h1,h2,h3,h4,h5,p,span,div,label,dt,dd').filter(visible),p=A.PROVIDERS[id],labelled=n=>p.labels.test((n.innerText||'').trim())||(id==='gemini'&&/^(?:Credit balance|Available credits|Prepay credit balance|Prepaid credit balance|クレジット残高|利用可能なクレジット|前払いクレジット残高)\s*[:：]?\s*(?:[$€¥£￥]|USD|EUR|JPY|GBP)/i.test((n.innerText||'').trim())&&A.parse(n.innerText,id).status==='ready'),matches=candidates.filter(n=>labelled(n)&&![...n.children].some(labelled)),values=[];let relevantBusy=false;
  for(const node of matches){let parent=node;for(let depth=0;parent&&depth<(id==='gemini'?8:4);depth++,parent=parent.parentElement||parent.getRootNode?.().host){const text=parent.innerText||'';if(text.length>1200)break;const parsed=A.parse(text,id);if(parsed.status==='ready'){const expiry=A.parseExpiry(text);values.push(expiry?{...parsed,expiresAt:expiry}:parsed);if(node.closest?.('[aria-busy="true"]'))relevantBusy=true;break}}}
  let result=matches.length===1&&values.length===1?values[0]:{status:'unavailable'};
  if(!matches.length){const text=document.body.innerText.slice(0,24000);result=A.parse(text,id);if(/(?:^|\n)(?:Sign in|Log in|Continue with Google|ログイン|Googleで続行)(?:\n|$)/i.test(text))result={status:'login'};if(id==='gemini'&&result.status==='ready')relevantBusy=nodes('[aria-busy="true"]').some(n=>visible(n)&&A.parse(n.innerText||'',id).status==='ready');}
  if(id==='chatgpt'&&result.status==='ready'&&matches.length===1){
   // Only bounded ancestors of the single verified balance label; never body, chat or forms.
   let parent=matches[0];for(let depth=0;parent&&parent!==document.body&&parent!==document.documentElement&&depth<7;depth++,parent=parent.parentElement){const text=parent.innerText||'';if(text.length>3200)break;if(parent.querySelector?.('input,textarea,[contenteditable="true"]'))break;const same=A.parse(text,id);if(same.status!=='ready'||same.amount!==result.amount||same.currency!==result.currency)continue;const next=A.parseNextExpiry(text,id,result);if(next){result={...result,nextExpiry:next};break;}}
  }
  if(id==='claude')result={...result,promotional:result.status==='login'?{status:'unavailable'}:A.promotional(document.body.innerText.slice(0,24000))};
  // Do not transmit page text, account names, API keys, credentials or payment details.
  try{await chrome.runtime.sendMessage({type:'API_CREDIT_SNAPSHOT',readerVersion:'1.61.0',balanceReaderVersion:'1.64.0',expiryReaderVersion:'1.118.0',service:id,...(id==='gemini'?{geminiReaderVersion:'1.82.0'}:{}),...result,scope:scope(),loading:document.readyState==='loading'||(id==='gemini'?relevantBusy:nodes('[aria-busy="true"]').some(visible))})}catch{}
 }
 chrome.runtime.onMessage.addListener((message,_,reply)=>{if(!['API_CREDIT_READ','API_CREDIT_READ_182'].includes(message?.type))return false;if(message.readerRules)globalThis.GlanceReaderRules?.install(message.readerRules);lastRead=0;read().then(()=>reply({ready:true,version:'1.61.0',balanceReaderVersion:'1.64.0',expiryReaderVersion:'1.118.0',geminiReaderVersion:'1.82.0'}),()=>reply({ready:false}));return true});
 const observer=new MutationObserver(()=>{if(scheduled!==null)return;scheduled=setTimeout(async()=>{try{await read()}catch{}finally{scheduled=null}},15000)});observer.observe(document.body,{subtree:true,childList:true,characterData:true});setTimeout(read,1500);setInterval(read,60000);
})();
