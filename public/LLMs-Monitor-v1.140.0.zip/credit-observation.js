/* Advisory-only, explicit export model. Never copies the source snapshot wholesale. */
(function(root){
 const SCHEMA='monitor.credit-observation.v1',TTL=125000,MAX_TIME=8640000000000000;
 const time=n=>Number.isSafeInteger(n)&&n>0&&n<=MAX_TIME;
 const iso=n=>time(n)?new Date(n).toISOString():null;
 const currency=v=>['USD','EUR','JPY','GBP'].includes(v);
 function decimal(n){const s=String(n);if(!/[eE]/.test(s))return s;const [co,ex]=s.toLowerCase().split('e'),negative=co.startsWith('-'),body=negative?co.slice(1):co,[a,b='']=body.split('.'),digits=a+b,pos=a.length+Number(ex);return (negative?'-':'')+(pos<=0?'0.'+'0'.repeat(-pos)+digits:pos>=digits.length?digits+'0'.repeat(pos-digits.length):digits.slice(0,pos)+'.'+digits.slice(pos));}
 function create(row={},version='',now=Date.now()){
  if(!time(now))throw Error('Invalid export time');row=row&&typeof row==='object'&&!Array.isArray(row)?row:{};
  const enabled=row.enabled===true,a=row.acquisition||{},stage=a.stage,attemptAt=time(a.at)&&a.at<=now?a.at:null;
  const failure=['login','rate-limited','ambiguous','no-api-organization','format','timeout','http','transport'].some(code=>stage==='console-'+code);
  const attemptStatus=!enabled?'unknown':attemptAt&&a.status==='ready'&&stage==='console-api'?'success':attemptAt&&failure?'failed':'unknown';
  function lane(v={}){
   v=v&&typeof v==='object'&&!Array.isArray(v)?v:{};
   const observed=time(v.capturedAt)&&v.capturedAt<=now?v.capturedAt:null,valid=v.status==='ready'&&typeof v.amount==='number'&&Number.isFinite(v.amount)&&Math.abs(v.amount)<=1e9&&currency(v.currency),expiry=time(v.expiresAt)?v.expiresAt:null;
   let status='unknown',reason='unavailable';
   if(!enabled){status='disabled';reason='connection-disabled'}
   else if(valid&&observed){
    if(expiry&&expiry<=now){status='expired';reason='expired'}
    else if(now-observed>TTL){status='stale';reason='observation-too-old'}
    else if(attemptStatus!=='success'||attemptAt!==observed){status='stale';reason='latest-success-not-confirmed'}
    else {status='ready';reason='fresh-observation'}
   }else if(time(v.capturedAt)&&v.capturedAt>now)reason='future-observation';
   return {status,reason,amountDecimal:enabled&&valid&&observed?decimal(v.amount):null,currency:enabled&&valid&&observed?v.currency:null,observedAt:enabled?iso(observed):null,expiresAt:enabled?iso(expiry):null,expiryStatus:!enabled||!expiry?'unknown':expiry<=now?'expired':'known'};
  }
  const purchased=lane(row),promotional=lane(row.promotional);
  // v1 has no per-grant contract: never export an aggregate as a single-expiry grant.
  if(enabled&&Array.isArray(row.promotional?.grants)&&row.promotional.grants.length>1)Object.assign(promotional,{status:'unknown',reason:'multiple-grants-not-supported',amountDecimal:null,currency:null,expiresAt:null,expiryStatus:'unknown'});
  // Negative promotional balances are not accepted by the current official adapter.
  if(promotional.amountDecimal?.startsWith('-'))Object.assign(promotional,{status:'unknown',reason:'invalid-promotional-balance',amountDecimal:null,currency:null});
  return {schemaVersion:SCHEMA,producer:{name:'LLMs Monitor',version:/^\d+\.\d+\.\d+$/.test(version)?version:'unknown'},provider:'anthropic',product:'api',generatedAt:iso(now),sourceKind:attemptStatus==='success'?'console-session-internal-api':'unverified-cache',organization:{bindingStatus:'unverified'},enabled,lastAttemptAt:iso(attemptAt),latestAttemptStatus:attemptStatus,lanes:{purchased,promotional},freshness:{maxAgeMs:TTL},autoReload:{status:'unknown'},invoiceBilling:{status:'unknown'},workspaceCap:{status:'unknown'},trust:{authenticatedTransport:false,spendAuthorization:false},automaticDelivery:false};
 }
 root.GlanceCreditObservation={SCHEMA,TTL,create};if(typeof module!=='undefined')module.exports=root.GlanceCreditObservation;
})(globalThis);
