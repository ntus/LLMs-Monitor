/* Client-local official entitlement notifications. Fixed URL/text, no server upload. */
(function(root){const KEY='llms-official-notices-v1';let pending=Promise.resolve();
 function observe(extras){const run=async()=>{const e=extras?.find(r=>r.label==='Fableリセット');if(!e||!['利用可能','対象使用量なし','利用可否未確認'].includes(e.value)||!Number.isFinite(e.expiresAt)||e.expiresAt<=Date.now())return;const key='fable:'+e.expiresAt+':'+(e.value==='利用可能'?'available':'announced'),saved=(await chrome.storage.local.get(KEY))[KEY]||{};if(saved[key])return;
  // Reserve before notification to suppress reload/concurrent duplicate events.
  await chrome.storage.local.set({[KEY]:{...Object.fromEntries(Object.entries(saved).slice(-31)),[key]:true}});
  const en=(await chrome.storage.local.get('settings')).settings?.language==='en';try{await chrome.notifications.create('llms-official-fable-reset',{type:'basic',iconUrl:'icons/icon128.png',title:en?'Claude · Official Fable reset update':'Claude · Fableリセットの公式情報',message:en?(e.value==='利用可能'?'Fable reset is now available. Check its scope and expiry in Monitor.':'A Fable reset expiry was detected. Check its scope and availability in Monitor.'):(e.value==='利用可能'?'Fableリセットが利用可能になりました。対象範囲・有効期限をモニターで確認してください。':'Fableリセットの有効期限を検知しました。対象範囲・利用可否をモニターで確認してください。')});}catch{const latest=(await chrome.storage.local.get(KEY))[KEY]||{};delete latest[key];await chrome.storage.local.set({[KEY]:latest});}
 };const task=pending.then(run);pending=task.catch(()=>{});return task;}
 root.GlanceOfficialNotices={observe};if(typeof module!=='undefined')module.exports=root.GlanceOfficialNotices;
})(globalThis);
