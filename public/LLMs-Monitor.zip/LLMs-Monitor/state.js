(function(root){
 function scopeKey(value){return typeof value==='string'&&/^claude:[a-f0-9]{64}$/.test(value)?value:'';}
 function scopeChanged(old,incoming,service){return service==='claude'&&!!scopeKey(incoming?.accountKey)&&scopeKey(old?.accountKey)!==incoming.accountKey;}
 function currentLabel(label){return /現在のセッション|current session/i.test(String(label||''));}
 function claudeProtectedLabel(label){return currentLabel(label)||/^(?:週間|今週|This week|Weekly limits)$/i.test(String(label||''));}
 function expireWindows(windows=[],now=Date.now()){return windows.map(window=>window?.resetAt&&Number(window.resetAt)<=now?{...window,remaining:null,expired:true,reset:'リセット後の更新待ち',resetAt:null}:window);}
 // Read-time projection never rewrites the stored baseline or manufactures a new quota.
 function view(snapshot={},now=Date.now()) {
  let expired=false;
  const windows=(snapshot.windows||[]).map(w=>{if(w.expired||w.resetAt&&Number(w.resetAt)<=now){expired=true;return {...w,remaining:null,expired:true,reset:'リセット済み · 再取得待ち'};}return {...w};});
  const stuck=snapshot.refreshing&&now-(snapshot.refreshStartedAt||0)>=45000;
  return {...snapshot,windows,...(expired||stuck?{status:'error',refreshing:false,note:expired?'リセット済み · 新しい残量を再取得待ち。':'更新が完了していません · 前回取得値を表示しています。'}:{})};
 }
 function loading(old={},now=Date.now()) {return {...old,windows:expireWindows(old.windows,now),status:'loading',refreshing:true,refreshStartedAt:now,note:'更新中 · 前回取得値を表示しています。'};}
 function accept(old={},incoming,now=Date.now(),service='') {
  // An unscoped already-open page cannot confirm a different organization's API quota or login.
  if(service==='claude'&&scopeKey(old.accountKey)&&incoming.source==='dom'&&!scopeKey(incoming.accountKey))return {...old};
  if(incoming.status==='login')return {...incoming,...(scopeKey(old.accountKey)?{accountKey:old.accountKey}:{}),windows:[],extras:[],capturedAt:null,refreshing:false};
  if(scopeChanged(old,incoming,service)&&incoming.status!=='ready')return {...incoming,windows:[],extras:[],plan:'未取得',capturedAt:null,refreshing:false};
  if(incoming.status!=='ready')return {...old,windows:expireWindows(old.windows,now),status:'error',refreshing:false,note:'取得できませんでした · 前回取得値を表示しています。'};
  const accountChanged=scopeChanged(old,incoming,service)||!!old.accountKey&&!!incoming.accountKey&&old.accountKey!==incoming.accountKey,prior=accountChanged?{}:old,source=incoming.source||'api',origin=item=>item?._source||prior.source||'legacy';
  const receivedWindows=expireWindows(Array.isArray(incoming.windows)?incoming.windows:[],now).map(item=>({...item,_source:source})),windowInput=[...receivedWindows,...expireWindows(prior.windows||[],now).filter(oldWindow=>!(service==='claude'&&source==='api'&&incoming.windowSetComplete===true)&&origin(oldWindow)!==source&&!receivedWindows.some(w=>w.label===oldWindow.label))];
  const windows=windowInput.map(w=>{const prev=prior.windows?.find(p=>p.label===w.label),resetAt=w.resetAt!=null&&Number.isFinite(Number(w.resetAt))?Number(w.resetAt):prev?.resetAt>now?prev.resetAt:null;
   // API zero needs confirmation from the official usage page for this window.
   const evidence=w.usageEvidence,confirmedApiZero=service==='claude'&&source==='api'&&!!scopeKey(incoming.accountKey)&&evidence?.source==='claude-org-usage-percentage'&&typeof evidence.usedPercent==='number'&&Number.isFinite(evidence.usedPercent)&&evidence.usedPercent>=99.5&&evidence.usedPercent<=100&&({five_hour:'現在のセッション',seven_day:'週間',seven_day_sonnet:'Sonnet · 週間',seven_day_opus:'Opus · 週間',seven_day_oauth_apps:'OAuthアプリ · 週間',seven_day_cowork:'Cowork · 週間'})[evidence.window]===w.label&&resetAt>now;
   if(service==='claude'&&source==='api'&&claudeProtectedLabel(w.label)&&w.remaining===0&&!confirmedApiZero){
    const sameSession=!!prev&&(!prev.resetAt||prev.resetAt>now)&&(!resetAt||!prev.resetAt||Math.abs(resetAt-prev.resetAt)<60000);
    if(sameSession&&prev._source==='dom'&&prev.remaining===0)return {...prev,resetAt,conflict:null};
    if(sameSession&&typeof prev.remaining==='number'&&prev.remaining>0)return {...prev,resetAt,conflict:'api-zero',previous:prev.previous};
    return {...w,remaining:null,conflict:'api-zero-unverified',previous:prev?.previous};
   }
   return {...w,resetAt,previous:prev&&prev.remaining!==w.remaining?{remaining:prev.remaining,capturedAt:prior.capturedAt}:prev?.previous};});
  const receivedExtras=(Array.isArray(incoming.extras)?incoming.extras:[]).map(item=>({...item,_source:source,...(item.label==='利用上限のリセット'&&source==='api'?{observedAt:now}:{})})),extraInput=[...receivedExtras,...(prior.extras||[]).filter(oldExtra=>origin(oldExtra)!==source&&!receivedExtras.some(e=>e.label===oldExtra.label)&&(!oldExtra.expiresAt||oldExtra.expiresAt>now))];
  const extras=extraInput.filter(e=>!(service==='chatgpt'&&e.label==='Pro APIクレジット特典'&&incoming.planEvidence==='chatgpt-usage-api'&&incoming.plan&&incoming.plan!=='未取得'&&!/^Pro(?: (?:100|200|500))?$/.test(incoming.plan))).map(e=>{const prev=prior.extras?.find(p=>p.label===e.label),missing=e.value==='未取得'&&prev&&prev.value!=='未取得';if(missing)return prev;if(e.label==='利用上限のリセット'&&prev){const freshApiZero=service==='chatgpt'&&source==='dom'&&prev._source==='api'&&/^(?:利用可能|Available)\s*0$/i.test(prev.value||'')&&now-(prev.observedAt||prior.capturedAt||0)<125000&&now>=(prev.observedAt||prior.capturedAt||0);if(freshApiZero&&/(?:利用可能|Available)\s*[1-9]\d*/i.test(e.value||''))return prev;const count=value=>Number(String(value||'').match(/(?:利用可能|Available)\s*(\d+)/i)?.[1]),incomingCount=count(e.value),previousCount=count(prev.value),uncertain=!Number.isFinite(incomingCount),keepValue=uncertain&&previousCount>0,keepExpiry=!e.expiresAt&&prev.expiresAt>now&&incomingCount!==0&&(incomingCount>0||uncertain),keepOfficial=!e.officialText&&prev.officialText&&incomingCount!==0&&(incomingCount>0||uncertain);return {...e,...(keepValue?{value:prev.value}:{}),...(keepExpiry?{expiresAt:prev.expiresAt,detail:prev.detail,observedAt:prev.observedAt}:{}),...(keepOfficial?{officialText:prev.officialText}:{}),previous:prev&&prev.value!==(keepValue?prev.value:e.value)?{value:prev.value,capturedAt:prior.capturedAt}:prev?.previous};}return {...e,previous:prev&&prev.value!==e.value?{value:prev.value,capturedAt:prior.capturedAt,...(prev.label==='追加使用クレジット'&&prev.unit==='unknown'&&prev.rawValues?{unit:'unknown',rawValues:{...prev.rawValues}}:{})}:prev?.previous};});
  for(const extra of extras)if(/\[object Object\]/.test(String(extra.previous?.value||'')))delete extra.previous;
  const oldReset=prior.extras?.find(e=>e.label==='利用上限のリセット'),hasReset=extras.some(e=>e.label==='利用上限のリセット');
  if(!hasReset&&oldReset?.expiresAt>now)extras.push(oldReset);
  let plan=incoming.plan&&incoming.plan!=='未取得'?incoming.plan:(prior.plan||'未取得'),planEvidence=incoming.planEvidence||'',planObservedAt=now;
  if(service==='chatgpt'){
   const billed=prior.planEvidence==='chatgpt-billing-current'&&now>=prior.planObservedAt&&now-prior.planObservedAt<300000,liveApi=prior.planEvidence==='chatgpt-usage-api',bootstrap=incoming.planEvidence==='chatgpt-bootstrap'||source==='dom'&&!incoming.planEvidence;
   if((billed&&/^Pro (?:100|200|500)$/.test(prior.plan||'')&&plan==='Pro')||bootstrap&&(billed||liveApi)){plan=prior.plan;planEvidence=prior.planEvidence;planObservedAt=prior.planObservedAt;}
  }

  return {...incoming,providerNotice:Object.hasOwn(incoming,'providerNotice')?String(incoming.providerNotice||'').slice(0,280):String(prior.providerNotice||'').slice(0,280),plan,...(service==='chatgpt'?{planEvidence,planObservedAt}:{}),windows,extras,note:service==='claude'&&windows.some(w=>w.conflict?.startsWith('api-zero'))?(scopeKey(incoming.accountKey)?'公式画面の組織を照合できないため、APIの0%は未確定です。':'公式APIの0%を確認中 · 直近の確認済み値を表示。'):incoming.note,capturedAt:receivedWindows.length?now:prior.capturedAt||null,metadataAt:now,refreshing:false};
 }
 root.GlanceState={loading,accept,view,scopeKey,scopeChanged};if(typeof module!=='undefined')module.exports=root.GlanceState;
})(globalThis);
