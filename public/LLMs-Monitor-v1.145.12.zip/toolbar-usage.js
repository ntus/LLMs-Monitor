(function (root) {
  const ADDITIONAL = 'llms-additional-services-v1';
  const KEYS = ['data', 'settings', ADDITIONAL];
  const FRESH_MS = 125000;
  const WEEKLY = [
    ['chatgpt', 'Work / Codex', ['週間 (Work / Codex)', 'Work / Codex · 週間']],
    ['claude', 'Claude', ['週間', '今週', 'This week', 'Weekly limits']],
    ['gemini', 'Gemini', ['週間', 'Weekly']],
    ['grok', 'Grok', ['週間', 'Weekly']],
  ];

  function value(snapshot, reading, used, now, labels) {
    if (snapshot?.status === 'login') return labels.login;
    if (reading?.expired || (reading?.resetAt > 0 && reading.resetAt <= now)) return labels.reset;
    if (!Number.isFinite(used) || used < 0 || used > 100 ||
        !Number.isSafeInteger(snapshot?.capturedAt) || snapshot.capturedAt <= 0 ||
        snapshot.capturedAt > now) return labels.missing;
    const current = snapshot.status === 'ready' && now - snapshot.capturedAt < FRESH_MS;
    return `${Math.round(used)}%${current ? '' : labels.previous}`;
  }

  function title(saved = {}, now = Date.now(), locale = 'ja', museUsage = root.GlanceMuseUsage) {
    const en = String(saved.settings?.language || locale).toLowerCase().startsWith('en');
    const labels = en
      ? { header: 'Weekly usage · used', login: 'Sign in', reset: 'Awaiting reset update', missing: '—', previous: ' (last read)' }
      : { header: '週間使用率（使用済み）', login: 'ログインが必要', reset: 'リセット後の更新待ち', missing: '—', previous: '（前回取得）' };
    const additional = saved[ADDITIONAL] || {};
    const rows = WEEKLY.filter(([id]) => id !== 'grok' || additional.grok?.enabled).map(([id, name, weeklyLabels]) => {
      const snapshot = saved.data?.[id];
      const reading = snapshot?.windows?.find(window => weeklyLabels.includes(window.label));
      const used = Number.isFinite(reading?.remaining) ? 100 - reading.remaining : null;
      return `${name}  ${value(snapshot, reading, used, now, labels)}`;
    });
    if (additional.muse?.enabled) {
      const snapshot = additional.muse;
      const observation = museUsage?.sanitize(snapshot.usage);
      const metric = observation?.metrics?.[0];
      const reading = metric?.period === 'week' ? metric : null;
      const used = reading?.total > 0 ? (reading.total - reading.remaining) * 100 / reading.total : null;
      rows.push(`Muse  ${value({ ...snapshot, status: observation?.status },
        { resetAt: reading?.officialResetAt }, used, now, labels)}`);
    }
    return ['LLMs Monitor', labels.header, ...rows].join('\n');
  }

  function register(chrome) {
    let pending = Promise.resolve();
    let lastTitle;
    function refresh() {
      pending = pending.then(async () => {
        const saved = await chrome.storage.local.get(KEYS);
        const next = title(saved, Date.now(), chrome.i18n.getUILanguage());
        if (next === lastTitle) return;
        await chrome.action.setTitle({ title: next });
        lastTitle = next;
      }).catch(() => {});
      return pending;
    }

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && KEYS.some(key => Object.hasOwn(changes, key))) return refresh();
    });
    chrome.alarms.onAlarm.addListener(alarm => {
      if (alarm.name === 'llms-refresh') return refresh();
    });
    refresh();
  }

  root.GlanceToolbarUsage = { title, register };
  if (typeof module !== 'undefined') module.exports = root.GlanceToolbarUsage;
})(globalThis);
