/* Optional local Native Messaging bridge. No provider requests or execution authority. */
(function(root){
'use strict';
const HOST='info.ntus.llms_gateway.monitor',SCHEMA='monitor-gateway-native.v1',KEY='llms-gateway-link-v1';
const PENDING=KEY+'-pending';
const PROVIDERS=['chatgpt','claude','gemini'],UUID=/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i;
const STATES=new Set(['ready','pairing-required','paired','session-expired','disconnected','unpaired','expired','denied','invalid-request','unavailable']);
const BINDINGS=new Set(['matched-local-baseline','changed','unavailable','unsupported']);
function nativeError(message){const text=typeof message==='string'?message:'';if(/native messaging host (?:was )?not found|native messaging host.*not registered/i.test(text))return 'host-not-found';if(/access to.*native messaging host.*forbidden|native messaging.*not allowed/i.test(text))return 'host-denied';if(/failed to start.*native messaging host|failed to execute/i.test(text))return 'host-start-failed';if(/native (?:messaging )?host has exited|native host exited/i.test(text))return 'host-exited';return 'host-unavailable';}
function selected(value){if(!Array.isArray(value)||!value.length||value.length>3||new Set(value).size!==value.length||value.some(p=>!PROVIDERS.includes(p)))throw Error('invalid-selection');return [...value];}
function response(raw,request,now){
 if(!raw||typeof raw!=='object'||Array.isArray(raw)||JSON.stringify(raw).length>8192||raw.schema!==SCHEMA||raw.requestId!==request.requestId||raw.op!==request.op||raw.peer!=='LLMs Gateway'||!STATES.has(raw.status))throw Error('invalid-response');
 const result={status:raw.status};
 if(raw.continuity!==undefined){if(raw.continuity!=='until-disconnected')throw Error('invalid-response');result.continuity=raw.continuity;}
 if(raw.status==='session-expired'&&request.op!=='publish')throw Error('invalid-response');
 for(const k of ['pairingId','sessionId'])if(raw[k]!==undefined){if(!UUID.test(raw[k]))throw Error('invalid-response');result[k]=raw[k];}
 if(raw.expiresAt!==undefined){if(!Number.isSafeInteger(raw.expiresAt)||raw.expiresAt<=now||raw.expiresAt>now+86400000)throw Error('expired');result.expiresAt=raw.expiresAt;}
 if(raw.confirmationCode!==undefined){if(!/^\d{6}$/.test(raw.confirmationCode))throw Error('invalid-response');result.confirmationCode=raw.confirmationCode;}
 if(raw.bindings!==undefined){if(!Array.isArray(raw.bindings)||raw.bindings.length>3||new Set(raw.bindings.map(b=>b?.provider)).size!==raw.bindings.length)throw Error('invalid-response');result.bindings=raw.bindings.map(b=>{if(!PROVIDERS.includes(b?.provider)||!BINDINGS.has(b.status))throw Error('invalid-response');return {provider:b.provider,status:b.status};});}
 if(raw.status==='paired'&&(!result.pairingId||!result.sessionId||!result.expiresAt))throw Error('invalid-response');
 if(raw.status==='pairing-required'&&(!result.pairingId||!result.confirmationCode||!result.expiresAt))throw Error('invalid-response');
 return result;
}
function accountProofs(data,providers,now){
 const s=data?.claude;
 // A local continuity proof for the subscription organization, not an API billing account.
 return providers.includes('claude')&&s?.status==='ready'&&s.source==='api'&&s.metadataAt===s.capturedAt&&Number.isSafeInteger(s.capturedAt)&&now>=s.capturedAt&&now-s.capturedAt<=125000&&/^claude:[a-f0-9]{64}$/.test(s.accountKey||'')
 ?[{provider:'claude',scopeType:'claude-subscription-organization-sha256',value:s.accountKey.slice(7),observedAt:s.capturedAt}]:[];
}
function create(browser,quota,{now=()=>Date.now(),uuid=()=>root.crypto.randomUUID(),schedule=setTimeout,cancel=clearTimeout}={}){
 let epoch=0,config={enabled:false,providers:[]},session=null,pendingPair=null,state='disconnected',bindings=[],lastReceivedAt=null,port=null,queue=Promise.resolve(),timer=null,loaded=false,loading=null,publishQueued=false,dirty=false;
 const serial=fn=>{const task=queue.then(fn);queue=task.catch(()=>{});return task;};
 async function load(){if(loaded)return;if(loading)return loading;loading=(async()=>{const saved=(await browser.storage.local.get(KEY))[KEY];if(saved?.enabled===true&&UUID.test(saved.pairingId||'')){try{config={enabled:true,providers:selected(saved.providers),pairingId:saved.pairingId,...(saved.continuity==='until-disconnected'?{continuity:saved.continuity}:{})};state='unavailable';}catch{}}else if(UUID.test(saved?.pendingPairingId||'')){config={enabled:false,providers:[],pendingPairingId:saved.pendingPairingId};state='recovery-required';try{const p=(await browser.storage.session.get(PENDING))[PENDING];if(p?.pairingId===saved.pendingPairingId&&/^\d{6}$/.test(p.confirmationCode||'')&&Number.isSafeInteger(p.expiresAt)&&p.expiresAt>now()-3600000&&p.expiresAt<=now()+86400000){pendingPair={pairingId:p.pairingId,confirmationCode:p.confirmationCode,expiresAt:p.expiresAt,providers:selected(p.providers),epoch};state='pairing-required';}}catch{}}loaded=true;})();try{await loading;}finally{loading=null;}}
 async function clearPending(){pendingPair=null;await browser.storage.session?.remove(PENDING);}
 function ownState(){return {...publicState(),...(pendingPair?{confirmationCode:pendingPair.confirmationCode,expiresAt:pendingPair.expiresAt}: {})};}
 async function permitted(){return await browser.permissions.contains({permissions:['nativeMessaging']});}
 function publicState(){return {enabled:config.enabled,providers:[...(pendingPair?.providers||config.providers)],state,continuity:session?.continuity||config.continuity||'session',bindings:[...bindings],lastReceivedAt,executionAllowed:false,spendingAllowed:false};}
 async function call(op,fields={},generation=epoch){
  if(!await permitted()||generation!==epoch)throw Error('permission-required');
  const request={schema:SCHEMA,requestId:uuid(),op,...fields};
  if(JSON.stringify(request).length>65536)throw Error('payload-too-large');
  return new Promise((resolve,reject)=>{let done=false,localPort;const finish=(value,error)=>{if(done)return;done=true;cancel(timeout);try{localPort?.disconnect();}catch{}if(port===localPort)port=null;if(generation!==epoch)return reject(Error('cancelled'));if(error)return reject(Error(error));try{resolve(response(value,request,now()));}catch(e){reject(e);}},timeout=schedule(()=>finish(null,'timeout'),6000);
   try{localPort=browser.runtime.connectNative(HOST);port=localPort;localPort.onMessage.addListener(value=>finish(value));localPort.onDisconnect.addListener(()=>{const reason=nativeError(browser.runtime.lastError?.message);finish(null,reason);});localPort.postMessage(request);}catch{finish(null,'host-unavailable');}
  });
 }
 async function readData(){return (await browser.storage.local.get('data')).data||{};}
 function applyReply(reply){if(reply.pairingId&&reply.pairingId!==config.pairingId)throw Error('invalid-response');state=reply.status;bindings=(reply.bindings||[]).filter(b=>config.providers.includes(b.provider));if(reply.status==='paired')session={sessionId:reply.sessionId,expiresAt:reply.expiresAt,...(reply.continuity?{continuity:reply.continuity}:{})};else session=null;}
 async function stopRevoked(reply){if(['disconnected','unpaired','expired','denied'].includes(reply.status)){config={enabled:false,providers:[]};session=null;bindings=[];if(timer!==null)cancel(timer);timer=null;await browser.storage.local.set({[KEY]:config});}}
 function fail(error){state=['permission-required','host-unavailable','host-not-found','host-denied','host-start-failed','host-exited','timeout','expired','invalid-response','session-unavailable'].includes(error.message)?error.message:'unavailable';session=null;return publicState();}
 async function publish(generation=epoch){
  await load();if(!config.enabled||generation!==epoch)return publicState();
  try{
  // One bounded refresh handles expiry between validation and delivery; never pair again.
  for(let attempt=0;attempt<2;attempt++){
   if(!session||session.expiresAt<=now()){
    const reply=await call('status',{pairingId:config.pairingId},generation);applyReply(reply);await stopRevoked(reply);
    if(reply.status!=='paired')return publicState();
   }
   const data=await readData();if(generation!==epoch||!config.enabled)return publicState();
   const payload=quota.fromSnapshots(data,{now:now()}).envelope;payload.pools=payload.pools.filter(p=>config.providers.includes(p.provider));
   const reply=await call('publish',{pairingId:config.pairingId,sessionId:session.sessionId,payload,accountProofs:accountProofs(data,config.providers,now())},generation);
   if(reply.status==='session-expired'){session=null;state='reconnecting';if(attempt===0)continue;return publicState();}
   applyReply(reply);await stopRevoked(reply);if(reply.status==='paired')lastReceivedAt=now();return publicState();
  }
  }catch(error){return generation===epoch?fail(error):publicState();}
 }
 function changed(){if(!config.enabled)return;if(publishQueued){dirty=true;return;}if(timer!==null)cancel(timer);const generation=epoch;timer=schedule(()=>{timer=null;publishQueued=true;dirty=false;serial(()=>publish(generation)).catch(()=>{}).finally(()=>{publishQueued=false;if(dirty&&generation===epoch){dirty=false;changed();}});},1000);}
 function allowed(sender,external){return !external&&sender?.id===browser.runtime.id&&sender.frameId===0&&sender.url===browser.runtime.getURL('gateway-setup.html');}
 async function disconnect(){
  await load();const old={pairingId:config.pairingId||config.pendingPairingId||pendingPair?.pairingId};const generation=++epoch;if(timer!==null)cancel(timer);timer=null;try{port?.disconnect();}catch{}port=null;
  config={enabled:false,providers:[]};session=null;pendingPair=null;bindings=[];lastReceivedAt=null;state='disconnected';await browser.storage.local.set({[KEY]:config});await clearPending();
  if(old.pairingId)try{const reply=await call('disconnect',Object.fromEntries(Object.entries(old).filter(([,v])=>v)),generation);if(generation===epoch&&reply.status!=='disconnected')state='disconnect-unconfirmed';}catch{if(generation===epoch)state='disconnect-unconfirmed';}
  return publicState();
 }
 async function handle(message,sender,external=false){
  if(!allowed(sender,external))return {error:'not-allowed'};
  if(message?.type==='GATEWAY_DISCONNECT')return disconnect();
  const requestedEpoch=epoch;
  return serial(async()=>{
   await load();if(requestedEpoch!==epoch)return publicState();const generation=epoch;
   if(message.type==='GATEWAY_STATUS')return ownState();
   if(message.type==='GATEWAY_CHECK'){if(config.pendingPairingId)return ownState();if(config.enabled)return publish();try{state=(await call('hello',{},generation)).status;return publicState();}catch(error){return generation===epoch?fail(error):publicState();}}
   if(message.type==='GATEWAY_PAIR_BEGIN'){
    if(config.enabled||config.pendingPairingId)return {error:'disconnect-first'};
    try{if(!browser.storage.session?.set||!browser.storage.session?.remove)throw Error('session-unavailable');await browser.storage.session.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'});const providers=selected(message.providers),data=await readData(),reply=await call('pair-begin',{providers,continuity:'until-disconnected',accountProofs:accountProofs(data,providers,now())},generation);
     if(reply.status!=='pairing-required')throw Error('invalid-response');pendingPair={...reply,providers,epoch};config={enabled:false,providers:[],pendingPairingId:reply.pairingId};await browser.storage.local.set({[KEY]:config});if(generation!==epoch){await browser.storage.local.set({[KEY]:{enabled:false,providers:[]}});return publicState();}await browser.storage.session.set({[PENDING]:{pairingId:reply.pairingId,confirmationCode:reply.confirmationCode,providers,expiresAt:reply.expiresAt}});if(generation!==epoch){await clearPending();return publicState();}state='pairing-required';return ownState();
    }catch(error){if(generation!==epoch)return publicState();pendingPair=null;return fail(error);}
   }
   if(message.type==='GATEWAY_PAIR_CONFIRM'){
    if(!pendingPair||pendingPair.epoch!==epoch||message.code!==pendingPair.confirmationCode)return {error:'pairing-expired'};
    try{const pair=pendingPair,reply=await call('pair-confirm',{pairingId:pair.pairingId,confirmationCode:message.code},generation);if(['expired','unpaired','denied','disconnected'].includes(reply.status)){await clearPending();config={enabled:false,providers:[]};await browser.storage.local.set({[KEY]:config});state=reply.status;return publicState();}if(reply.pairingId!==pair.pairingId)throw Error('invalid-response');if(reply.status==='pairing-required'){state='pairing-required';return ownState();}if(reply.status!=='paired'||reply.continuity!=='until-disconnected')throw Error('invalid-response');if(generation!==epoch)return publicState();config={enabled:true,providers:pair.providers,pairingId:reply.pairingId,...(reply.continuity?{continuity:reply.continuity}:{})};pendingPair=null;applyReply(reply);await browser.storage.local.set({[KEY]:config});await browser.storage.session.remove(PENDING);if(generation!==epoch){await browser.storage.local.set({[KEY]:{enabled:false,providers:[]}});return publicState();}return publish(generation);}catch(error){return generation===epoch?fail(error):publicState();}
   }
   return {error:'unsupported-operation'};
  });
 }
 browser.storage.onChanged?.addListener((changes,area)=>{if(area==='local'&&changes.data)changed();});
 browser.permissions?.onRemoved?.addListener(p=>{if(p.permissions?.includes('nativeMessaging'))disconnect().catch(()=>{});});
 async function resume(){await load();if(config.enabled)return serial(()=>publish());return publicState();}
 return Object.freeze({handle,allowed,resume,disconnect,changed});
}
const api={HOST,SCHEMA,KEY,PENDING,selected,response,accountProofs,nativeError,create};
if(typeof module!=='undefined')module.exports=api;
else root.LLMGatewayBridge=create(root.chrome,root.GlanceCurrentQuota);
})(globalThis);
