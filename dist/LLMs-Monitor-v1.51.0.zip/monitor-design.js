/* Layout and setup presentation. Permission controls mount only on the own top-level extension page. */
(function(root){
 const $=s=>document.querySelector(s),G=root.Glance,L=root.GlanceLocale;let last={},paintKey='',ownLanguage='',ownMounting=false;
 const say=(ja,en)=>L.language()==='ja'?ja:en;
 function paint(state=last){last=state||{};if(location.protocol==='chrome-extension:'){if(ownLanguage!==L.language()&&!ownMounting)mountOwnSetup();return;}const host=$('#inline-options');if(!host)return;const key=JSON.stringify([L.language(),Object.fromEntries(Object.entries(last.apiCredits||{}).map(([id,v])=>[id,!!v.enabled]))]);if(key===paintKey)return;paintKey=key;const open=new Set([...host.querySelectorAll('details[open]')].map(n=>n.dataset.option));const diagnosticsLabel=document.querySelector('.dock-diagnostics>summary');if(diagnosticsLabel)diagnosticsLabel.textContent=say('診断・更新状況','Diagnostics / updates');
  const rows=[['api',say('APIクレジット残高','API credit balances'),say('月額の利用枠とは別です。各社の請求画面の表示値を読み取ります。','Separate from plan quotas. Reads the official billing display.')],['codex','Codex',say('初回のみヘルパー導入。接続後の一覧はChatGPTタスク詳細に表示します。','Install the helper once. Local tasks appear in ChatGPT task details.')],['tibo','Tibo / ClaudeDevs 𝕏',say('表示済みの本人投稿を確認。自動巡回・リロードはしません。','Checks rendered public author posts without automatic navigation or reload.')],['additional',say('追加サービス','Additional services'),say('Grok・DeepSeek・Perplexity・Gensparkは試験対応。選択欄で最大3つまで表示できます。','Grok, DeepSeek, Perplexity and Genspark are experimental. Select up to three services below.')]];
  host.innerHTML=rows.map(([id,title,copy])=>`<details class="inline-option" data-option="${id}"><summary>${G.escape(title)}</summary><p>${G.escape(copy)}</p>${id==='api'?Object.entries(root.GlanceApiCredits.PROVIDERS).map(([key,p])=>`<div class="option-provider"><b>${G.escape(p.name)}</b><span>${last.apiCredits?.[key]?.enabled?say('連携ON','Connected'):say('未設定','Not configured')}</span><a href="${p.url}" target="_blank" rel="noopener noreferrer">${say('公式画面','Official page')} ↗</a></div>`).join(''):''}<button type="button" data-permission-setup="${id}">${say('このタブで設定する','Set up in this tab')} ↗</button><small>${say('このタブを拡張機能のメイン画面に切り替えて、同じ画面内で設定します。','Switches this tab to the extension monitor, with settings on the same page.')}</small></details>`).join('');for(const n of host.querySelectorAll('details'))n.open=open.has(n.dataset.option);
 }
 const dock=$('#monitor-dock'),advisor=$('#advisor');if(dock&&advisor)$('#dock-advice-slot').append(advisor);
 const diagnostics=$('#status-log');if(diagnostics){const wrap=document.createElement('details');wrap.className='dock-diagnostics';const summary=document.createElement('summary');summary.textContent=say('診断・更新状況','Diagnostics / updates');diagnostics.before(wrap);wrap.append(summary,diagnostics);}
 document.addEventListener('click',e=>{if(!e.target.closest('[data-permission-setup]'))return;rpc({type:'SETUP_INLINE_OPEN'}).catch(error=>{const n=$('#toast');n.textContent=error.message;n.style.display='block'})});
 function openSetup(key){const show=()=>{const setup=$('#setup'),options=$('#setup-options');if(options)options.open=true;const option=document.querySelector('[data-option="'+key+'"]')||document.getElementById('setup-'+key);if(option)option.open=true;(option||setup)?.scrollIntoView({behavior:'smooth',block:'start'})};if(document.fullscreenElement)document.exitFullscreen().then(show).catch(show);else show();}
 document.addEventListener('click',e=>{if(e.target.closest('#header-setup')){e.preventDefault();openSetup('')}});
 async function mountOwnSetup(){
  if(location.protocol!=='chrome-extension:'||window.top!==window||ownMounting)return;ownMounting=true;ownLanguage=L.language();
  const host=$('#inline-options');try{
   const response=await fetch(chrome.runtime.getURL('setup.html'));if(!response.ok)throw Error('Setup unavailable');
   const source=new DOMParser().parseFromString(await response.text(),'text/html'),body=source.querySelector('.api-setup'),panel=document.createElement('div');panel.className='api-setup';
   panel.append(...[...body.childNodes].map(node=>document.importNode(node,true)));host.replaceChildren(panel);
   // Reuse the trusted setup controls and direct-click permission prompts without frames.
   for(const name of ['tibo-reader.js','helper-package.js','setup.js','api-setup.js','codex-setup.js','tibo-setup.js'])await new Promise((resolve,reject)=>{const script=document.createElement('script');script.src=chrome.runtime.getURL(name);script.onload=resolve;script.onerror=reject;document.body.append(script)});
   if(location.hash==='#setup')openSetup('');
  }catch{host.textContent=say('設定を読み込めません。拡張機能を再読み込みしてください。','Could not load settings. Reload the extension.');}finally{ownMounting=false;}
 }
 root.GlanceMonitorDesign={paint,openSetup};paint();mountOwnSetup();
})(globalThis);
