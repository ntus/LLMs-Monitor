/* Explicit click only. The native host opens its own fixed local UI; no launch URL crosses this bridge. */
(function(root){'use strict';
 const HOST='info.ntus.llms_gateway.credit',SCHEMA='monitor-gateway-credit.v1';
 function create(browser,{uuid=()=>root.crypto.randomUUID(),schedule=setTimeout,cancel=clearTimeout}={}){
  let pending=null;
  function allowed(sender,trusted,external){let u;try{u=new URL(sender.url)}catch{return false}return trusted===true&&sender.frameId===0&&(external||sender.id===browser.runtime.id)&&!u.username&&!u.password&&!u.search&&['/','/index.html'].includes(u.pathname);}
  async function open(){
   if(!await browser.permissions.contains({permissions:['nativeMessaging']}))return {ok:false,error:'permission-required'};
   const request={schema:SCHEMA,op:'open-workbench',request_id:uuid()};
   return new Promise(resolve=>{let done=false,port,timer;const finish=(raw,error)=>{if(done)return;done=true;cancel(timer);try{port?.disconnect()}catch{}if(error)return resolve({ok:false,error});const valid=raw&&typeof raw==='object'&&!Array.isArray(raw)&&Object.keys(raw).every(k=>['schema','op','request_id','status'].includes(k))&&raw.schema===SCHEMA&&raw.op===request.op&&raw.request_id===request.request_id&&['opened','unavailable'].includes(raw.status);resolve(valid?{ok:raw.status==='opened',error:raw.status==='opened'?undefined:'unavailable'}:{ok:false,error:'invalid-response'});};timer=schedule(()=>finish(null,'timeout'),6000);try{port=browser.runtime.connectNative(HOST);port.onMessage.addListener(raw=>finish(raw));port.onDisconnect.addListener(()=>{void browser.runtime.lastError;finish(null,'unavailable')});port.postMessage(request)}catch{finish(null,'unavailable')}});
  }
  function handle(message,sender,trusted,external=false){if(message?.type!=='GATEWAY_WORKBENCH_OPEN'||Object.keys(message).length!==1||!allowed(sender,trusted,external))return Promise.resolve({ok:false,error:'not-allowed'});if(!pending)pending=open().catch(()=>({ok:false,error:'unavailable'})).finally(()=>{pending=null});return pending;}
  return {handle};
 }
 const api={HOST,SCHEMA,create};if(typeof module!=='undefined')module.exports=api;else root.GlanceGatewayWorkbench=create(root.chrome);
})(globalThis);
