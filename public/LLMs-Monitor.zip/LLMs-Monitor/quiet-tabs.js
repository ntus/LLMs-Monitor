/* Automatic acquisition never creates, focuses, minimizes or closes a window. */
(function(root){
 const SOURCES='llms-acquisition-sources-v1';
 const sourceURLs=new Set(['https://claude.ai/settings/usage','https://claude.ai/new#settings/usage','https://platform.claude.com/settings/billing','https://platform.openai.com/settings/organization/billing/overview','https://chatgpt.com/settings/usage?tab=overview','https://chatgpt.com/settings/billing','https://grok.com/dashboard','https://muse.ai/','https://gemini.google.com/usage']);
 const sourceKey=url=>url==='https://claude.ai/new#settings/usage'?'https://claude.ai/settings/usage':url;
 const KEY='llms-quiet-tabs-v1',MONITOR='llms-acquisition-monitor-v1';let queue=Promise.resolve();
 const serial=fn=>{const p=queue.then(fn);queue=p.catch(()=>{});return p};
 const samePage=(actual,expected)=>actual===expected||expected==='https://platform.claude.com/settings/billing'&&actual==='https://platform.claude.com/settings/billing/'||expected==='https://claude.ai/settings/usage'&&actual==='https://claude.ai/new#settings/usage';
 const page=tab=>tab.url&&tab.url!=='about:blank'?tab.url:tab.pendingUrl;
 // The worker/session can disappear on an extension update. Persist only tab identity,
 // then revalidate the live route + this extension's marker before any mutation.
 const read=async()=>((await chrome.storage.session.get(KEY))[KEY]||(await chrome.storage.local?.get(KEY))?.[KEY]||{tabs:[]});
 const save=async state=>{await chrome.storage.local?.set({[KEY]:state});await chrome.storage.session.set({[KEY]:state})};
 function monitorPage(value){try{const u=new URL(value);return !u.username&&!u.password&&((u.origin==='https://llmsmonitor.ntus.org'||u.origin==='https://llmsmonitor.ntus.info'||u.origin==='https://llmsmonitor.ntusnog.chatgpt.site')&&['/','/index.html'].includes(u.pathname)||value.split(/[?#]/)[0]===chrome.runtime.getURL('index.html'));}catch{return false}}
 async function setMonitor(id){if(!Number.isInteger(id))return;try{const tab=await chrome.tabs.get(id);if(monitorPage(tab.url))await chrome.storage.session.set({[MONITOR]:id})}catch{}}
 async function monitorTarget(){
  const windows=await chrome.windows.getAll({windowTypes:['normal']}),valid=new Map(windows.filter(w=>w.type==='normal'&&w.incognito!==true).map(w=>[w.id,w]));
  const saved=(await chrome.storage.session.get(MONITOR))[MONITOR];
  let preferred=null;try{if(Number.isInteger(saved))preferred=await chrome.tabs.get(saved)}catch{}
  const candidates=preferred&&monitorPage(preferred.url)&&valid.has(preferred.windowId)?[preferred]:
   (await chrome.tabs.query({url:['https://llmsmonitor.ntus.org/*','https://llmsmonitor.ntus.info/*','https://llmsmonitor.ntusnog.chatgpt.site/*',chrome.runtime.getURL('index.html')+'*']})).filter(t=>monitorPage(t.url)&&valid.has(t.windowId)).sort((a,b)=>Number(!!valid.get(b.windowId)?.focused)-Number(!!valid.get(a.windowId)?.focused)||a.id-b.id);
  const selected=candidates[0];if(!selected)throw Error('No monitor browser window; automatic acquisition skipped');
  // Revalidate after discovery: do not fall back to an unrelated normal window.
  const live=await chrome.tabs.get(selected.id);if(!monitorPage(live.url)||!valid.has(live.windowId))throw Error('Monitor moved or closed; automatic acquisition skipped');return live;
 }
 async function monitorWindow(){return (await monitorTarget()).windowId}
 const recordMarked=(tab,record)=>!!tab?.mutedInfo?.muted&&tab.mutedInfo.extensionId===chrome.runtime.id&&Number.isInteger(record?.windowId)&&tab.windowId===record.windowId&&Number.isInteger(record?.openerTabId)&&(tab.openerTabId===undefined||tab.openerTabId===record.openerTabId);
 const marked=tab=>!!tab?.mutedInfo?.muted&&tab.mutedInfo.extensionId===chrome.runtime.id&&Number.isInteger(tab.openerTabId);
 function create(url){return serial(async()=>{
  const state=await read(),monitor=await monitorTarget(),windowId=monitor.windowId;
  const live=[];for(const owned of (state.tabs||[]).slice(0,12))try{const tab=await chrome.tabs.get(owned.id);if(recordMarked(tab,owned)&&samePage(page(tab),owned.url))live.push(owned)}catch{}
  // An extension reload clears session storage. Recover only tabs marked as muted by this exact extension and opened from this monitor.
  const recorded=live.find(owned=>owned.windowId===windowId&&samePage(owned.url,url));let retained=null;if(recorded)try{const tab=await chrome.tabs.get(recorded.id);if(!tab.active&&recordMarked(tab,recorded)&&samePage(tab.url,url))retained=tab}catch{}
  const candidates=(await chrome.tabs.query({})).filter(tab=>tab.incognito!==true&&(samePage(page(tab),url)||samePage(tab.pendingUrl,url)));
  const tracked=sourceURLs.has(url),sources=tracked?(await chrome.storage.local.get(SOURCES))[SOURCES]||{}:{},key=sourceKey(url);
  const remember=async tab=>{if(tracked)await chrome.storage.local.set({[SOURCES]:{...sources,[key]:tab.id}});return tab;};
  const reusable=retained||candidates.find(tab=>!tab.active&&tab.windowId===windowId&&tab.openerTabId===monitor.id&&marked(tab));
  if(reusable){if(!live.some(t=>t.id===reusable.id))await save({tabs:[...live,{id:reusable.id,url,windowId,openerTabId:monitor.id,...(url==='https://platform.claude.com/settings/billing'&&reusable.autoDiscardable===false?{restoreDiscardable:true}:{})}]});return remember({...reusable,reused:true});}
  // An adopted/restored/user-opened exact page is a passive source, not a reason
  // to allocate another acquisition tab. Never mark, reload or close that page.
  const existing=candidates.sort((a,b)=>Number(!!b.active)-Number(!!a.active)||Number(b.windowId===windowId)-Number(a.windowId===windowId)||(b.lastAccessed||0)-(a.lastAccessed||0)||a.id-b.id)[0];
  if(existing){await save({tabs:live});return remember({...existing,reused:true,borrowed:true});}
  // A retained source that navigated or logged out is not permission to allocate another tab.
  if(tracked&&Number.isInteger(sources[key])){let prior;try{prior=await chrome.tabs.get(sources[key])}catch{}if(prior)throw Error('Existing acquisition source changed; automatic replacement paused');}
  if(live.length>=12)throw Error('Quiet acquisition capacity reached');
  const tab=await chrome.tabs.create({url,windowId,openerTabId:monitor.id,active:false});
  if(!Number.isInteger(tab?.id))throw Error('Acquisition tab unavailable');
  try{await save({tabs:[...live,{id:tab.id,url,windowId,openerTabId:monitor.id,...(url==='https://platform.claude.com/settings/billing'&&tab.autoDiscardable!==false?{restoreDiscardable:true}:{})}]})}catch(error){try{const current=await chrome.tabs.get(tab.id);if(!current.active&&samePage(current.url||current.pendingUrl,url))await chrome.tabs.remove(tab.id)}catch{}throw error;}
  try{await chrome.tabs.update(tab.id,{muted:true,...(url==='https://platform.claude.com/settings/billing'?{autoDiscardable:false}:{})})}catch{}
  return remember(tab);
 });}
 function park(id){return serial(async()=>{
  const state=await read(),record=(state.tabs||[]).find(t=>t.id===id);if(!record)return false;
  try{const tab=await chrome.tabs.get(id);return !tab.active&&recordMarked(tab,record)&&samePage(tab.url,record.url)}catch{return false}
 });}
 function release(id){return serial(async()=>{
  const state=await read(),owned=(state.tabs||[]).find(t=>t.id===id);if(!owned)return false;
  // Keep user-activated/navigated tabs; never delete a whole window or its blank tab.
  try{const tab=await chrome.tabs.get(id);if(!tab.active&&recordMarked(tab,owned)&&(samePage(tab.url,owned.url)||!tab.url&&samePage(tab.pendingUrl,owned.url)))await chrome.tabs.remove(id);else if(marked(tab)||recordMarked(tab,owned))await chrome.tabs.update(id,{muted:false,...(owned.restoreDiscardable?{autoDiscardable:true}:{})})}catch{}
  await save({tabs:(state.tabs||[]).filter(t=>t.id!==id)});return true;
 });}
 async function sameMonitorWindow(windowId){try{return Number.isInteger(windowId)&&await monitorWindow()===windowId}catch{return false}}
 // Muse may keep its original acquisition window while another valid monitor becomes preferred.
 async function hasMonitorWindow(windowId){try{if(!Number.isInteger(windowId))return false;const windows=await chrome.windows.getAll({windowTypes:['normal']});if(!windows.some(w=>w.id===windowId&&w.type==='normal'&&w.incognito!==true))return false;const tabs=await chrome.tabs.query({windowId});for(const t of tabs){if(t.windowId!==windowId||!monitorPage(t.url))continue;try{const live=await chrome.tabs.get(t.id);if(live.windowId===windowId&&monitorPage(live.url))return true}catch{}}return false}catch{return false}}
 // A user-activated or navigated acquisition tab becomes user-owned. Clear our mute marker so a later reload cannot recover it.
 async function relinquish(id){try{const tab=await chrome.tabs.get(id),owned=(await read()).tabs?.find(t=>t.id===id);if(!marked(tab)&&!recordMarked(tab,owned))return;await chrome.tabs.update(id,{muted:false,...(owned?.restoreDiscardable?{autoDiscardable:true}:{})});await serial(async()=>{const state=await read();await save({tabs:(state.tabs||[]).filter(t=>t.id!==id)})})}catch{}}
 chrome.tabs.onActivated?.addListener(({tabId})=>relinquish(tabId));
 chrome.tabs.onDetached?.addListener(id=>relinquish(id));
 chrome.tabs.onAttached?.addListener(id=>relinquish(id));
 chrome.tabs.onUpdated?.addListener((id,change)=>{if(change.url)read().then(state=>{const owned=(state.tabs||[]).find(t=>t.id===id);if(!owned||!samePage(change.url,owned.url))relinquish(id)}).catch(()=>{})});
 async function isOwned(id,{allowSeveredOpener=false}={}){try{const state=await read(),owned=(state.tabs||[]).find(t=>t.id===id),tab=await chrome.tabs.get(id);return !!owned&&!tab.active&&recordMarked(tab,owned)&&(allowSeveredOpener||tab.openerTabId===owned.openerTabId)&&samePage(tab.url,owned.url)}catch{return false}}
 const RECOVERY='llms-acquisition-recovery-v1',RECOVERY_AT='llms-acquisition-recovery-at-v1';
 const recoveryRoutes={claude:['https://platform.claude.com/settings/billing','https://platform.claude.com/settings/billing/','https://claude.ai/settings/usage','https://claude.ai/new#settings/usage'],grok:['https://grok.com/dashboard'],muse:['https://muse.ai/']};
 async function configureRecovery(message,sender,external=false){
  if(external||sender?.id!==chrome.runtime.id||sender.frameId!==0||!['gateway-credit-setup.html','setup.html','api-setup.html'].map(p=>chrome.runtime.getURL(p)).includes(sender.url)||!Object.hasOwn(recoveryRoutes,message.service)||typeof message.enabled!=='boolean')return {ok:false};
  return serial(async()=>{const settings=(await chrome.storage.local.get(RECOVERY))[RECOVERY]||{};await chrome.storage.local.set({[RECOVERY]:{...settings,[message.service]:message.enabled}});return {ok:true,enabled:message.enabled};});
 }
 async function recoverDiscarded(service,id){return serial(async()=>{
  if(!Object.hasOwn(recoveryRoutes,service)||!Number.isInteger(id))return false;
  const eligible=async()=>{
   if((await chrome.storage.local.get(RECOVERY))[RECOVERY]?.[service]!==true)return null;
   let tab;try{tab=await chrome.tabs.get(id)}catch{return null}
   if(tab.active||tab.incognito||tab.discarded!==true||!recoveryRoutes[service].includes(tab.url)||!await hasMonitorWindow(tab.windowId))return null;
   const source=service==='claude'&&tab.url.startsWith('https://platform.claude.com/')?'billing':'usage';
   const saved=await chrome.storage.local.get(source==='billing'?'apiCredits':service==='claude'?'settings':'llms-additional-services-v1');
   if(source==='billing'?saved.apiCredits?.claude?.enabled!==true:service==='claude'?saved.settings?.enabled===false:saved['llms-additional-services-v1']?.[service]?.enabled!==true)return null;
   if(!await chrome.permissions.contains({permissions:['scripting'],origins:[new URL(tab.url).origin+'/*']}))return null;
   return tab;
  };
  const first=await eligible();if(!first)return false;
  const attempts=(await chrome.storage.session.get(RECOVERY_AT))[RECOVERY_AT]||{},at=Date.now();if(at-(attempts[id]||0)<60000)return false;
  const live=await eligible();if(!live||live.url!==first.url||live.windowId!==first.windowId)return false;
  const recent=Object.fromEntries(Object.entries(attempts).filter(([,v])=>Number.isFinite(v)&&at-v<3600000).slice(-11));
  await chrome.storage.session.set({[RECOVERY_AT]:{...recent,[id]:at}});
  // Resume the same discarded document only. No focus, ownership or discard-policy changes.
  await chrome.tabs.reload(id);return true;
 });}
 async function recoverKnown(service){
  if(!Object.hasOwn(recoveryRoutes,service))return;
  const rows=(await read()).tabs||[],ids=rows.filter(t=>recoveryRoutes[service].includes(t.url)).map(t=>t.id);
  if(service==='claude'){const saved=await chrome.storage.session.get('llms-claude-api-probe-v1'),local=await chrome.storage.local.get('claudeProbeTabId');ids.push(saved['llms-claude-api-probe-v1']?.id,local.claudeProbeTabId);}
  for(const id of [...new Set(ids.filter(Number.isInteger))].slice(0,12))await recoverDiscarded(service,id);
 }
 root.GlanceQuietTabs={create,park,release,relinquish,setMonitor,sameMonitorWindow,hasMonitorWindow,isOwned,recoverDiscarded,recoverKnown,configureRecovery,RECOVERY};if(typeof module!=='undefined')module.exports=root.GlanceQuietTabs;
})(globalThis);
