(function(root){
 const A=root.GlanceAdditional,KEY='llms-additional-services-v1',OPEN_KEY='llms-muse-open-usage-v1';let queue=Promise.resolve();
 const serial=fn=>{const next=queue.then(fn);queue=next.catch(()=>{});return next};
 const permission=id=>({permissions:['scripting'],origins:(A.PROVIDERS[id].origins||[A.PROVIDERS[id].origin]).map(origin=>origin+'/*')});
 async function configure(id,enabled){if(!Object.hasOwn(A.PROVIDERS,id)||A.PROVIDERS[id].displayOnly)return {ok:false};if(enabled&&!await chrome.permissions.contains(permission(id)))return {ok:false};await serial(async()=>{const s=(await chrome.storage.local.get(KEY))[KEY]||{};if(s[id]?.enabled!==enabled)s[id]={enabled,status:'unavailable',rows:[],...(id==='muse'?{history:root.GlanceMuseUsage.normalizeHistory(s[id]?.history)}:{})};await chrome.storage.local.set({[KEY]:s})});if(enabled)await refresh(id,true);else {if(id==='grok')await root.GlanceGrokRefresh?.stop();if(id==='muse')await root.GlanceMuseRefresh?.stop();try{await chrome.scripting.unregisterContentScripts({ids:['llms-additional-'+id]})}catch{}}return {ok:true}}
 async function authorized(id,sender){return Object.hasOwn(A.PROVIDERS,id)&&!A.PROVIDERS[id].displayOnly&&sender.id===chrome.runtime.id&&sender.frameId===0&&Number.isInteger(sender.tab?.id)&&A.route(sender.url)===id&&await chrome.permissions.contains(permission(id))&&((await chrome.storage.local.get(KEY))[KEY]||{})[id]?.enabled===true}
 async function setMuseResetAnswer(text){return serial(async()=>{const hint=root.GlanceMuseUsage.resetAnswer(text);if(!hint)return {ok:false,reason:'invalid-datetime'};const saved=(await chrome.storage.local.get(KEY))[KEY]||{};if(!saved.muse?.enabled)return {ok:false,reason:'disabled'};if(!root.GlanceMuseUsage.validResetHint(hint,root.GlanceMuseUsage.sanitize(saved.muse.usage).metrics[0]))return {ok:false,reason:'reset-date-mismatch'};saved.muse={...saved.muse,resetHint:hint};await chrome.storage.local.set({[KEY]:saved});return {ok:true};});}
 async function openMuseUsage(){
  const saved=(await chrome.storage.local.get(KEY))[KEY]||{};if(!saved.muse?.enabled||!await chrome.permissions.contains(permission('muse')))throw Error('Museの読取りをセットアップで有効にしてください。');
  const result=await root.GlanceWindows.createNormalTab(chrome,'https://muse.ai/');if(!Number.isInteger(result?.tabId))throw Error('Museを開けませんでした');
  await chrome.storage.session.set({[OPEN_KEY]:{tabId:result.tabId,expiresAt:Date.now()+90000}});
  try{await chrome.scripting.executeScript({target:{tabId:result.tabId},files:['usage-evidence.js','muse-usage.js','muse-reader.js']})}catch{/* Registered reader retries after navigation. */}
  return {ok:true};
 }
 async function readerStatus(m,sender){const enabled=await authorized(m.service,sender);if(m.service!=='muse')return {enabled};const explicit=enabled?(await chrome.storage.session.get(OPEN_KEY))[OPEN_KEY]:null;if(explicit?.tabId===sender.tab.id&&explicit.expiresAt>Date.now()&&explicit.expiresAt<=Date.now()+90000)return {enabled,prepare:true,explicit:true,generation:0};return {enabled,...(enabled?await root.GlanceMuseRefresh?.readerContext(sender.tab.id):{prepare:false,generation:0})}}
 async function receive(m,sender){const id=m.service;if(!await authorized(id,sender))return {ok:false};return serial(async()=>{const s=(await chrome.storage.local.get(KEY))[KEY]||{};if(!s[id]?.enabled)return {ok:false};
 if(id==='muse'){
  if(m.readerVersion!=='1.140.0'||!await authorized(id,sender)||(await root.GlanceMuseRefresh?.accepts(sender.tab.id,m.generation))!==true)return {ok:false};
  const now=Date.now();if(!Number.isSafeInteger(m.observedAt)||m.observedAt<=0||m.observedAt>now||now-m.observedAt>90000)return {ok:false};
  const usage=root.GlanceMuseUsage.extract(m.evidence);if(usage.status!=='ready')return {ok:false};
  const previous=s[id],before=root.GlanceMuseUsage.sanitize(previous?.usage).metrics[0],after=usage.metrics[0],recovered=previous?.capturedAt&&Date.now()-previous.capturedAt<125000&&before?.remaining===0&&after.remaining>0&&before.unit===after.unit&&before.total===after.total;
  const capturedAt=m.observedAt;if(previous?.capturedAt>capturedAt)return {ok:false};s[id]={enabled:true,rows:[],usage,capturedAt,...(root.GlanceMuseUsage.validResetHint(previous?.resetHint,usage.metrics[0])?{resetHint:previous.resetHint}:{}),history:root.GlanceMuseUsage.recordHistory(root.GlanceMuseUsage.normalizeHistory(previous?.history).length?previous.history:root.GlanceMuseUsage.recordHistory([],previous?.usage,previous?.capturedAt||0),usage,capturedAt)};await root.GlanceMuseRefresh?.report(sender.tab.id,m.generation);
  await chrome.storage.local.set({[KEY]:s});if(recovered)await root.GlanceMuseRecovered?.();return {ok:true};
 }
 if(id==='copilot'){
  const tabs=(await chrome.tabs.query({url:A.PROVIDERS.copilot.origins.map(origin=>origin+'/*')})).filter(t=>A.route(t.url)==='copilot'&&Number.isInteger(t.id));
  tabs.sort((a,b)=>Number(new URL(b.url).origin==='https://copilot.cloud.microsoft')-Number(new URL(a.url).origin==='https://copilot.cloud.microsoft')||Number(!!b.active)-Number(!!a.active)||(b.lastAccessed||0)-(a.lastAccessed||0)||a.id-b.id);
  if(tabs[0]?.id!==sender.tab.id)return {ok:false};
 }
 if(id==='grok'&&m.quota!==undefined){
 if(!['1.54.0','1.96.0'].includes(m.readerVersion))return {ok:false};
 const tabs=(await chrome.tabs.query({url:A.PROVIDERS.grok.origin+'/*'})).filter(t=>A.route(t.url)==='grok'&&Number.isInteger(t.id));
 const owned=await root.GlanceGrokRefresh?.ownedId();const selected=tabs.filter(t=>t.active).sort((a,b)=>(b.lastAccessed||0)-(a.lastAccessed||0)||a.id-b.id)[0]||tabs.find(t=>t.id===owned)||tabs.sort((a,b)=>(b.lastAccessed||0)-(a.lastAccessed||0)||a.id-b.id)[0];
 if(!selected||selected.id!==sender.tab.id)return {ok:false};
 const prior=(await chrome.storage.local.get('data')).data?.grok;
 if(root.GlanceGrokQuota?.olderCycle(prior,m.quota)){
  await root.GlanceGrokRefresh?.report(sender.tab.id,false);
  return {ok:false,reason:'older-reset-cycle'};
 }
 }const quota=id==='grok'&&m.quota!==undefined&&root.GlanceGrokQuota?root.GlanceGrokQuota.sanitize(m.quota):null;if(id==='grok')await root.GlanceGrokRefresh?.report(sender.tab.id,quota?.status==='ready');s[id]={enabled:true,rows:A.sanitize(m.rows,id),...(id==='copilot'?{plan:A.copilotPlan(m.plan),source:new URL(sender.url).origin==='https://copilot.cloud.microsoft'?'work':'personal'}:{}),capturedAt:Date.now()};if(quota&&root.GlanceGrokAccept)await root.GlanceGrokAccept(quota);await chrome.storage.local.set({[KEY]:s});return {ok:true}})}
 function bounded(task){let timer;return Promise.race([task,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Additional reader timeout')),3000)})]).finally(()=>clearTimeout(timer))}
 async function refresh(only,force=false){const s=(await chrome.storage.local.get(KEY))[KEY]||{};await Promise.allSettled((only?[only]:Object.keys(A.PROVIDERS)).map(async id=>{if(A.PROVIDERS[id]?.displayOnly||!s[id]?.enabled)return;if(!await chrome.permissions.contains(permission(id))){await configure(id,false);return}const scriptId='llms-additional-'+id,files=id==='muse'?['usage-evidence.js','muse-usage.js','muse-reader.js','task-list.js','task-note-metadata.js','task-note-button.js']:['grok-quota.js','additional-services.js','additional-reader.js'],version=id==='muse'?'1.136.0':'1.96.0',registered=(await chrome.scripting.getRegisteredContentScripts({ids:[scriptId]}))[0],upgrade=!!registered&&(id==='muse'?JSON.stringify(registered.js)!==JSON.stringify(files):registered.js?.[0]!=='grok-quota.js');if(upgrade)await chrome.scripting.unregisterContentScripts({ids:[scriptId]});if(!registered||upgrade)await chrome.scripting.registerContentScripts([{id:scriptId,matches:(A.PROVIDERS[id].origins||[A.PROVIDERS[id].origin]).map(origin=>origin+'/*'),js:files,runAt:'document_idle',persistAcrossSessions:true}]);if(id==='grok')await root.GlanceGrokRefresh?.refresh(force);if(id==='muse')await root.GlanceMuseRefresh?.refresh(force);for(const tab of (await chrome.tabs.query({url:(A.PROVIDERS[id].origins||[A.PROVIDERS[id].origin]).map(origin=>origin+'/*')})).filter(t=>A.route(t.url)===id).sort((a,b)=>Number(!!b.active)-Number(!!a.active)||(b.lastAccessed||0)-(a.lastAccessed||0)||a.id-b.id).slice(0,3)){if(A.route(tab.url)!==id)continue;try{const reply=await bounded(chrome.tabs.sendMessage(tab.id,{type:id==='muse'?'ADDITIONAL_READ':'ADDITIONAL_READ_196'}));if(reply?.version!==version)throw Error('Reader upgrade')}catch{await bounded(chrome.scripting.executeScript({target:{tabId:tab.id},files}))}}}));}
 root.GlanceAdditionalBackground={KEY,openMuseUsage,setMuseResetAnswer,configure,receive,refresh,readerStatus};
})(globalThis);
