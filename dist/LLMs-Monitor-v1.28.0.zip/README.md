# LLMs Monitor

[![LLMs Monitor — English A4 landscape product overview](assets/promotional/llms-monitor-a4-landscape-flyer-en-v1.jpg)](assets/promotional/llms-monitor-a4-landscape-flyer-en-v1.jpg?raw=1)

[Open the full-size English flyer](assets/promotional/llms-monitor-a4-landscape-flyer-en-v1.jpg?raw=1) · [Download English JPEG](assets/promotional/llms-monitor-a4-landscape-flyer-en-v1.jpg?raw=1)

**See the remaining usage across ChatGPT, Claude, and Gemini at a glance.**

[🌍 EN](#en) · [🇯🇵 JP](#ja)

<a id="en"></a>

This browser companion checks usage from your signed-in provider sessions about once a minute. Large gauges and bars show current and weekly limits, reset times, plans, and available credits. Your change history stays in your browser, with up to 10,000 entries per limit. The interface supports English and Japanese, light and dark themes, fullscreen viewing, and compact floating panels.

Version **1.26.0 beta** fixes a billing-reader circular wait that could stop quota refresh, masks expired cached quotas, and adds independent automatic sidebar task lists. Custom-domain pairing and the previous Site URL remain supported. It includes bounded local diagnostic logs, stable language selection, reliable usage/API page opening, and a compact floating view with all three services visible. API billing balances remain optional and separate from subscription quotas. OpenAI billing-page extraction was verified; Claude/Gemini live billing accounts still need validation. Earlier changes are in the [changelog](CHANGELOG.md).

[Product site](https://llmsmonitor.ntus.info/product.html) · [Open the monitor](https://llmsmonitor.ntus.info/) · [Download the beta extension package](dist/LLMs-Monitor-v1.27.0.zip) · [Detailed specification](SPECIFICATION.md) · [Privacy](PRIVACY.md) · [Follow @ntus on X](https://x.com/ntus)

### Custom domain connection

Version **1.23.0** adds extension access for [llmsmonitor.ntus.info](https://llmsmonitor.ntus.info/), preserving the previous Site URL. Update the existing extension in place, reload the monitor, and enter the same extension ID once on the new domain. Browser localStorage is separated by origin; extension-stored history and settings are retained. Do not uninstall to update. Store installations need the approved store update; the packaged ZIP is available for beta testing.

## Basic specifications

- **Platforms:** static web monitor plus a Manifest V3 extension for desktop Chrome and Edge. The extension supplies data from currently signed-in official provider accounts.
- **Services:** ChatGPT, Claude, and Gemini, individually shown or hidden and reordered. Available session and weekly limits, plans, credits, reset times, and local change history are displayed only when provider data is available.
- **Refresh:** usage about every minute; official OpenAI, Claude, and Gemini status feeds every minute. Active incidents trigger a visible alert and optional sound. The ⓘ control also shows a normal or unavailable state.
- **Storage:** settings and up to 10,000 history entries per limit stay in browser local storage; provider passwords are never requested.
- **Display:** English/Japanese, light/dark, fullscreen, floating window, supported browser Picture-in-Picture, configurable translucency, and alert volume.
- **Limits:** provider APIs and pages may change; unverified values remain unavailable. The floating window cannot provide OS-wide transparency or always-on-top behavior without browser support.

[Revision history](CHANGELOG.md#en) · [Security review](SECURITY_REVIEW.md#en)

## Quick start

1. Sign in to the services you want to monitor on their official [ChatGPT](https://chatgpt.com/), [Claude](https://claude.ai/), and [Gemini](https://gemini.google.com/) sites in the same Chrome or Edge profile. Enter credentials only on those sites.
2. Before store approval, run `python3 build.py --package`, unpack `dist/LLMs-Monitor-v1.27.0.zip`, and load the unpacked extension from the browser's extension management page for beta testing. Installing without developer mode requires Chrome Web Store or Edge Add-ons review and publication.
3. Open the extension or the [web monitor](https://llmsmonitor.ntus.info/). The web monitor asks for your extension ID once. The providers' usage tabs do not need to remain open.
4. Use **Show and arrange services** to choose and reorder cards. Hidden services continue collecting history. Adjust language, theme, opacity, volume, and fullscreen mode from the controls.

The monitor never asks for provider passwords and never exercises a reset entitlement automatically. A reset link opens the official usage page when an entitlement is available. If a provider does not expose a reliable plan or deadline, the app shows it as unavailable rather than guessing. Document Picture-in-Picture can keep a panel on top in supported browsers; OS-wide window transparency and native mobile apps are outside this beta.

For contributors and future AI-assisted changes, read [AGENTS.md](AGENTS.md), the [specification](SPECIFICATION.md), and the [requirements ledger](spec/requirements.json) before editing. Run `node --test tests/*.test.cjs` and `python3 build.py --package` before a package release.

---

## Task trial v1.26.0: separate task windows

Each visible ChatGPT, Claude or Gemini card now has **Task details**, opening a separate tall, resizable window (or a new tab if popups are blocked). Search projects/chats, filter reported states, expand the tree, and copy it as text. Language and theme are inherited when opening; controls in the task window affect only that window.

With extension **1.26.0**, the separate page acquires a partial list of visible sidebar titles and links from fresh inactive provider home tabs, on opening and every minute while visible. An independent observer checks already-open conversation controls every five seconds for generating/response-idle states; closed chats stay unknown. It never reads messages or infers completion. Update the extension in place and, if needed, reload official chat tabs after saving drafts. Desktop Codex tasks still require a manual JSON export. JSON import and the labelled synthetic demo remain available; import, Demo and Clear pause automatic acquisition. Lists stay in memory, without upload or persistence. See [the task-view contract and limits](TASK_DETAILS.md#en).

Quota acquisition and saved history are independent from the task adapter. Floating incident details omit healthy providers while incidents exist; AI feed disclosure has a separate expand control. The X feed needs server configuration and is not claimed operational.

v1.27.0 adds Claude Code sidebar input-needed/idle/unread observations without opening individual conversations. Refresh is once a minute and observations expire after 90 seconds; unread never means completed. Update the installed extension in place.

<a id="ja"></a>

## タスク試作 v1.26.0：独立したタスク画面

各ChatGPT・Claude・Geminiカードの **［タスク詳細］** から、縦長でサイズ変更可能な別窓を開きます。小窓がブロックされた場合は別タブになります。プロジェクト・チャットの検索、状態の絞り込み、ツリー開閉、テキストコピーに対応します。起動時の言語・テーマを引き継ぎ、別窓内の切替はその窓だけに適用します。

拡張機能 **1.26.0** で、公式ホームを新しい非アクティブなタブで開き、表示済みサイドバーの名称とリンクを起動時・表示中の約1分ごとに自動取得します。一覧は部分的です。独立した観測処理が開いている会話の操作ボタンを約5秒ごとに確認し、応答生成中／応答待機を補足します。閉じた会話は未確認のまま、本文取得や完了の推定は行いません。拡張を上書き更新後、必要なら入力を保存して公式会話タブを再読込してください。デスクトップCodexのタスクは引き続き手動JSONが必要です。JSON読込と架空サンプルも利用でき、読込・サンプル・消去で自動取得を停止します。一覧はメモリー内だけで扱い、送信・永続保存しません。[詳細仕様と制約](TASK_DETAILS.md#ja)を参照してください。

残量取得・保存履歴とタスク処理は独立しています。障害中の小窓詳細は該当サービスだけを表示し、AI速報は別に開閉します。X速報はサーバー設定が必要で、稼働済みとは表示しません。

## 独自ドメインへの接続

**1.23.0** で [llmsmonitor.ntus.info](https://llmsmonitor.ntus.info/) を接続許可に追加し、旧URLも継続利用できます。既存の拡張機能を同じ読込元のまま更新し、Web画面を再読込して、同じ拡張機能IDを新ドメインで一度登録してください。ブラウザーのlocalStorageはURLのoriginごとに分かれますが、拡張機能内の履歴・設定は保持されます。更新のためにアンインストールしないでください。ストア版は審査・公開された更新が必要です。β検証用ZIPも配布します。
# 日本語 — LLMs モニター

**ChatGPT/Claude/Geminiのトークン利用残量をリアルタイム表示**

[![LLMs モニター — 日本語A4横製品紹介](assets/promotional/llms-monitor-a4-landscape-flyer-v1.jpg)](assets/promotional/llms-monitor-a4-landscape-flyer-v1.jpg?raw=1)

[日本語版チラシを原寸表示](assets/promotional/llms-monitor-a4-landscape-flyer-v1.jpg?raw=1) · [日本語版JPEGをダウンロード](assets/promotional/llms-monitor-a4-landscape-flyer-v1.jpg?raw=1)

[🌍 EN](#en) · [🇯🇵 JP](#ja)

## 1.27.0 β

API請求読取で起きた循環待ちを修正し、期限切れの古い残量を現在値として表示しないようにしました。独立したタスク一覧の自動取得を追加し、旧URLと履歴を維持します。

診断ログを変化履歴とは別に端末内へ保存し、必要なときだけJSONLで書き出せます。言語切替、利用状況・API連携画面の再表示、3社を同時に見せる小窓を改善しました。API連携はAPIクレジット欄から開きます。


診断ログは端末内に保存し、自動送信しません。小窓は3社を表示し、独自のタイトル行やサイズメニューは追加しません。


Claudeの週間0%も公式画面で確認します。使用率1%は残量99%として扱い、確認前に前回値や履歴を上書きしません。


Claudeの未確認0%を誤って確定表示しないよう修正し、公式画面を再確認します。フローティングの変化履歴は初期状態で閉じ、縦方向のCSS制限を解除しました。

ChatGPTのリセット権期限がAPIにない場合、公式使用状況タブの読み取りを自動復旧します。既存タブにスクリプトがなければ再読込し、タブがない場合は一時的に非アクティブな公式タブを開いて取得後に閉じます。各種AIツールはおすすめ9件＋10番目のNerf Benchに整理しました。

## 1.17.1 β

「役立つAIツール」を「各種AIツール」に改め、「各種LLM」と同じ幅連動のカード配置にしました。カードの余白と行間を詰めました。全画面表示ではツール欄を隠し、残量・履歴の表示領域を優先します。

## 1.17.0 β

ChatGPTの使用状況画面を開いたまま拡張機能を更新したときは、該当タブを一度再読込してリセット権期限の原文を取り直します。フローティング画面の点滅中も主数値の大きさを維持し、各種LLMの前に便利なAIツール11件のリンク集を追加しました。Nerf Benchは11番目のリンクのみです。

## 1.16.0 β

ChatGPTのリセット権は、公式画面で確認できた種別と期限の原文を利用可能件数の下に表示します。Claudeの公式画面で残量があるのにAPIだけが0%を返した場合は、矛盾する0%を表示・通知しません。残量5%以下と1%以下には段階別の穏やかな警告音を用意しました。

Tibo氏と各社公式Xの1分周期速報を維持します。X認証情報は拡張機能へ入れず、サーバー側Secretだけで扱います。実データ接続にはX Developer bearer token、サーバーキャッシュ、1分cronの設定が必要です。

## 1.9.0 β

Claudeの週間枠とクラウドセッションクレジットへ現在セッション単位の区切りを追加し、クラウドセッションクレジット残額を小数点以下2桁に丸めました。残量変化時は通知音を開始してから赤色点滅を表示します。公式障害情報は引き続き1分ごとに確認します。

## 1.6.4 β

ChatGPT、Claude、Gemini の残量とリセット時刻を、ログイン中の公式セッションから約1分ごとに確認するブラウザー用モニターです。円とバーで現在枠・週間枠を見渡し、変化履歴を各枠最大10,000件まで端末内に保持します。日本語／英語、標準／ダーク、フルスクリーン、通常小窓、対応ブラウザーでの最前面表示に対応します。

v1.6.4では履歴読込結果と通知音説明を左右ボタン付きのステータスログへ集約し、履歴読込メッセージの再計算を最大1分に1回へ抑えました。通常小窓は明示的なボタン操作時だけ開き、作成時の固定幅・固定高を廃止してブラウザーとOSが許す範囲で自由にリサイズできます。

3サービスの表示・非表示と順序を保存し、表示枚数に合わせてレイアウトを調整します。履歴から週間枠が現在セッションの何枠分に相当するかを推定し、期限が近いリセット権と利用枠を段階的に警告します。分析欄は高さを約半分に抑え、利用ペースの提案、公式ソース付きTips／NEWSを切り替えて表示します。通知音量のスライダー操作中も画面が動かないよう修正し、アプリアイコンを刷新しました。

[使い方](#使い方) · [基本仕様](#基本仕様) · [改訂履歴](CHANGELOG.md#ja) · [詳しい仕様と制限](SPECIFICATION.md) · [デグレ防止手順](AGENTS.md) · [プライバシー](PRIVACY.md) · [更新情報をXで見る](https://x.com/ntus)

## 基本仕様

- **構成:** OSに依存しない静的Webモニターと、デスクトップ版Chrome／Edge用Manifest V3拡張機能。ログイン済みの公式セッションから拡張機能がデータを取得します。
- **対象:** ChatGPT、Claude、Gemini。表示・非表示と順序を設定でき、提供元から確認できた現在枠、週間枠、契約プラン、クレジット、リセット時刻、変化履歴を表示します。
- **更新:** 残量は約1分ごと、各社の公式障害情報は約1分ごと。障害があれば画面内警告と設定に応じた通知音で知らせ、ⓘから正常時も確認できます。
- **保存:** 設定と各枠最大10,000件の履歴はブラウザー内に保存。パスワード入力は求めません。
- **画面:** 日英、標準／ダーク、フルスクリーン、通常小窓、対応ブラウザーの最前面表示、半透明度と音量調整。
- **制約:** 提供元の画面やAPI変更により未取得になる場合があります。OS全体での窓透過・常時最前面はブラウザーの対応範囲に限られます。

### 使い方

1. 同じChromeまたはEdgeプロファイルで [ChatGPT](https://chatgpt.com/)、[Claude](https://claude.ai/)、[Gemini](https://gemini.google.com/) に必要な分だけログインします。パスワードは公式サイトで入力します。
2. ストア公開前は、このリポジトリで `python3 build.py --package` を実行し、`dist/LLMs-Monitor-v1.27.0.zip` を展開して、ブラウザーの拡張機能管理画面から開発用として読み込みます。一般ユーザーがデベロッパーモードなしで導入するには、Chrome Web Store / Edge Add-ons の審査・公開が必要です。
3. 拡張機能の画面、または [公開モニター](https://llmsmonitor.ntus.info/) を開きます。公開モニターでは拡張機能IDを一度登録してください。各サービスの使用量タブを開いたままにする必要はありません。
4. 「表示サービス」からチェックと上下ボタンで表示数・順序を変更します。非表示中も取得と履歴保存は続きます。音、テーマ、言語、透明度、フルスクリーンも画面上で変更できます。
5. 残量とリセット時刻は公式サービスが返す範囲で表示されます。リセット権は利用可能なら公式利用量ページへ移動できますが、アプリから自動行使しません。出典のあるTips／NEWSはリンクで原文を確認できます。

### β版の注意点

Geminiなどの契約プランは公式アカウント画面から取得できない場合があります。その場合は未取得と表示し、推測した有料プラン名は付けません。週間の「現在セッション何枠分」は十分な同期履歴があるときだけ推定表示します。ブラウザー外のOS全体での常時最前面・窓全体の透過はWeb拡張機能の機能ではありません。対応ブラウザーのDocument Picture-in-Pictureを使用します。iOS／Androidのネイティブ版は今後の設計対象で、今回のβには含みません。

OSに依存しない静的Webアプリと、Chrome / Edgeデスクトップ用Manifest V3拡張機能です。Safari、Firefox、モバイルブラウザへの対応は未検証です。

## 使い方

1. Chrome Web StoreまたはMicrosoft Edge Add-onsで審査公開された拡張機能を追加します。ストア公開前のZIPは審査提出・動作確認用です。
2. ChatGPT・Claude・Geminiの公式サイトへ普段のブラウザプロファイルでログインします。モニタにパスワードを入力する画面はありません。
3. ツールバーの「LLMs モニター」を開きます。以後は60秒ごとにバックグラウンド取得し、専用タブを開いたままにする必要はありません。
4. 各AIサイト上の半透明パネル、必要時にボタンで開くフローティング小窓、またはメインモニタで残量を確認します。
5. 常に手前へ置く場合はメイン画面の「最前面に固定」を押します。ブラウザの制約によりユーザー操作が必要で、元のモニター画面を閉じると終了します。

ホストされたWebアプリは、拡張機能の詳細画面にある32文字のIDを入力すると接続できます。拡張機能に内蔵したモニターはID入力不要・ネット接続なしでも起動できます。取得には各サービスへの通信が必要です。

## 表示と制約

- Claude: 現在のセッション・週間の使用済み率から残量を算出。製品別内訳や追加クレジットは混ぜません。
- Gemini: 公式使用量ページの現在・週間の使用率から残量を算出。
- ChatGPT: 現時点で確認した公式使用量ページは通常Chatを含みません。表示できるのは **Work / Codex等の共通利用枠** です。「通常のChat：取得不可」と明記します。Chatの正確な残量は未実装・取得未確認です。
- 数値がない場合は「—」。更新中・取得失敗時は前回取得値を保持し、ログアウト時は数値を消去。125秒以上経過すると「更新待ち」を表示します。
- 常駐パネルは対象3サイトのページ内で半透明表示されます。背景不透明度は15〜100%です。通常小窓およびPiPのウィンドウ自体は、OSデスクトップを透過するネイティブオーバーレイではありません。
- 通常小窓はボタン操作時だけ開き、ブラウザーとOSが許す範囲で縦横にリサイズできます。対応Chrome/Edgeでは、ユーザーが「最前面に固定」を押すとDocument Picture-in-Pictureへ切り替えます。
- 複数アカウントの合算はしません。各公式サービスで現在選択されているアカウントが対象です。アカウント切り替え後は「今すぐ更新」を押してください。
- 公式DOM構造を読むため、サービス側の変更で修正が必要になることがあります。

## データ・権限

パスワードは読み取りません。ChatGPTの使用量取得では、公式ページが現在のログインに使っているアクセストークンを取得処理中のメモリ内だけで利用し、保存・ログ出力・第三者送信をしません。ClaudeとGeminiも現在の公式ログインセッションを使います。取得対象は契約名・利用枠・残率・リセット時刻・関連クレジットです。使用量・履歴・表示設定はブラウザのlocalストレージだけに保存し、運営サーバーへアップロードしません。送信・購入操作は自動実行しません。

拡張機能に対する3サイトの閲覧権限は、ログイン中の公式セッションで使用量を取得するために必要です。ブラウザ再起動時は前回値をすぐ表示し、その後バックグラウンド更新します。

## 開発

- `python3 -m http.server 4173 --directory dist` でローカルWeb版の表示を確認できます。本番Manifestは安全のためlocalhostからの外部接続を許可しないので、実データ接続は拡張機能内蔵画面か公開HTTPS版で検証します。
- `node --test tests/*.test.cjs` で残量パーサーを検証。
- `python3 build.py` でWeb成果物を更新し、ストア配布ZIPを意図的に更新する場合だけ `python3 build.py --package` を使う。
- `dist/` が静的Web配布物。`extension/` が読み込み可能な拡張機能。

実装契約、取得経路、データモデル、手動検証項目は [SPECIFICATION.md](SPECIFICATION.md) を正本とし、機械可読の受入条件は [`spec/requirements.json`](spec/requirements.json) を参照してください。公式サービスの非公開内部構造は変更され得るため、拡張機能の実アカウントでの通し動作はリリースごとに確認します。

APIクレジット残高も追加しました。上部の「API連携」で各社へのアクセスを個別に許可し、公式請求画面を開いておくと表示値を読み取ります。月額プランの残量とは別表示です。OpenAIの実画面を確認済み、Claude／Geminiの請求アカウント実測は未検証です。外窓のタイトルと言語を共通化し、↔メニューで縦横のサイズを個別に調整できます。

v1.27.0はClaude Codeの一覧から入力待ち／アイドル／未読の返答を取得します。会話タブ不要、1分更新、90秒失効。未読を完了とは扱いません。拡張機能の上書き更新が必要です。

## v1.28.0

EN: Pinned items, verified project/group names and explicitly saved thread work notes/checklists/handoff in the independent task screen. Sidebar coverage remains partial. Claude API promotional credits have a separate row.

JP: 独立タスク画面へピン留め優先・確認済みプロジェクト／グループ名・スレッド別作業メモ・チェックリスト・引継ぎを追加。一覧の全件取得は保証しません。Claude APIのプロモーションクレジットを別行に表示します。
