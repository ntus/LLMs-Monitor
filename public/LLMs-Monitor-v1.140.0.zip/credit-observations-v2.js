/* Local advisory observations only. No source identifiers or execution authority. */
(function(root){
'use strict';
const SCHEMA='monitor.credit-observations.v2',TTL=125000;
const PROVIDERS=Object.freeze({openai:'chatgpt',anthropic:'claude',google:'gemini',xai:'grok'});
const time=n=>Number.isSafeInteger(n)&&n>0&&n<=8640000000000000;
const iso=n=>time(n)?new Date(n).toISOString():null;
const object=v=>v&&typeof v==='object'&&!Array.isArray(v)?v:{};
const money=n=>typeof n==='number'&&Number.isFinite(n)&&Math.abs(n)<=1e9&&decimal(n).length<=40;
const currency=v=>['USD','EUR','JPY','GBP'].includes(v);
function decimal(n){const s=String(n);if(!/[eE]/.test(s))return s;const [co,ex]=s.toLowerCase().split('e'),negative=co.startsWith('-'),body=negative?co.slice(1):co,[a,b='']=body.split('.'),digits=a+b,pos=a.length+Number(ex);return (negative?'-':'')+(pos<=0?'0.'+'0'.repeat(-pos)+digits:pos>=digits.length?digits+'0'.repeat(pos-digits.length):digits.slice(0,pos)+'.'+digits.slice(pos));}
function selection(ids){if(!Array.isArray(ids)||!ids.length||ids.length>4||new Set(ids).size!==ids.length||ids.some(id=>!Object.hasOwn(PROVIDERS,id)))throw Error('invalid-selection');return [...ids].sort();}
function expiry(v){return time(v)?{precision:'instant',at:iso(v)}:{precision:'unknown'};}
function date(v){if(typeof v!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(v))return false;const d=new Date(v+'T00:00:00Z');return Number.isFinite(d.getTime())&&d.toISOString().slice(0,10)===v;}
function create(input,ids,now=Date.now()){
 if(!time(now))throw Error('invalid-clock');input=object(input);
 const providers=selection(ids).map(provider=>{
  const row=object(input[PROVIDERS[provider]]),enabled=row.enabled===true,a=object(row.acquisition),at=time(a.at)&&a.at<=now?a.at:null;
  const failed=/^console-(?:login|rate-limited|ambiguous|no-api-organization|format|timeout|http|transport)$/.test(a.stage||'');
  const attempt=at?failed?'error':['ready','paused','waiting'].includes(a.status)?a.status==='ready'?'success':a.status==='paused'?'error':'pending':'unknown':'unknown';
  function lane(raw,kind){
   raw=object(raw);const observed=time(raw.capturedAt)&&raw.capturedAt<=now?raw.capturedAt:null;
   const valid=enabled&&observed&&raw.status==='ready'&&money(raw.amount)&&currency(raw.currency)&&(kind!=='promotional'||raw.amount>=0);
   let status=!enabled?'disabled':['login','postpaid','unavailable'].includes(raw.status)?raw.status:'unknown';
   const stale=valid&&(now-observed>TTL||at&&at>=observed&&attempt==='error'||attempt==='pending'&&at>observed);
   if(valid)status=time(raw.expiresAt)&&raw.expiresAt<=now?'expired':stale?'stale':'ready';
   const result={kind,status,amountDecimal:valid?decimal(raw.amount):null,currency:valid?raw.currency:null,observedAt:enabled?iso(observed):null,totalDecimal:valid&&money(raw.total)&&raw.total>0&&raw.amount<=raw.total?decimal(raw.total):null,expiry:valid?expiry(raw.expiresAt):{precision:'unknown'},grants:[],nextExpiry:null};
   if(valid&&raw.grants!==undefined){
    const grants=raw.grants;
    const good=Array.isArray(grants)&&grants.length>0&&grants.length<=100&&grants.every(g=>g&&g.status==='ready'&&money(g.amount)&&g.amount>=0&&g.currency===raw.currency&&money(g.total)&&g.total>0&&g.amount<=g.total)&&Math.abs(grants.reduce((n,g)=>n+g.amount,0)-raw.amount)<.005;
    if(!good)return {...result,status:'unknown',amountDecimal:null,currency:null,totalDecimal:null,expiry:{precision:'unknown'}};
    result.grants=grants.map(g=>({amountDecimal:decimal(g.amount),currency:g.currency,totalDecimal:decimal(g.total),expiry:expiry(g.expiresAt)}));
    // The aggregate has no single deadline, even if an old cache retained one.
    result.expiry={precision:'unknown'};
    if(status==='expired')result.status=stale?'stale':'ready';
    if(grants.every(g=>time(g.expiresAt)&&g.expiresAt<=now))result.status='expired';
   }
   const next=object(raw.nextExpiry);
   if(valid&&provider==='openai'&&kind==='purchased'&&date(next.date)&&money(next.amount)&&next.amount>0&&next.amount<=raw.amount+.005&&next.currency===raw.currency)result.nextExpiry={amountDecimal:decimal(next.amount),currency:next.currency,expiry:{precision:'date',date:next.date,timezone:'unknown'}};
   return result;
  }
  const observedAt=enabled&&time(row.capturedAt)&&row.capturedAt<=now?iso(row.capturedAt):null;
  return {provider,product:'api',enabled,account:{bindingStatus:'unverified'},observedAt,sourceStatus:!enabled?'disabled':row.status==='ready'&&!observedAt?'unknown':['ready','login','postpaid','unavailable'].includes(row.status)?row.status:'unknown',sourceKind:'official-billing-reader',lastAttempt:{at:enabled?iso(at):null,status:enabled?attempt:'unknown'},lanes:[lane(row,'purchased'),...(provider==='anthropic'?[lane(row.promotional,'promotional')]:[])]};
 });
 return {schema:SCHEMA,generatedAt:iso(now),providers,freshness:{maxAgeMs:TTL},trust:{accountVerified:false,spendAuthorization:false,executionAuthorization:false}};
}
const api={SCHEMA,TTL,PROVIDERS,selection,create};root.GlanceCreditObservationsV2=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
