/* Optional Muse settings. Read-only preparation only in a freshly revalidated owned inactive tab. */
(()=>{
 const version='1.145.11';
 if(globalThis.llmsMuseReader?.version===version)return;globalThis.llmsMuseReader={version};
 const RETRY_CLOSE_MS=5000;
 let reopen='not-requested',closeAttempt=0,closeRetryAt=0,exitProgress=null;
 let pending=false,transitionQueued=false,stopped=false,timer,mutationTimer,signature='',stableAt=0,preparations=0,lastPreparationAt=0,generation=0,refreshPending=false,previousUsage=null,submittedAt=0,diagStage='idle';
 const route=()=>location.origin==='https://muse.ai'&&location.pathname==='/'&&!location.search&&!location.hash;
 function wake(delay){
  clearTimeout(timer);
  timer=setTimeout(read,delay);
 }
 async function read(){
  if(stopped||pending||globalThis.llmsMuseReader?.version!==version||!route())return;pending=true;diagStage='checking';
  try{
   const allowed=await chrome.runtime.sendMessage({type:'ADDITIONAL_READER_STATUS',service:'muse'});if(allowed?.enabled!==true||!route()||stopped){diagStage='disabled';return;}
   if(allowed.generation!==generation){
    generation=allowed.generation;preparations=0;lastPreparationAt=0;
    if(allowed.prepare===true&&allowed.explicit!==true){
     refreshPending=true;closeAttempt=0;closeRetryAt=0;
    }else refreshPending=false;
   }
   const exiting=closingSettings()||(allowed.prepare===true&&GlanceMuseUsage.findClosingSettings?.(document));
   if(exiting){
    refreshPending=false;
    reopen='closing';
    const checkedAt=Date.now();
    if(exitProgress?.element!==exiting||exitProgress.generation!==generation)exitProgress={element:exiting,generation,since:checkedAt,attempts:0,nextAt:0,result:'pending'};
    if(exitProgress.attempts<2&&checkedAt>=exitProgress.nextAt&&allowed.prepare===true&&allowed.explicit!==true&&document.visibilityState==='hidden'){
     const current=await chrome.runtime.sendMessage({type:'ADDITIONAL_READER_STATUS',service:'muse'});
     if(current?.enabled===true&&current.prepare===true&&current.generation===generation&&route()&&document.visibilityState==='hidden'){
      const emitted=GlanceMuseUsage.finishSettingsClose(exiting,(Date.now()-exitProgress.since)/1000);
      if(emitted)exitProgress.attempts++;
      exitProgress.result=emitted?'exit-signalled':'animation-unavailable';
      exitProgress.nextAt=Date.now()+(emitted?5000:1000);
     }
    }
    if(exiting.isConnected&&!GlanceMuseUsage.currentUsageView(document)){diagStage='preparing';wake(1600);return;}
    if(!exiting.isConnected){signature='';stableAt=0;}
    reopen='view-replaced';
   }
   if(previousUsage&&usageViewChanged()){
    previousUsage=null;signature='';stableAt=0;reopen='view-replaced';refreshPending=false;
   }
   const retryClose=previousUsage&&closeAttempt===1&&Date.now()>=closeRetryAt&&allowed.prepare===true&&allowed.explicit!==true;
   if(refreshPending||retryClose){
    const current=await chrome.runtime.sendMessage({type:'ADDITIONAL_READER_STATUS',service:'muse'});
    if(current?.enabled!==true||current.prepare!==true||current.generation!==generation||!route())return;
    refreshPending=false;
    const attempted=GlanceMuseUsage.refreshGeneral(document,closeAttempt===1);
    if(attempted){
     previousUsage=previousUsage||attempted;
     closeAttempt++;
     closeRetryAt=Date.now()+RETRY_CLOSE_MS;
     reopen=closeAttempt===1?'requested':'retry-requested';
     diagStage='preparing';wake(1600);return;
    }
    reopen=previousUsage?'close-unconfirmed':'settings-not-ready';
    if(previousUsage)closeAttempt=2;
   }
   if(previousUsage){
    if(closeRetryAt>Date.now())wake(closeRetryAt-Date.now());
    else reopen='close-unconfirmed';
   }
   diagStage='collecting';const cards=GlanceMuseUsage.collect(document),parsed=GlanceMuseUsage.extract(cards);
   // Loading or an absent General section must not erase or refresh the previous observation.
   if(parsed.status!=='ready'){if(allowed.prepare===true&&preparations<3){const render=allowed.explicit===true?null:await chrome.runtime.sendMessage({type:'MUSE_RENDER_PENDING',service:'muse'});if(render?.rendered){wake(1600);return}if(Date.now()-lastPreparationAt<5000){wake(5000-(Date.now()-lastPreparationAt));return}const current=await chrome.runtime.sendMessage({type:'ADDITIONAL_READER_STATUS',service:'muse'});if(current?.enabled!==true||current.prepare!==true||current.generation!==generation||!route())return;diagStage='preparing';if(GlanceMuseUsage.prepare(document)){lastPreparationAt=Date.now();preparations++;}else diagStage='no-controls';wake(1600)}return}
   const key=JSON.stringify(parsed);if(key!==signature){signature=key;stableAt=Date.now();wake(1600);return}if(Date.now()-stableAt<1500)return;
   if(stableAt===submittedAt){diagStage='unchanged';return;}
   const result=await chrome.runtime.sendMessage({type:'ADDITIONAL_SNAPSHOT',service:'muse',readerVersion:version,generation:allowed.generation,observedAt:stableAt,evidence:cards});
   if(result?.ok===true){submittedAt=stableAt;diagStage='submitted';}
   else if(result?.reason==='source-window')diagStage='source-window';
   else if(result?.reason==='stale-observation'){submittedAt=stableAt;diagStage='stale';}
   else diagStage='ignored';
  }catch{diagStage='error'; /* An extension restart/revoke fails closed; no page text or private error logging. */ }
  finally{
   pending=false;
   if(transitionQueued){transitionQueued=false;void read();}
  }
 }
 function closingSettings(){
  const dialog=previousUsage?.heading?.closest?.('[role="dialog"]');
  return dialog?.isConnected&&dialog.getAttribute('data-state')==='closed'?dialog:null;
 }
 function usageViewChanged(){
  const view=GlanceMuseUsage.currentUsageView(document);
  return !view||view.heading!==previousUsage.heading||previousUsage.weekly&&view.weekly!==previousUsage.weekly;
 }
 // Resume a known dialog transition from its DOM mutation, even if the
 // hidden document's retry timer has been delayed. Other mutations coalesce.
 const observer=new MutationObserver(()=>{
  if(stopped||globalThis.llmsMuseReader?.version!==version)return;
  if(previousUsage&&usageViewChanged()){
   if(pending)transitionQueued=true;
   else void read();
   return;
  }
  if(mutationTimer!==undefined)return;
  mutationTimer=setTimeout(()=>{mutationTimer=undefined;void read()},1500);
 });
 observer.observe(document.documentElement,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['data-state','hidden','aria-hidden']});
 const interval=setInterval(read,60000);timer=setTimeout(read,1500);
 chrome.runtime.onMessage.addListener((m,_,reply)=>{if(m?.type==='MUSE_READER_DIAG_145'){
  const dialog=previousUsage?.heading?.closest?.('[role="dialog"]')||GlanceMuseUsage.findClosingSettings?.(document);
  const state=dialog?.getAttribute('data-state');
  const closeState=state==='closed'?'closed':state==='open'?'open':dialog?'unspecified':'no-dialog';
  reply({version,stage:diagStage,reopen,closeState,closeAttempts:closeAttempt,exitSignal:exitProgress?.result,exitSignals:exitProgress?.attempts,focused:document.hasFocus(),visibility:document.visibilityState});return false;
 }if(m?.type!=='MUSE_READ_145')return false;void read();reply({ready:true,version});return false});
 addEventListener('pagehide',()=>{stopped=true;observer.disconnect();clearTimeout(timer);clearTimeout(mutationTimer);clearInterval(interval)},{once:true});
})();
