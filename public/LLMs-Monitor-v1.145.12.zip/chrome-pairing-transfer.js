/* Only the verified Store extension can claim an explicitly armed local transfer. */
(function(root){
 'use strict';
 const LEGACY='ldhacaeoaldahdlldkbcndifogplegda';
 const STORE='menlhnbheidlicenhdampkebgopnlpdk'; // Replaced by prepare-store.py after checking the Store public key.
 const PAGE='chrome-migration.html',SESSION='llms-chrome-pairing-transfer-v1';
 const QUOTA='llms-gateway-link-v1',CREDIT='llms-gateway-credit-link-v1';
 const CODE=/^[a-f0-9]{32}$/;
 const UUID=/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i;

 function snapshot(saved){
  const quota=saved[QUOTA],credit=saved[CREDIT];
  return {
   quota:quota?.enabled===true&&quota.continuity==='until-disconnected'&&UUID.test(quota.pairingId)
    ?{pairingId:quota.pairingId,providers:quota.providers}:null,
   credit:credit?.enabled===true&&UUID.test(credit.id)&&Number.isSafeInteger(credit.epoch)&&credit.epoch>0&&
    Number.isSafeInteger(credit.sequence)&&credit.sequence>=0
    ?{id:credit.id,epoch:credit.epoch,sequence:credit.sequence,providers:credit.providers}:null
  };
 }

 function create(chrome,readers,{now=Date.now,token=()=>root.crypto.randomUUID().replaceAll('-',''),store=STORE}={}){
  let queue=Promise.resolve();
  const serial=fn=>{const result=queue.then(fn);queue=result.catch(()=>{});return result;};
  const role=!/^[a-p]{32}$/.test(store)||store===LEGACY?'unconfigured':
   chrome.runtime.id===LEGACY?'legacy':chrome.runtime.id===store?'store':'unconfigured';
  const own=sender=>sender.id===chrome.runtime.id&&sender.url===chrome.runtime.getURL(PAGE)&&
   (sender.frameId===undefined||sender.frameId===0);

  async function handle(message,sender,external){
   if(external){
    if(role!=='legacy'||message.type!=='CHROME_PAIRING_CLAIM'||sender.id!==store||
       (sender.url&&sender.url!==`chrome-extension://${store}/background.js`)||
       (sender.origin&&sender.origin!==`chrome-extension://${store}`)||
       typeof message.code!=='string'||!CODE.test(message.code))return {ok:false};
    return serial(async()=>{
     const armed=(await chrome.storage.session.get(SESSION))[SESSION];
     if(!armed||armed.expiresAt<=now()||armed.code!==message.code||armed.recipient!==store)return {ok:false};
     const payload=snapshot(await chrome.storage.local.get([QUOTA,CREDIT]));
     // Consume the code before returning, even if the active selection changed.
     await chrome.storage.session.remove(SESSION);
     return payload.quota||payload.credit?{ok:true,payload}:{ok:false};
    });
   }
   if(!own(sender))return {ok:false};
   if(message.type==='CHROME_PAIRING_MODE')return {ok:true,role};
   if(message.type==='CHROME_PAIRING_ARM'&&role==='legacy'){
    return serial(async()=>{
     const available=snapshot(await chrome.storage.local.get([QUOTA,CREDIT]));
     if(!available.quota&&!available.credit)return {ok:false,reason:'no-active-approval'};
     await chrome.storage.session.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'});
     const code=token();
     await chrome.storage.session.set({[SESSION]:{code,recipient:store,expiresAt:now()+5*60_000}});
     return {ok:true,code};
    });
   }
   if(message.type!=='CHROME_PAIRING_IMPORT'||role!=='store'||typeof message.code!=='string'||!CODE.test(message.code)){
    return {ok:false};
   }
   return serial(async()=>{
    if(!await chrome.permissions.contains({permissions:['nativeMessaging']}))return {ok:false,reason:'permission'};
    const result=await chrome.runtime.sendMessage(LEGACY,{type:'CHROME_PAIRING_CLAIM',code:message.code});
    if(!result?.ok||!result.payload)return {ok:false,reason:'invalid-code'};
    const {quota,credit}=result.payload;
    const adopt=async(ref,fn)=>{
     if(!ref)return 'absent';
     try{return await fn(ref)?'adopted':'unverified';}catch{return 'unverified';}
    };
    return {ok:true,quota:await adopt(quota,readers.quota),credit:await adopt(credit,readers.credit)};
   });
  }
  return {handle};
 }
 root.GlanceChromePairingTransfer={create};
 if(typeof module!=='undefined')module.exports={create,LEGACY,QUOTA,CREDIT};
})(globalThis);
